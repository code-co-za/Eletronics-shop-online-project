<?php
require_once '../includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /auth/login.php");
    exit;
}

$page_title = 'My Profile';
$user = getUserById($_SESSION['user_id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $firstName = $_POST['first_name'] ?? '';
    $lastName = $_POST['last_name'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $address = $_POST['address'] ?? '';

    if (updateUserProfile($_SESSION['user_id'], $email, $firstName, $lastName, $phone, $address)) {
        $success = "Profile updated successfully";
        $user = getUserById($_SESSION['user_id']); // Refresh user data
    } else {
        $error = "Error updating profile";
    }
}
?>
<h1>My Profile</h1>
<?php if (isset($success)): ?>
    <div class="success"><?= $success ?></div>
<?php elseif (isset($error)): ?>
    <div class="error"><?= $error ?></div>
<?php endif; ?>
<form method="post">
    <div>
        <label>Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
    </div>
    <div>
        <label>First Name:</label>
        <input type="text" name="first_name" value="<?= htmlspecialchars($user['first_name'] ?? '') ?>">
    </div>
    <div>
        <label>Last Name:</label>
        <input type="text" name="last_name" value="<?= htmlspecialchars($user['last_name'] ?? '') ?>">
    </div>
    <div>
        <label>Phone:</label>
        <input type="text" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
    </div>
    <div>
        <label>Address:</label>
        <textarea name="address"><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
    </div>
    <button type="submit">Update Profile</button>
</form>
<?php
require_once '../includes/footer.php';
?>