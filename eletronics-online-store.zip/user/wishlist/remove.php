<?php
require_once '../../../includes/header.php';

if (!isset($_SESSION['user_id']) || !isset($_POST['product_id'])) {
    header("Location: /user/wishlist.php");
    exit;
}

$userId = $_SESSION['user_id'];
$productId = $_POST['product_id'];

$stmt = $pdo->prepare("DELETE FROM wishlist WHERE user_id = ? AND product_id = ?");
$stmt->execute([$userId, $productId]);

header("Location: /user/wishlist.php?removed=1");
exit;
?>