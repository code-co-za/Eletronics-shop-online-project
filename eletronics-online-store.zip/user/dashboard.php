<?php
require_once '../includes/header.php';
require_once '../includes/cart_functions.php';
require_once '../includes/user_functions.php'; // Add this line to include user functions

if (!isset($_SESSION['user_id'])) {
    header("Location: /auth/login.php");
    exit;
}

$user = getUserById($_SESSION['user_id']);
$recentOrders = getRecentUserOrders($_SESSION['user_id'], 3);
$cartCount = getCartCount($_SESSION['user_id']);

$page_title = 'My Dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <style>
        /* Dashboard Styles */
        .user-dashboard {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .welcome-section h1 {
            color: #2c3e50;
            margin-bottom: 20px;
            font-size: 2.2rem;
        }
        
        .quick-stats {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            flex: 1;
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card h3 {
            color: #7f8c8d;
            margin-top: 0;
            font-size: 1rem;
        }
        
        .stat-card p {
            font-size: 2rem;
            font-weight: bold;
            color: #2c3e50;
            margin: 10px 0 0;
        }
        
        .dashboard-sections {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }
        
        section {
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        section h2 {
            color: #2c3e50;
            margin-top: 0;
            padding-bottom: 10px;
            border-bottom: 1px solid #ecf0f1;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        table th, table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }
        
        table th {
            background-color: #f8f9fa;
            color: #34495e;
            font-weight: 600;
        }
        
        table tr:hover {
            background-color: #f8f9fa;
        }
        
        .view-all {
            display: inline-block;
            margin-top: 10px;
            color: #3498db;
            text-decoration: none;
            font-weight: 500;
        }
        
        .view-all:hover {
            text-decoration: underline;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
        }
        
        .btn:hover {
            background: #2980b9;
        }
        
        .action-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-top: 20px;
        }
        
        .action-card {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
            text-decoration: none;
            color: #2c3e50;
            transition: all 0.3s ease;
            height: 100px;
        }
        
        .action-card:hover {
            background: #3498db;
            color: white;
            transform: translateY(-3px);
        }
        
        .action-card i {
            font-size: 2rem;
            margin-bottom: 10px;
        }
        
        @media (max-width: 768px) {
            .dashboard-sections {
                grid-template-columns: 1fr;
            }
            
            .quick-stats {
                flex-direction: column;
            }
            
            .action-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<div class="user-dashboard">
    <div class="welcome-section">
        <h1>Welcome, <?= htmlspecialchars($user['first_name'] ?? 'User') ?>!</h1>
        <div class="quick-stats">
            <div class="stat-card">
                <h3>Recent Orders</h3>
                <p><?= count($recentOrders) ?></p>
            </div>
            <div class="stat-card">
                <h3>Items in Cart</h3>
                <p><?= $cartCount ?></p>
            </div>
        </div>
    </div>

    <div class="dashboard-sections">
        <section class="recent-orders">
            <h2>Recent Orders</h2>
            <?php if (!empty($recentOrders)): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentOrders as $order): ?>
                        <tr>
                            <td><?= $order['order_id'] ?></td>
                            <td><?= date('M j, Y', strtotime($order['created_at'])) ?></td>
                            <td>$<?= number_format($order['total'], 2) ?></td>
                            <td><?= ucfirst($order['status']) ?></td>
                            <td><a href="/user/orders.php?id=<?= $order['order_id'] ?>">View</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <a href="/user/orders.php" class="view-all">View All Orders</a>
            <?php else: ?>
                <p>You haven't placed any orders yet.</p>
                <a href="/products/cellphones.php" class="btn">Start Shopping</a>
            <?php endif; ?>
        </section>

        <section class="quick-actions">
            <h2>Quick Actions</h2>
            <div class="action-grid">
                <a href="/user/profile.php" class="action-card">
                    <i class="fas fa-user"></i>
                    <span>Edit Profile</span>
                </a>
                <a href="/user/wishlist.php" class="action-card">
                    <i class="fas fa-heart"></i>
                    <span>Wishlist</span>
                </a>
                <a href="/cart/view.php" class="action-card">
                    <i class="fas fa-shopping-cart"></i>
                    <span>View Cart</span>
                </a>
                <a href="/products/cellphones.php" class="action-card">
                    <i class="fas fa-shopping-bag"></i>
                    <span>Continue Shopping</span>
                </a>
            </div>
        </section>
    </div>
</div>
<?php
require_once '../includes/footer.php';
?>