<?php
require_once '../includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /auth/login.php");
    exit;
}

$page_title = 'My Wishlist';
$wishlist = getUserWishlist($_SESSION['user_id']);
?>
<h1>My Wishlist</h1>
<?php if (empty($wishlist)): ?>
    <p>Your wishlist is empty.</p>
<?php else: ?>
    <div class="wishlist-items">
        <?php foreach ($wishlist as $item): ?>
        <div class="wishlist-item">
            <a href="/products/view.php?id=<?= $item['product_id'] ?>">
                <h3><?= htmlspecialchars($item['name']) ?></h3>
                <p>Price: $<?= number_format($item['price'], 2) ?></p>
            </a>
            <form action="/wishlist/remove.php" method="post">
                <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                <button type="submit">Remove</button>
            </form>
        </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
<?php
require_once '../includes/footer.php';
?>