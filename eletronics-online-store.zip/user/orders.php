<?php
require_once '../includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /auth/login.php");
    exit;
}

$page_title = 'My Orders';
$orders = getUserOrders($_SESSION['user_id']);
?>
<h1>My Orders</h1>
<?php if (empty($orders)): ?>
    <p>You haven't placed any orders yet.</p>
<?php else: ?>
    <table class="order-table">
        <thead>
            <tr>
                <th>Order #</th>
                <th>Date</th>
                <th>Total</th>
                <th>Status</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($orders as $order): ?>
            <tr>
                <td><?= $order['order_id'] ?></td>
                <td><?= date('M j, Y', strtotime($order['created_at'])) ?></td>
                <td>$<?= number_format($order['total'], 2) ?></td>
                <td><?= ucfirst($order['status']) ?></td>
                <td><a href="/order/details.php?id=<?= $order['order_id'] ?>">View</a></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
<?php
require_once '../includes/footer.php';
?>