<?php
require_once 'includes/header.php';

// Get featured products
$featuredProducts = [];
$categoryProducts = [];

try {
    // Featured products
    $stmt = $pdo->query("SELECT * FROM products WHERE featured = 1 ORDER BY created_at DESC LIMIT 8");
    $featuredProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Products by category (for category preview)
    $stmt = $pdo->query("
        SELECT p.* 
        FROM products p
        JOIN (
            SELECT category, MAX(created_at) as latest
            FROM products
            GROUP BY category
        ) latest_products
        ON p.category = latest_products.category AND p.created_at = latest_products.latest
    ");
    $categoryProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $error = "Error loading products";
}
?>

<style>
/* Main Layout */
.homepage {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 20px;
}

/* Hero Section */
.hero {
    background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
    color: white;
    padding: 80px 20px;
    text-align: center;
    border-radius: 8px;
    margin-bottom: 40px;
    position: relative;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.hero::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><path fill="rgba(255,255,255,0.05)" d="M0,0 L100,0 L100,100 L0,100 Z" /></svg>');
    background-size: cover;
}

.hero-content {
    position: relative;
    z-index: 1;
    max-width: 800px;
    margin: 0 auto;
}

.hero h1 {
    font-size: 3rem;
    margin-bottom: 20px;
    font-weight: 700;
    text-shadow: 0 2px 4px rgba(0,0,0,0.2);
}

.hero p {
    font-size: 1.2rem;
    margin-bottom: 30px;
    opacity: 0.9;
}

/* Buttons */
.btn {
    display: inline-block;
    padding: 12px 24px;
    border-radius: 4px;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
    cursor: pointer;
}

.btn-primary {
    background-color: #ff6b6b;
    color: white;
    border: 2px solid #ff6b6b;
}

.btn-primary:hover {
    background-color: #ff5252;
    border-color: #ff5252;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(255, 107, 107, 0.3);
}

/* Product Grid */
.product-grid, .category-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 30px;
    margin: 30px 0;
}

.product-card {
    background: white;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
    display: flex;
    flex-direction: column;
    position: relative;
}

.product-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
}

.product-image {
    height: 200px;
    position: relative;
    overflow: hidden;
    background: #f8f9fa;
    cursor: pointer;
}

.product-image img {
    width: 100%;
    height: 100%;
    object-fit: contain;
    padding: 20px;
    transition: transform 0.3s ease;
}

.product-card:hover .product-image img {
    transform: scale(1.05);
}

.no-image {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    color: #999;
}

.product-info {
    padding: 20px;
    flex-grow: 1;
}

.product-info h3 {
    margin: 0 0 10px;
    font-size: 1.1rem;
    color: #333;
}

.price {
    font-size: 1.2rem;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 10px;
}

.old-price {
    text-decoration: line-through;
    color: #999;
    font-size: 0.9rem;
    margin-right: 5px;
}

.discount-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    background: #ff6b6b;
    color: white;
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 0.8rem;
    font-weight: bold;
    z-index: 2;
}

.category-badge {
    display: inline-block;
    padding: 4px 8px;
    background: #f1f1f1;
    border-radius: 4px;
    font-size: 0.8rem;
    color: #666;
}

.add-to-cart {
    width: 100%;
    padding: 12px;
    background: #2c3e50;
    color: white;
    border: none;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s ease;
}

.add-to-cart:hover {
    background: #1a252f;
}

.add-to-cart.added {
    background: #4CAF50;
}

/* Category Showcase */
.category-showcase {
    margin: 60px 0;
}

.category-showcase h2, .featured-products h2 {
    text-align: center;
    margin-bottom: 30px;
    font-size: 2rem;
    color: #2c3e50;
    position: relative;
}

.category-showcase h2::after, .featured-products h2::after {
    content: '';
    display: block;
    width: 80px;
    height: 4px;
    background: #ff6b6b;
    margin: 15px auto 0;
    border-radius: 2px;
}

.category-card {
    position: relative;
    border-radius: 8px;
    overflow: hidden;
    height: 200px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
}

.category-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
}

.category-card img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.category-card:hover img {
    transform: scale(1.05);
}

.category-placeholder {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    background: #f8f9fa;
    color: #666;
    font-size: 1.2rem;
    font-weight: 600;
}

.category-card h3 {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0,0,0,0.7);
    color: white;
    padding: 15px;
    margin: 0;
    text-align: center;
    font-size: 1.2rem;
}

/* Benefits Section */
.benefits {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 30px;
    margin: 60px 0;
    padding: 40px 0;
    border-top: 1px solid #eee;
    border-bottom: 1px solid #eee;
}

.benefit {
    text-align: center;
    padding: 20px;
}

.benefit i {
    font-size: 2.5rem;
    color: #ff6b6b;
    margin-bottom: 20px;
}

.benefit h3 {
    font-size: 1.2rem;
    color: #2c3e50;
    margin-bottom: 10px;
}

.benefit p {
    color: #666;
    margin: 0;
}

/* Alert */
.alert {
    padding: 15px;
    border-radius: 4px;
    margin: 20px 0;
}

.alert-danger {
    background: #ffebee;
    color: #c62828;
    border-left: 4px solid #c62828;
}

/* Image Modal */
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.9);
    overflow: auto;
}

.modal-content {
    margin: auto;
    display: block;
    max-width: 90%;
    max-height: 90%;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}

.close {
    position: absolute;
    top: 20px;
    right: 35px;
    color: #f1f1f1;
    font-size: 40px;
    font-weight: bold;
    transition: 0.3s;
    cursor: pointer;
}

.close:hover {
    color: #ff6b6b;
}

/* Product Carousel */
.carousel {
    position: relative;
    overflow: hidden;
}

.carousel-inner {
    display: flex;
    transition: transform 0.5s ease;
}

.carousel-item {
    min-width: 100%;
}

.carousel-control {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: rgba(0,0,0,0.5);
    color: white;
    border: none;
    padding: 10px 15px;
    cursor: pointer;
    z-index: 10;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s;
}

.carousel-control:hover {
    background: rgba(0,0,0,0.8);
}

.carousel-control.prev {
    left: 15px;
}

.carousel-control.next {
    right: 15px;
}

.carousel-indicators {
    display: flex;
    justify-content: center;
    margin-top: 15px;
}

.carousel-indicator {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #ccc;
    margin: 0 5px;
    cursor: pointer;
    transition: background 0.3s;
}

.carousel-indicator.active {
    background: #ff6b6b;
}

/* Responsive Design */
@media (max-width: 768px) {
    .hero h1 {
        font-size: 2rem;
    }
    
    .product-grid, .category-grid {
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    }
    
    .benefits {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 480px) {
    .hero {
        padding: 60px 20px;
    }
    
    .product-grid, .category-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<main class="homepage">
    <section class="hero">
        <div class="hero-content">
            <h1>Welcome to <?= SITE_NAME ?></h1>
            <p>Your one-stop shop for the latest electronics and gadgets</p>
            <a href="/products/cellphones.php" class="btn btn-primary">Shop Now</a>
        </div>
    </section>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <section class="featured-products">
        <h2>Featured Products</h2>
        <div class="carousel">
            <div class="carousel-inner">
                <?php 
                // Split featured products into chunks of 4 for carousel slides
                $chunks = array_chunk($featuredProducts, 4);
                foreach ($chunks as $chunk): ?>
                <div class="carousel-item">
                    <div class="product-grid">
                        <?php foreach ($chunk as $product): ?>
                            <div class="product-card">
                                <?php if (isset($product['discount']) && $product['discount'] > 0): ?>
                                    <div class="discount-badge">-<?= $product['discount'] ?>%</div>
                                <?php endif; ?>
                                <a href="/products/view.php?id=<?= $product['product_id'] ?>">
                                    <div class="product-image">
                                        <?php if ($product['image_main']): ?>
                                            <img src="/assets/images/products/<?= htmlspecialchars($product['image_main']) ?>" 
                                                 alt="<?= htmlspecialchars($product['name']) ?>"
                                                 data-product-id="<?= $product['product_id'] ?>">
                                        <?php else: ?>
                                            <div class="no-image">No Image</div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="product-info">
                                        <h3><?= htmlspecialchars($product['name']) ?></h3>
                                        <div class="price">
                                               <?php if (isset($product['discount']) && $product['discount'] > 0): ?>
                                                <span class="old-price">$<?= number_format($product['price'], 2) ?></span>
                                                $<?= number_format($product['price'] * (1 - $product['discount']/100), 2) ?>
                                            <?php else: ?>
                                                $<?= number_format($product['price'], 2) ?>
                                            <?php endif; ?>
                                        </div>
                                        <div class="category-badge"><?= ucfirst($product['category']) ?></div>
                                    </div>
                                </a>
                                <button class="add-to-cart" data-product-id="<?= $product['product_id'] ?>">Add to Cart</button>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <button class="carousel-control prev" aria-label="Previous slide">&#10094;</button>
            <button class="carousel-control next" aria-label="Next slide">&#10095;</button>
            <div class="carousel-indicators">
                <?php for ($i = 0; $i < count($chunks); $i++): ?>
                    <div class="carousel-indicator <?= $i === 0 ? 'active' : '' ?>" data-slide-to="<?= $i ?>"></div>
                <?php endfor; ?>
            </div>
        </div>
    </section>

    <section class="category-showcase">
        <h2>Shop by Category</h2>
        <div class="category-grid">
            <?php 
            $categories = [
                'cellphone' => 'Cellphones',
                'computer' => 'Computers',
                'accessory' => 'Accessories',
                'audio' => 'Audio',
                'gaming' => 'Gaming',
                'smart-home' => 'Smart Home'
            ];
            
            foreach ($categories as $slug => $name): 
                $categoryProduct = array_filter($categoryProducts, function($p) use ($slug) {
                    return $p['category'] === $slug;
                });
                $categoryProduct = reset($categoryProduct);
            ?>
                <div class="category-card">
                    <a href="/products/<?= $slug ?>s.php">
                        <?php if ($categoryProduct && $categoryProduct['image_main']): ?>
                            <img src="/assets/images/products/<?= htmlspecialchars($categoryProduct['image_main']) ?>" alt="<?= $name ?>">
                        <?php else: ?>
                            <div class="category-placeholder"><?= $name ?></div>
                        <?php endif; ?>
                        <h3><?= $name ?></h3>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="benefits">
        <div class="benefit">
            <i class="fas fa-shipping-fast"></i>
            <h3>Free Shipping</h3>
            <p>On all orders over $50</p>
        </div>
        <div class="benefit">
            <i class="fas fa-undo"></i>
            <h3>30-Day Returns</h3>
            <p>No questions asked</p>
        </div>
        <div class="benefit">
            <i class="fas fa-lock"></i>
            <h3>Secure Payment</h3>
            <p>100% secure checkout</p>
        </div>
        <div class="benefit">
            <i class="fas fa-headset"></i>
            <h3>24/7 Support</h3>
            <p>Dedicated support</p>
        </div>
    </section>
</main>

<!-- Image Modal -->
<div id="imageModal" class="modal">
    <span class="close">&times;</span>
    <img class="modal-content" id="modalImage">
    <div id="caption"></div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Image Modal functionality
    const modal = document.getElementById('imageModal');
    const modalImg = document.getElementById('modalImage');
    const captionText = document.getElementById('caption');
    const closeBtn = document.querySelector('.close');
    
    // Get all product images and add click event
    document.querySelectorAll('.product-image img').forEach(img => {
        img.addEventListener('click', function() {
            modal.style.display = 'block';
            modalImg.src = this.src;
            captionText.innerHTML = this.alt;
        });
    });
    
    // Close modal when clicking X
    closeBtn.addEventListener('click', function() {
        modal.style.display = 'none';
    });
    
    // Close modal when clicking outside image
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });
    
    // Add to cart functionality
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', async function() {
            const productId = this.getAttribute('data-product-id');
            const button = this;
            
            // Visual feedback
            button.textContent = 'Adding...';
            button.classList.add('adding');
            
            try {
                // Simulate API call (replace with actual fetch)
                // In a real app, you would make an AJAX call here:
                /*
                const response = await fetch('/api/add-to-cart', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ product_id: productId })
                });
                
                const data = await response.json();
                */
                
                // Simulate response delay
                await new Promise(resolve => setTimeout(resolve, 500));
                
                // Success feedback
                button.textContent = 'Added to Cart!';
                button.classList.remove('adding');
                button.classList.add('added');
                
                // Update cart count in header (if exists)
                const cartCount = document.querySelector('.cart-count');
                if (cartCount) {
                    const currentCount = parseInt(cartCount.textContent) || 0;
                    cartCount.textContent = currentCount + 1;
                    cartCount.classList.add('pulse');
                    setTimeout(() => cartCount.classList.remove('pulse'), 500);
                }
                
                // Reset button after delay
                setTimeout(() => {
                    button.textContent = 'Add to Cart';
                    button.classList.remove('added');
                }, 2000);
                
            } catch (error) {
                console.error('Error:', error);
                button.textContent = 'Error Adding';
                setTimeout(() => {
                    button.textContent = 'Add to Cart';
                    button.classList.remove('adding');
                }, 2000);
            }
        });
    });
    
    // Carousel functionality
    const carousel = document.querySelector('.carousel');
    if (carousel) {
        const inner = carousel.querySelector('.carousel-inner');
        const items = carousel.querySelectorAll('.carousel-item');
        const prevBtn = carousel.querySelector('.prev');
        const nextBtn = carousel.querySelector('.next');
        const indicators = carousel.querySelectorAll('.carousel-indicator');
        
        let currentIndex = 0;
        const itemCount = items.length;
        
        function updateCarousel() {
            inner.style.transform = `translateX(-${currentIndex * 100}%)`;
            
            // Update indicators
            indicators.forEach((indicator, index) => {
                indicator.classList.toggle('active', index === currentIndex);
            });
        }
        
        prevBtn.addEventListener('click', () => {
            currentIndex = (currentIndex > 0) ? currentIndex - 1 : itemCount - 1;
            updateCarousel();
        });
        
        nextBtn.addEventListener('click', () => {
            currentIndex = (currentIndex < itemCount - 1) ? currentIndex + 1 : 0;
            updateCarousel();
        });
        
        // Indicator click
        indicators.forEach((indicator, index) => {
            indicator.addEventListener('click', () => {
                currentIndex = index;
                updateCarousel();
            });
        });
        
        // Auto-advance carousel
        let carouselInterval = setInterval(() => {
            currentIndex = (currentIndex < itemCount - 1) ? currentIndex + 1 : 0;
            updateCarousel();
        }, 5000);
        
        // Pause on hover
        carousel.addEventListener('mouseenter', () => {
            clearInterval(carouselInterval);
        });
        
        carousel.addEventListener('mouseleave', () => {
            carouselInterval = setInterval(() => {
                currentIndex = (currentIndex < itemCount - 1) ? currentIndex + 1 : 0;
                updateCarousel();
            }, 5000);
        });
    }
    
    // Animate elements when they come into view
    const animateOnScroll = () => {
        const elements = document.querySelectorAll('.product-card, .category-card, .benefit');
        
        elements.forEach(element => {
            const elementPosition = element.getBoundingClientRect().top;
            const screenPosition = window.innerHeight / 1.2;
            
            if (elementPosition < screenPosition) {
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }
        });
    };
    
    // Set initial state for animation
    document.querySelectorAll('.product-card, .category-card, .benefit').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    });
    
    // Run once on load
    animateOnScroll();
    
    // Run on scroll
    window.addEventListener('scroll', animateOnScroll);
    
    // Keyboard navigation for modal
    document.addEventListener('keydown', function(e) {
        if (modal.style.display === 'block') {
            if (e.key === 'Escape') {
                modal.style.display = 'none';
            } else if (e.key === 'ArrowRight') {
                // Next image logic could be added here
            } else if (e.key === 'ArrowLeft') {
                // Previous image logic could be added here
            }
        }
    });
});
</script>

<?php
require_once 'includes/footer.php';
?>