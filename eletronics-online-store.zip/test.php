<?php
require_once 'includes/header.php';

// Get featured products
$featuredProducts = [];
$categoryProducts = [];

try {
    // Featured products with category names
    $stmt = $pdo->query("
        SELECT p.*, c.name as category_name, c.slug as category_slug
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.category_id 
        WHERE p.featured = 1 AND p.status = 'active' 
        ORDER BY p.created_at DESC 
        LIMIT 8
    ");
    $featuredProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Products by category (for category preview)
    $stmt = $pdo->query("
        SELECT p.*, c.name as category_name, c.slug as category_slug
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.category_id
        WHERE p.status = 'active'
        ORDER BY p.created_at DESC
    ");
    $allProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Group by category and get latest product for each
    $categoryProducts = [];
    foreach ($allProducts as $product) {
        if (!isset($categoryProducts[$product['category_slug']])) {
            $categoryProducts[$product['category_slug']] = $product;
        }
    }
    
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $error = "Error loading products";
}

// Helper function to get first image from JSON
function getFirstImage($imagesJson) {
    if (empty($imagesJson)) return null;
    $images = json_decode($imagesJson, true);
    return is_array($images) && !empty($images) ? $images[0] : null;
}

// Helper function to calculate discount percentage
function getDiscountPercentage($originalPrice, $discountPrice) {
    if (!$discountPrice || $discountPrice >= $originalPrice) return 0;
    return round((($originalPrice - $discountPrice) / $originalPrice) * 100);
}
?>

<style>
/* Enhanced Modern CSS with Advanced Styling */
:root {
    /* Primary Colors */
    --primary-50: #eff6ff;
    --primary-100: #dbeafe;
    --primary-200: #bfdbfe;
    --primary-300: #93c5fd;
    --primary-400: #60a5fa;
    --primary-500: #3b82f6;
    --primary-600: #2563eb;
    --primary-700: #1d4ed8;
    --primary-800: #1e40af;
    --primary-900: #1e3a8a;
    
    /* Secondary Colors */
    --secondary-50: #fff7ed;
    --secondary-100: #ffedd5;
    --secondary-200: #fed7aa;
    --secondary-300: #fdba74;
    --secondary-400: #fb923c;
    --secondary-500: #f97316;
    --secondary-600: #ea580c;
    --secondary-700: #c2410c;
    --secondary-800: #9a3412;
    --secondary-900: #7c2d12;
    
    /* Neutral Colors */
    --gray-50: #f8fafc;
    --gray-100: #f1f5f9;
    --gray-200: #e2e8f0;
    --gray-300: #cbd5e1;
    --gray-400: #94a3b8;
    --gray-500: #64748b;
    --gray-600: #475569;
    --gray-700: #334155;
    --gray-800: #1e293b;
    --gray-900: #0f172a;
    
    /* Status Colors */
    --success-500: #10b981;
    --success-600: #059669;
    --danger-500: #ef4444;
    --danger-600: #dc2626;
    --warning-500: #f59e0b;
    --warning-600: #d97706;
    
    /* Shadows */
    --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
    --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
    --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
    --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
    --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
    --shadow-2xl: 0 25px 50px -12px rgb(0 0 0 / 0.25);
    
    /* Animation Variables */
    --transition-fast: 150ms;
    --transition-normal: 300ms;
    --transition-slow: 500ms;
    --bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55);
    --ease-out: cubic-bezier(0.0, 0.0, 0.2, 1);
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

*::before,
*::after {
    box-sizing: border-box;
}

body {
    font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    line-height: 1.6;
    color: var(--gray-800);
    background: linear-gradient(135deg, var(--gray-50) 0%, var(--primary-50) 100%);
    min-height: 100vh;
    font-feature-settings: 'kern' 1, 'liga' 1;
    text-rendering: optimizeLegibility;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

.container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 2rem;
}

/* Enhanced Hero Section */
.hero {
    position: relative;
    height: 70vh;
    min-height: 600px;
    border-radius: 1.5rem;
    margin: 2rem 0 5rem;
    overflow: hidden;
    display: flex;
    align-items: center;
    box-shadow: var(--shadow-2xl);
    background: linear-gradient(135deg, var(--primary-600), var(--primary-800));
    isolation: isolate;
}

.hero::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(
        135deg,
        rgba(0, 0, 0, 0.8) 0%,
        rgba(0, 0, 0, 0.6) 30%,
        rgba(0, 0, 0, 0.4) 60%,
        rgba(0, 0, 0, 0.2) 100%
    );
    z-index: 1;
}

.hero-bg {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform var(--transition-slow) var(--ease-out);
    z-index: 0;
}

.hero:hover .hero-bg {
    transform: scale(1.05);
}

.hero-content {
    position: relative;
    z-index: 2;
    max-width: 650px;
    padding: 0 3rem;
    color: white;
    animation: fadeInUp 1s var(--ease-out);
}

.hero h1 {
    font-size: clamp(2.5rem, 6vw, 4rem);
    font-weight: 900;
    margin-bottom: 1.5rem;
    line-height: 1.1;
    letter-spacing: -0.02em;
    background: linear-gradient(135deg, #ffffff 0%, #f1f5f9 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.hero p {
    font-size: 1.25rem;
    margin-bottom: 2.5rem;
    opacity: 0.95;
    font-weight: 400;
    line-height: 1.6;
}

/* Enhanced Button Styles */
.btn {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 1rem 2.5rem;
    border-radius: 0.75rem;
    font-weight: 600;
    font-size: 1rem;
    text-decoration: none;
    transition: all var(--transition-normal) var(--ease-out);
    cursor: pointer;
    border: none;
    position: relative;
    overflow: hidden;
    backdrop-filter: blur(10px);
}

.btn::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(255, 255, 255, 0.2), rgba(255, 255, 255, 0.1));
    border-radius: inherit;
    transition: opacity var(--transition-normal);
    opacity: 0;
}

.btn:hover::before {
    opacity: 1;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
    color: white;
    box-shadow: var(--shadow-lg);
}

.btn-primary:hover {
    background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
    transform: translateY(-2px) scale(1.02);
    box-shadow: var(--shadow-xl);
}

.btn-primary:active {
    transform: translateY(-1px) scale(1.01);
}

/* Enhanced Section Styles */
.section {
    margin: 6rem 0;
    position: relative;
}

.section-title {
    font-size: clamp(2rem, 4vw, 3rem);
    font-weight: 800;
    margin-bottom: 4rem;
    text-align: center;
    position: relative;
    color: var(--gray-900);
    letter-spacing: -0.02em;
}

.section-title::after {
    content: '';
    display: block;
    width: 100px;
    height: 5px;
    background: linear-gradient(135deg, var(--primary-500), var(--secondary-500));
    margin: 1.5rem auto 0;
    border-radius: 2.5px;
    box-shadow: var(--shadow-md);
}

/* Advanced Product Grid */
.product-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 2rem;
    perspective: 1000px;
}

.product-card {
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 1.5rem;
    overflow: hidden;
    box-shadow: var(--shadow-lg);
    transition: all var(--transition-normal) var(--ease-out);
    position: relative;
    cursor: pointer;
    transform-style: preserve-3d;
}

.product-card::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.05), rgba(249, 115, 22, 0.05));
    opacity: 0;
    transition: opacity var(--transition-normal);
    border-radius: inherit;
}

.product-card:hover {
    transform: translateY(-8px) rotateX(2deg);
    box-shadow: var(--shadow-2xl);
    border-color: rgba(59, 130, 246, 0.3);
}

.product-card:hover::before {
    opacity: 1;
}

.product-image {
    height: 280px;
    background: linear-gradient(135deg, var(--gray-50), var(--gray-100));
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 1.5rem;
    position: relative;
    overflow: hidden;
}

.product-image::before {
    content: '';
    position: absolute;
    inset: 0;
    background: radial-gradient(circle at center, rgba(59, 130, 246, 0.1) 0%, transparent 70%);
    opacity: 0;
    transition: opacity var(--transition-normal);
}

.product-card:hover .product-image::before {
    opacity: 1;
}

.product-image img {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
    transition: all var(--transition-slow) var(--ease-out);
    filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1));
}

.product-card:hover .product-image img {
    transform: scale(1.1) rotateY(-5deg);
}

.product-info {
    padding: 2rem;
    position: relative;
}

.product-info h3 {
    font-size: 1.375rem;
    font-weight: 700;
    margin-bottom: 1rem;
    color: var(--gray-900);
    line-height: 1.3;
    transition: color var(--transition-normal);
}

.product-card:hover .product-info h3 {
    color: var(--primary-600);
}

.price {
    font-size: 1.75rem;
    font-weight: 800;
    margin-bottom: 1.5rem;
    color: var(--gray-900);
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.old-price {
    text-decoration: line-through;
    color: var(--gray-400);
    font-size: 1.125rem;
    font-weight: 500;
}

.discount-badge {
    position: absolute;
    top: 1.5rem;
    right: 1.5rem;
    background: linear-gradient(135deg, var(--danger-500), var(--danger-600));
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 9999px;
    font-size: 0.875rem;
    font-weight: 700;
    box-shadow: var(--shadow-md);
    animation: pulse 2s infinite;
    z-index: 10;
}

.category-badge {
    display: inline-flex;
    align-items: center;
    padding: 0.5rem 1rem;
    background: linear-gradient(135deg, var(--primary-50), var(--primary-100));
    color: var(--primary-700);
    border-radius: 9999px;
    font-size: 0.875rem;
    font-weight: 600;
    margin-bottom: 1.5rem;
    border: 1px solid var(--primary-200);
    transition: all var(--transition-normal);
}

.product-card:hover .category-badge {
    background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
    color: white;
    transform: scale(1.05);
}

.add-to-cart {
    width: 100%;
    padding: 1rem;
    background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
    color: white;
    border: none;
    border-radius: 0.75rem;
    font-weight: 700;
    font-size: 1rem;
    cursor: pointer;
    transition: all var(--transition-normal) var(--ease-out);
    margin-top: 1rem;
    position: relative;
    overflow: hidden;
}

.add-to-cart::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(255, 255, 255, 0.2), rgba(255, 255, 255, 0.1));
    opacity: 0;
    transition: opacity var(--transition-normal);
}

.add-to-cart:hover {
    background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
    transform: translateY(-2px);
    box-shadow: var(--shadow-xl);
}

.add-to-cart:hover::before {
    opacity: 1;
}

.add-to-cart:active {
    transform: translateY(-1px);
}

/* Enhanced Category Grid */
.category-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 2rem;
}

.category-card {
    position: relative;
    height: 350px;
    border-radius: 1.5rem;
    overflow: hidden;
    box-shadow: var(--shadow-xl);
    transition: all var(--transition-normal) var(--ease-out);
    cursor: pointer;
    background: linear-gradient(135deg, var(--gray-800), var(--gray-900));
}

.category-card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: var(--shadow-2xl);
}

.category-card img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: all var(--transition-slow) var(--ease-out);
    filter: brightness(0.8) contrast(1.1);
}

.category-card:hover img {
    transform: scale(1.15);
    filter: brightness(0.6) contrast(1.2);
}

.category-card h3 {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 2rem;
    background: linear-gradient(
        to top,
        rgba(0, 0, 0, 0.9) 0%,
        rgba(0, 0, 0, 0.7) 50%,
        transparent 100%
    );
    color: white;
    font-size: 1.75rem;
    font-weight: 800;
    letter-spacing: -0.01em;
    transition: all var(--transition-normal);
    backdrop-filter: blur(10px);
}

.category-card:hover h3 {
    transform: translateY(-5px);
    color: var(--primary-300);
}

/* Enhanced Benefits Section */
.benefits {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 2rem;
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(20px);
    padding: 4rem 3rem;
    border-radius: 1.5rem;
    box-shadow: var(--shadow-xl);
    border: 1px solid rgba(255, 255, 255, 0.2);
    position: relative;
    overflow: hidden;
}

.benefits::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.03), rgba(249, 115, 22, 0.03));
    pointer-events: none;
}

.benefit {
    text-align: center;
    padding: 2rem 1rem;
    position: relative;
    transition: all var(--transition-normal) var(--ease-out);
    border-radius: 1rem;
}

.benefit:hover {
    transform: translateY(-5px);
    background: rgba(59, 130, 246, 0.05);
    box-shadow: var(--shadow-lg);
}

.benefit i {
    font-size: 3rem;
    background: linear-gradient(135deg, var(--primary-500), var(--secondary-500));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 1.5rem;
    transition: all var(--transition-normal);
    display: block;
}

.benefit:hover i {
    transform: scale(1.2) rotateY(10deg);
    filter: drop-shadow(0 4px 8px rgba(59, 130, 246, 0.3));
}

.benefit h3 {
    font-size: 1.375rem;
    font-weight: 700;
    margin-bottom: 0.75rem;
    color: var(--gray-900);
    transition: color var(--transition-normal);
}

.benefit:hover h3 {
    color: var(--primary-600);
}

.benefit p {
    color: var(--gray-600);
    font-weight: 500;
    line-height: 1.6;
}

/* Loading States */
.loading {
    position: relative;
    overflow: hidden;
}

.loading::after {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(255, 255, 255, 0.6),
        transparent
    );
    animation: shimmer 1.5s infinite;
}

/* Animations */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(2rem);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes pulse {
    0%, 100% {
        transform: scale(1);
    }
    50% {
        transform: scale(1.05);
    }
}

@keyframes shimmer {
    0% {
        left: -100%;
    }
    100% {
        left: 100%;
    }
}

@keyframes bounce {
    0%, 20%, 53%, 80%, 100% {
        transform: scale(1);
    }
    40%, 43% {
        transform: scale(1.1);
    }
}

.animate-bounce {
    animation: bounce 1s ease-in-out;
}

/* Enhanced Responsive Design */
@media (max-width: 1200px) {
    .container {
        padding: 0 1.5rem;
    }
    
    .product-grid {
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    }
    
    .category-grid {
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    }
}

@media (max-width: 768px) {
    .hero {
        height: 60vh;
        min-height: 500px;
        margin: 1rem 0 4rem;
        border-radius: 1rem;
    }
    
    .hero-content {
        padding: 0 2rem;
    }
    
    .section {
        margin: 4rem 0;
    }
    
    .section-title {
        margin-bottom: 3rem;
    }
    
    .product-grid, .category-grid {
        grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
        gap: 1.5rem;
    }
    
    .benefits {
        padding: 3rem 2rem;
        gap: 1.5rem;
    }
    
    .product-info {
        padding: 1.5rem;
    }
}

@media (max-width: 480px) {
    .container {
        padding: 0 1rem;
    }
    
    .hero {
        height: 50vh;
        min-height: 400px;
        border-radius: 0.75rem;
    }
    
    .hero-content {
        padding: 0 1.5rem;
    }
    
    .section {
        margin: 3rem 0;
    }
    
    .benefits {
        grid-template-columns: 1fr;
        padding: 2rem 1.5rem;
    }
    
    .product-grid, .category-grid {
        grid-template-columns: 1fr;
    }
    
    .category-card {
        height: 300px;
    }
}

/* Performance Optimizations */
@media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
    }
}

/* High contrast mode support */
@media (prefers-contrast: high) {
    .product-card,
    .category-card,
    .benefits {
        border: 2px solid var(--gray-800);
    }
}
</style>

<main class="container">
    <!-- Enhanced Hero Banner -->
    <section class="hero">
        <img src="/assets/images/banner.jpg" alt="Electronics Banner" class="hero-bg">
        <div class="hero-content">
            <h1>Discover the Latest Tech at <?= SITE_NAME ?></h1>
            <p>Premium electronics, unbeatable prices, and exceptional service that exceeds expectations</p>
            <a href="/products/cellphones.php" class="btn btn-primary">
                <span>Shop Now</span>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="m9 18 6-6-6-6"/>
                </svg>
            </a>
        </div>
    </section>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger" style="padding: 1rem; background: var(--danger-50); color: var(--danger-700); border-radius: 0.75rem; border: 1px solid var(--danger-200); margin-bottom: 2rem;">
            <?= $error ?>
        </div>
    <?php endif; ?>

    <!-- Enhanced Featured Products -->
    <section class="section">
        <h2 class="section-title">Featured Products</h2>
        <div class="product-grid">
            <?php foreach ($featuredProducts as $product): ?>
                <?php 
                $firstImage = getFirstImage($product['images']);
                $discountPercentage = getDiscountPercentage($product['price'], $product['discount_price']);
                $finalPrice = $product['discount_price'] ?: $product['price'];
                ?>
                <div class="product-card" data-aos="fade-up">
                    <?php if ($discountPercentage > 0): ?>
                        <div class="discount-badge">-<?= $discountPercentage ?>%</div>
                    <?php endif; ?>
                    <a href="/products/view.php?id=<?= $product['product_id'] ?>" style="text-decoration: none; color: inherit;">
                        <div class="product-image">
                            <?php if ($firstImage): ?>
                                <img src="/assets/images/products/<?= htmlspecialchars($firstImage) ?>" 
                                     alt="<?= htmlspecialchars($product['name']) ?>"
                                     loading="lazy"
                                     onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                                <div class="no-image" style="display: none; align-items: center; justify-content: center; color: var(--gray-500); font-weight: 500;">
                                    No Image Available
                                </div>
                            <?php else: ?>
                                <div class="no-image" style="display: flex; align-items: center; justify-content: center; color: var(--gray-500); font-weight: 500;">
                                    No Image Available
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="product-info">
                            <div class="category-badge"><?= ucfirst($product['category_name'] ?: 'Electronics') ?></div>
                            <h3><?= htmlspecialchars($product['name']) ?></h3>
                            <div class="price">
                                <span>$<?= number_format($finalPrice, 2) ?></span>
                                <?php if ($discountPercentage > 0): ?>
                                    <span class="old-price">$<?= number_format($product['price'], 2) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                    <button class="add-to-cart" data-product-id="<?= $product['product_id'] ?>">
                        <span class="button-text">Add to Cart</span>
                    </button>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Enhanced Category Showcase -->
    <section class="section">
        <h2 class="section-title">Shop by Category</h2>
        <div class="category-grid">
            <?php 
            $categories = [
                'smartphones' => ['name' => 'Smartphones', 'image' => '/assets/images/categories/phones.jpg'],
                'laptops' => ['name' => 'Laptops', 'image' => '/assets/images/categories/laptops.jpg'],
                'tablets' => ['name' => 'Tablets', 'image' => '/assets/images/categories/tablets.jpg'],
                'audio' => ['name' => 'Audio', 'image' => '/assets/images/categories/audio.jpg'],
                'gaming' => ['name' => 'Gaming', 'image' => '/assets/images/categories/gaming.jpg'],
                'accessories' => ['name' => 'Accessories', 'image' => '/assets/images/categories/accessories.jpg']
            ];
            
            foreach ($categories as $slug => $category): 
                $categoryProduct = $categoryProducts[$slug] ?? null;
            ?>
                <div class="category-card" data-aos="fade-up">
                    <a href="/products/<?= $slug ?>.php" style="text-decoration: none; color: inherit;">
                        <?php if ($categoryProduct && getFirstImage($categoryProduct['images'])): ?>
                            <img src="/assets/images/products/<?= htmlspecialchars(getFirstImage($categoryProduct['images'])) ?>" 
                                 alt="<?= $category['name'] ?>"
                                 loading="lazy">
                        <?php else: ?>
                            <img src="<?= $category['image'] ?>" alt="<?= $category['name'] ?>" loading="lazy">
                        <?php endif; ?>
                        <h3><?= $category['name'] ?></h3>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Enhanced Benefits Section -->
    <section class="section">
        <div class="benefits">
            <div class="benefit" data-aos="fade-up" data-aos-delay="100">
                <i class="fas fa-shipping-fast"></i>
                <h3>Free Shipping</h3>
                <p>Complimentary shipping on all orders over $50 with fast delivery</p>
            </div>
            <div class="benefit" data-aos="fade-up" data-aos-delay="200">
                <i class="fas fa-undo"></i>
                <h3>Easy Returns</h3>
                <p>Hassle-free 30-day return policy with full refund guarantee</p>
            </div>
            <div class="benefit" data-aos="fade-up" data-aos-delay="300">
                <i class="fas fa-lock"></i>
                <h3>Secure Payment</h3>
                <p>Bank-level security with 256-bit SSL encryption protection</p>
            </div>
            <div class="benefit" data-aos="fade-up" data-aos-delay="400">
                <i class="fas fa-headset"></i>
                <h3>24/7 Support</h3>
                <p>Round-the-clock customer service with expert technical help</p>
            </div>
        </div>
    </section>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Enhanced add to cart functionality with improved animations
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', async function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const productId = this.getAttribute('data-product-id');
            const buttonText = this.querySelector('.button-text');
            const originalText = buttonText.textContent;
            
            // Add loading state
            this.classList.add('loading');
            this.disabled = true;
            buttonText.innerHTML = `
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation: spin 1s linear infinite; margin-right: 0.5rem;">
                    <path d="M21 12a9 9 0 11-6.219-8.56"/>
                </svg>
                Adding...
            `;
            
            try {
                // Simulate API call with realistic delay
                await new Promise(resolve => setTimeout(resolve, 800));
                
                // Success state
                this.style.background = 'linear-gradient(135deg, var(--success-500), var(--success-600))';
                buttonText.innerHTML = `
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 0.5rem;">
                        <polyline points="20,6 9,17 4,12"/>
                    </svg>
                    Added to Cart!
                `;
                
                // Update cart count with animation
                const cartCount = document.querySelector('.cart-count');
                if (cartCount) {
                    const currentCount = parseInt(cartCount.textContent) || 0;
                    cartCount.textContent = currentCount + 1;
                    cartCount.classList.add('animate-bounce');
                    
                    // Create floating notification
                    createFloatingNotification('Product added to cart!');
                    
                    setTimeout(() => cartCount.classList.remove('animate-bounce'), 1000);
                }
                
                // Reset button after delay
                setTimeout(() => {
                    buttonText.textContent = originalText;
                    this.style.background = '';
                    this.disabled = false;
                    this.classList.remove('loading');
                }, 2500);
                
            } catch (error) {
                console.error('Error:', error);
                
                // Error state
                this.style.background = 'linear-gradient(135deg, var(--danger-500), var(--danger-600))';
                buttonText.innerHTML = `
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 0.5rem;">
                        <circle cx="12" cy="12" r="10"/>
                        <line x1="15" y1="9" x2="9" y2="15"/>
                        <line x1="9" y1="9" x2="15" y2="15"/>
                    </svg>
                    Error - Try Again
                `;
                
                setTimeout(() => {
                    buttonText.textContent = originalText;
                    this.style.background = '';
                    this.disabled = false;
                    this.classList.remove('loading');
                }, 3000);
            }
        });
    });
    
    // Create floating notification system
    function createFloatingNotification(message) {
        const notification = document.createElement('div');
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 2rem;
            right: 2rem;
            background: linear-gradient(135deg, var(--success-500), var(--success-600));
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 0.75rem;
            box-shadow: var(--shadow-xl);
            font-weight: 600;
            z-index: 1000;
            transform: translateX(100%);
            transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            backdrop-filter: blur(20px);
        `;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Animate out and remove
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
    
    // Enhanced scroll animations with Intersection Observer
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0) scale(1)';
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    // Apply animation to elements
    const animatedElements = document.querySelectorAll('.product-card, .category-card, .benefit');
    animatedElements.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(2rem) scale(0.95)';
        el.style.transition = `all 0.6s cubic-bezier(0.16, 1, 0.3, 1) ${index * 0.1}s`;
        observer.observe(el);
    });
    
    // Parallax effect for hero background
    function updateParallax() {
        const scrolled = window.pageYOffset;
        const parallaxElement = document.querySelector('.hero-bg');
        if (parallaxElement) {
            const rate = scrolled * -0.5;
            parallaxElement.style.transform = `translateY(${rate}px)`;
        }
    }
    
    // Throttled scroll handler for performance
    let ticking = false;
    function requestTick() {
        if (!ticking) {
            requestAnimationFrame(updateParallax);
            ticking = true;
            setTimeout(() => ticking = false, 16);
        }
    }
    
    window.addEventListener('scroll', requestTick);
    
    // Enhanced keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Tab') {
            document.body.classList.add('keyboard-nav');
        }
    });
    
    document.addEventListener('mousedown', function() {
        document.body.classList.remove('keyboard-nav');
    });
    
    // Add CSS for keyboard navigation
    const style = document.createElement('style');
    style.textContent = `
        .keyboard-nav .product-card:focus,
        .keyboard-nav .category-card:focus,
        .keyboard-nav .btn:focus,
        .keyboard-nav .add-to-cart:focus {
            outline: 3px solid var(--primary-500);
            outline-offset: 2px;
        }
        
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
    `;
    document.head.appendChild(style);
});
</script>

<?php
require_once 'includes/footer.php';
?>