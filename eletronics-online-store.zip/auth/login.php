<?php
require_once '../includes/header.php';
$page_title = 'Login';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['is_admin'] = $user['is_admin'];
        header("Location: /user/dashboard.php");
        exit;
    } else {
        $error = "Invalid email or password";
    }
}
?>

<style>
    /* Auth Form Styles */
    .auth-container {
        min-height: calc(100vh - 140px);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 2rem 1rem;
        background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
    }

    .auth-card {
        background: white;
        border-radius: 16px;
        box-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 10px 10px -5px rgb(0 0 0 / 0.04);
        width: 100%;
        max-width: 420px;
        padding: 2.5rem;
        position: relative;
        overflow: hidden;
    }

    .auth-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, var(--primary-color), var(--primary-hover));
    }

    .auth-header {
        text-align: center;
        margin-bottom: 2rem;
    }

    .auth-logo {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
        margin-bottom: 1.5rem;
    }

    .auth-logo .logo-icon {
        width: 48px;
        height: 48px;
        background: linear-gradient(135deg, var(--primary-color), var(--primary-hover));
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 1.5rem;
    }

    .auth-logo h2 {
        color: var(--text-dark);
        font-size: 1.5rem;
        font-weight: 700;
        margin: 0;
    }

    .auth-title {
        color: var(--text-dark);
        font-size: 1.75rem;
        font-weight: 700;
        margin: 0 0 0.5rem 0;
    }

    .auth-subtitle {
        color: var(--text-light);
        font-size: 0.95rem;
        margin: 0;
    }

    /* Form Styles */
    .auth-form {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .form-label {
        color: var(--text-dark);
        font-weight: 600;
        font-size: 0.9rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .form-input {
        padding: 0.875rem 1rem;
        border: 2px solid var(--border-color);
        border-radius: 8px;
        font-size: 1rem;
        transition: all 0.2s ease;
        background: white;
        color: var(--text-dark);
    }

    .form-input:focus {
        outline: none;
        border-color: var(--primary-color);
        box-shadow: 0 0 0 3px rgb(37 99 235 / 0.1);
    }

    .form-input:hover {
        border-color: #cbd5e1;
    }

    .form-input::placeholder {
        color: var(--text-light);
    }

    /* Password wrapper */
    .password-wrapper {
        position: relative;
    }

    .password-toggle {
        position: absolute;
        right: 12px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: var(--text-light);
        cursor: pointer;
        padding: 4px;
        border-radius: 4px;
        transition: color 0.2s ease;
    }

    .password-toggle:hover {
        color: var(--primary-color);
    }

    /* Remember me and forgot password */
    .form-options {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: -0.5rem 0 0 0;
    }

    .remember-me {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-size: 0.9rem;
        color: var(--text-dark);
    }

    .remember-me input[type="checkbox"] {
        width: 16px;
        height: 16px;
        accent-color: var(--primary-color);
    }

    .forgot-password {
        color: var(--primary-color);
        text-decoration: none;
        font-size: 0.9rem;
        font-weight: 500;
        transition: color 0.2s ease;
    }

    .forgot-password:hover {
        color: var(--primary-hover);
        text-decoration: underline;
    }

    /* Submit Button */
    .auth-submit {
        background: linear-gradient(135deg, var(--primary-color), var(--primary-hover));
        color: white;
        border: none;
        padding: 1rem;
        border-radius: 8px;
        font-size: 1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        margin-top: 0.5rem;
    }

    .auth-submit:hover {
        transform: translateY(-1px);
        box-shadow: 0 10px 25px -5px rgb(37 99 235 / 0.4);
    }

    .auth-submit:active {
        transform: translateY(0);
    }

    .auth-submit:disabled {
        opacity: 0.6;
        cursor: not-allowed;
        transform: none;
    }

    /* Error/Success Messages */
    .alert {
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 0.75rem;
        font-weight: 500;
    }

    .alert-error {
        background: #fde8e8;
        color: #dc2626;
        border: 1px solid #fca5a5;
    }

    .alert-success {
        background: #d1fae5;
        color: #065f46;
        border: 1px solid #6ee7b7;
    }

    /* Auth Footer */
    .auth-footer {
        text-align: center;
        margin-top: 2rem;
        padding-top: 1.5rem;
        border-top: 1px solid var(--border-color);
    }

    .auth-footer p {
        color: var(--text-light);
        margin: 0;
        font-size: 0.9rem;
    }

    .auth-footer a {
        color: var(--primary-color);
        text-decoration: none;
        font-weight: 600;
        transition: color 0.2s ease;
    }

    .auth-footer a:hover {
        color: var(--primary-hover);
        text-decoration: underline;
    }

    /* Social Login Options */
    .social-login {
        margin: 1.5rem 0;
    }

    .divider {
        display: flex;
        align-items: center;
        margin: 1.5rem 0;
        color: var(--text-light);
        font-size: 0.9rem;
    }

    .divider::before,
    .divider::after {
        content: '';
        flex: 1;
        height: 1px;
        background: var(--border-color);
    }

    .divider span {
        padding: 0 1rem;
        background: white;
    }

    .social-btn {
        width: 100%;
        padding: 0.875rem;
        border: 2px solid var(--border-color);
        background: white;
        border-radius: 8px;
        font-size: 0.95rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
        margin-bottom: 0.75rem;
        text-decoration: none;
        color: var(--text-dark);
    }

    .social-btn:hover {
        border-color: var(--primary-color);
        background: var(--bg-light);
    }

    /* Demo Account */
    .demo-account {
        background: #f0f9ff;
        border: 1px solid #bae6fd;
        border-radius: 8px;
        padding: 1rem;
        margin-bottom: 1.5rem;
    }

    .demo-account h4 {
        color: #0369a1;
        margin: 0 0 0.5rem 0;
        font-size: 0.9rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .demo-account p {
        color: #0369a1;
        margin: 0;
        font-size: 0.85rem;
        line-height: 1.4;
    }

    .demo-account code {
        background: rgba(3, 105, 161, 0.1);
        padding: 0.2rem 0.4rem;
        border-radius: 4px;
        font-size: 0.8rem;
        color: #0369a1;
    }

    /* Mobile Responsive */
    @media (max-width: 480px) {
        .auth-container {
            padding: 1rem;
        }

        .auth-card {
            padding: 2rem 1.5rem;
        }

        .auth-title {
            font-size: 1.5rem;
        }

        .form-options {
            flex-direction: column;
            gap: 1rem;
            align-items: flex-start;
        }
    }

    /* Loading State */
    .loading {
        display: inline-block;
        width: 20px;
        height: 20px;
        border: 2px solid rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        border-top-color: white;
        animation: spin 1s ease-in-out infinite;
    }

    @keyframes spin {
        to { transform: rotate(360deg); }
    }
</style>

<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <div class="auth-logo">
                <div class="logo-icon">
                    <i class="fas fa-bolt"></i>
                </div>
                <h2><?= SITE_NAME ?></h2>
            </div>
            <h1 class="auth-title">Welcome Back</h1>
            <p class="auth-subtitle">Sign in to your account to continue shopping</p>
        </div>

        <!-- Demo Account Info -->
        <div class="demo-account">
            <h4>
                <i class="fas fa-info-circle"></i>
                Demo Account
            </h4>
            <p>
                Use <code>demo@example.com</code> with password <code>demo123</code> to test the system
            </p>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-triangle"></i>
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="post" class="auth-form" id="loginForm">
            <div class="form-group">
                <label class="form-label" for="email">
                    <i class="fas fa-envelope"></i>
                    Email Address
                </label>
                <input 
                    type="email" 
                    id="email"
                    name="email" 
                    class="form-input"
                    placeholder="Enter your email address"
                    value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label class="form-label" for="password">
                    <i class="fas fa-lock"></i>
                    Password
                </label>
                <div class="password-wrapper">
                    <input 
                        type="password" 
                        id="password"
                        name="password" 
                        class="form-input"
                        placeholder="Enter your password"
                        required
                    >
                    <button type="button" class="password-toggle" onclick="togglePassword('password')">
                        <i class="fas fa-eye" id="password-eye"></i>
                    </button>
                </div>
            </div>

            <div class="form-options">
                <label class="remember-me">
                    <input type="checkbox" name="remember_me" id="remember_me">
                    Remember me
                </label>
                <a href="forgot-password.php" class="forgot-password">
                    Forgot password?
                </a>
            </div>

            <button type="submit" class="auth-submit" id="submitBtn">
                <i class="fas fa-sign-in-alt"></i>
                Sign In
            </button>
        </form>

        <div class="divider">
            <span>or continue with</span>
        </div>

        <div class="social-login">
            <a href="#" class="social-btn">
                <i class="fab fa-google"></i>
                Continue with Google
            </a>
            <a href="#" class="social-btn">
                <i class="fab fa-facebook-f"></i>
                Continue with Facebook
            </a>
        </div>

        <div class="auth-footer">
            <p>Don't have an account? <a href="register.php">Create one here</a></p>
        </div>
    </div>
</div>

<script>
    // Password visibility toggle
    function togglePassword(fieldId) {
        const field = document.getElementById(fieldId);
        const eye = document.getElementById(fieldId + '-eye');
        
        if (field.type === 'password') {
            field.type = 'text';
            eye.classList.remove('fa-eye');
            eye.classList.add('fa-eye-slash');
        } else {
            field.type = 'password';
            eye.classList.remove('fa-eye-slash');
            eye.classList.add('fa-eye');
        }
    }

    // Form submission with loading state
    document.getElementById('loginForm').addEventListener('submit', function() {
        const submitBtn = document.getElementById('submitBtn');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<div class="loading"></div> Signing In...';
    });

    // Demo account quick fill
    function fillDemoAccount() {
        document.getElementById('email').value = 'demo@example.com';
        document.getElementById('password').value = 'demo123';
    }

    // Add click handler to demo account info
    document.querySelector('.demo-account').addEventListener('click', fillDemoAccount);
    document.querySelector('.demo-account').style.cursor = 'pointer';

    // Remember me functionality (localStorage)
    document.addEventListener('DOMContentLoaded', function() {
        const emailField = document.getElementById('email');
        const rememberCheckbox = document.getElementById('remember_me');
        
        // Load saved email if "remember me" was checked
        const savedEmail = localStorage.getItem('remembered_email');
        if (savedEmail) {
            emailField.value = savedEmail;
            rememberCheckbox.checked = true;
        }
        
        // Save/remove email based on remember me checkbox
        document.getElementById('loginForm').addEventListener('submit', function() {
            if (rememberCheckbox.checked) {
                localStorage.setItem('remembered_email', emailField.value);
            } else {
                localStorage.removeItem('remembered_email');
            }
        });
    });

    // Enhanced form validation
    document.getElementById('email').addEventListener('blur', function() {
        const email = this.value;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        if (email && !emailRegex.test(email)) {
            this.style.borderColor = '#ef4444';
        } else {
            this.style.borderColor = '';
        }
    });

    // Enter key handling for better UX
    document.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && e.target.tagName !== 'BUTTON') {
            document.getElementById('submitBtn').click();
        }
    });
</script>

<?php
require_once '../includes/footer.php';
?>