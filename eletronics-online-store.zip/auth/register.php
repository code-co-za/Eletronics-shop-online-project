<?php
require_once '../includes/header.php';
$page_title = 'Register';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    
    if ($password !== $confirm) {
        $error = "Passwords don't match";
    } else {
        $stmt = $pdo->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        if ($stmt->execute([$email, $hashed])) {
            header("Location: login.php");
            exit;
        } else {
            $error = "Registration failed";
        }
    }
}
?>

<style>
    /* Auth Form Styles */
    .auth-container {
        min-height: calc(100vh - 140px);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 2rem 1rem;
        background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
    }

    .auth-card {
        background: white;
        border-radius: 16px;
        box-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 10px 10px -5px rgb(0 0 0 / 0.04);
        width: 100%;
        max-width: 420px;
        padding: 2.5rem;
        position: relative;
        overflow: hidden;
    }

    .auth-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, var(--primary-color), var(--primary-hover));
    }

    .auth-header {
        text-align: center;
        margin-bottom: 2rem;
    }

    .auth-logo {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
        margin-bottom: 1.5rem;
    }

    .auth-logo .logo-icon {
        width: 48px;
        height: 48px;
        background: linear-gradient(135deg, var(--primary-color), var(--primary-hover));
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 1.5rem;
    }

    .auth-logo h2 {
        color: var(--text-dark);
        font-size: 1.5rem;
        font-weight: 700;
        margin: 0;
    }

    .auth-title {
        color: var(--text-dark);
        font-size: 1.75rem;
        font-weight: 700;
        margin: 0 0 0.5rem 0;
    }

    .auth-subtitle {
        color: var(--text-light);
        font-size: 0.95rem;
        margin: 0;
    }

    /* Form Styles */
    .auth-form {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .form-label {
        color: var(--text-dark);
        font-weight: 600;
        font-size: 0.9rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .form-input {
        padding: 0.875rem 1rem;
        border: 2px solid var(--border-color);
        border-radius: 8px;
        font-size: 1rem;
        transition: all 0.2s ease;
        background: white;
        color: var(--text-dark);
    }

    .form-input:focus {
        outline: none;
        border-color: var(--primary-color);
        box-shadow: 0 0 0 3px rgb(37 99 235 / 0.1);
    }

    .form-input:hover {
        border-color: #cbd5e1;
    }

    .form-input::placeholder {
        color: var(--text-light);
    }

    /* Password Strength Indicator */
    .password-wrapper {
        position: relative;
    }

    .password-toggle {
        position: absolute;
        right: 12px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: var(--text-light);
        cursor: pointer;
        padding: 4px;
        border-radius: 4px;
        transition: color 0.2s ease;
    }

    .password-toggle:hover {
        color: var(--primary-color);
    }

    .password-strength {
        margin-top: 0.5rem;
        display: none;
    }

    .password-strength.show {
        display: block;
    }

    .strength-bar {
        height: 4px;
        background: #e2e8f0;
        border-radius: 2px;
        overflow: hidden;
        margin-bottom: 0.5rem;
    }

    .strength-fill {
        height: 100%;
        transition: all 0.3s ease;
        border-radius: 2px;
    }

    .strength-weak { background: #ef4444; width: 25%; }
    .strength-fair { background: #f59e0b; width: 50%; }
    .strength-good { background: #10b981; width: 75%; }
    .strength-strong { background: #059669; width: 100%; }

    .strength-text {
        font-size: 0.8rem;
        color: var(--text-light);
    }

    /* Submit Button */
    .auth-submit {
        background: linear-gradient(135deg, var(--primary-color), var(--primary-hover));
        color: white;
        border: none;
        padding: 1rem;
        border-radius: 8px;
        font-size: 1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        margin-top: 0.5rem;
    }

    .auth-submit:hover {
        transform: translateY(-1px);
        box-shadow: 0 10px 25px -5px rgb(37 99 235 / 0.4);
    }

    .auth-submit:active {
        transform: translateY(0);
    }

    .auth-submit:disabled {
        opacity: 0.6;
        cursor: not-allowed;
        transform: none;
    }

    /* Error/Success Messages */
    .alert {
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 0.75rem;
        font-weight: 500;
    }

    .alert-error {
        background: #fde8e8;
        color: #dc2626;
        border: 1px solid #fca5a5;
    }

    .alert-success {
        background: #d1fae5;
        color: #065f46;
        border: 1px solid #6ee7b7;
    }

    /* Auth Footer */
    .auth-footer {
        text-align: center;
        margin-top: 2rem;
        padding-top: 1.5rem;
        border-top: 1px solid var(--border-color);
    }

    .auth-footer p {
        color: var(--text-light);
        margin: 0;
        font-size: 0.9rem;
    }

    .auth-footer a {
        color: var(--primary-color);
        text-decoration: none;
        font-weight: 600;
        transition: color 0.2s ease;
    }

    .auth-footer a:hover {
        color: var(--primary-hover);
        text-decoration: underline;
    }

    /* Social Login Options */
    .social-login {
        margin: 1.5rem 0;
    }

    .divider {
        display: flex;
        align-items: center;
        margin: 1.5rem 0;
        color: var(--text-light);
        font-size: 0.9rem;
    }

    .divider::before,
    .divider::after {
        content: '';
        flex: 1;
        height: 1px;
        background: var(--border-color);
    }

    .divider span {
        padding: 0 1rem;
        background: white;
    }

    .social-btn {
        width: 100%;
        padding: 0.875rem;
        border: 2px solid var(--border-color);
        background: white;
        border-radius: 8px;
        font-size: 0.95rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
        margin-bottom: 0.75rem;
        text-decoration: none;
        color: var(--text-dark);
    }

    .social-btn:hover {
        border-color: var(--primary-color);
        background: var(--bg-light);
    }

    /* Mobile Responsive */
    @media (max-width: 480px) {
        .auth-container {
            padding: 1rem;
        }

        .auth-card {
            padding: 2rem 1.5rem;
        }

        .auth-title {
            font-size: 1.5rem;
        }
    }

    /* Loading State */
    .loading {
        display: inline-block;
        width: 20px;
        height: 20px;
        border: 2px solid rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        border-top-color: white;
        animation: spin 1s ease-in-out infinite;
    }

    @keyframes spin {
        to { transform: rotate(360deg); }
    }
</style>

<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <div class="auth-logo">
                <div class="logo-icon">
                    <i class="fas fa-bolt"></i>
                </div>
                <h2><?= SITE_NAME ?></h2>
            </div>
            <h1 class="auth-title">Create Account</h1>
            <p class="auth-subtitle">Join us and start shopping for the latest electronics</p>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-triangle"></i>
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="post" class="auth-form" id="registerForm">
            <div class="form-group">
                <label class="form-label" for="email">
                    <i class="fas fa-envelope"></i>
                    Email Address
                </label>
                <input 
                    type="email" 
                    id="email"
                    name="email" 
                    class="form-input"
                    placeholder="Enter your email address"
                    value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label class="form-label" for="password">
                    <i class="fas fa-lock"></i>
                    Password
                </label>
                <div class="password-wrapper">
                    <input 
                        type="password" 
                        id="password"
                        name="password" 
                        class="form-input"
                        placeholder="Create a strong password"
                        required
                    >
                    <button type="button" class="password-toggle" onclick="togglePassword('password')">
                        <i class="fas fa-eye" id="password-eye"></i>
                    </button>
                </div>
                <div class="password-strength" id="passwordStrength">
                    <div class="strength-bar">
                        <div class="strength-fill" id="strengthFill"></div>
                    </div>
                    <div class="strength-text" id="strengthText"></div>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="confirm_password">
                    <i class="fas fa-lock"></i>
                    Confirm Password
                </label>
                <div class="password-wrapper">
                    <input 
                        type="password" 
                        id="confirm_password"
                        name="confirm_password" 
                        class="form-input"
                        placeholder="Confirm your password"
                        required
                    >
                    <button type="button" class="password-toggle" onclick="togglePassword('confirm_password')">
                        <i class="fas fa-eye" id="confirm_password-eye"></i>
                    </button>
                </div>
            </div>

            <button type="submit" class="auth-submit" id="submitBtn">
                <i class="fas fa-user-plus"></i>
                Create Account
            </button>
        </form>

        <div class="divider">
            <span>or continue with</span>
        </div>

        <div class="social-login">
            <a href="#" class="social-btn">
                <i class="fab fa-google"></i>
                Continue with Google
            </a>
            <a href="#" class="social-btn">
                <i class="fab fa-facebook-f"></i>
                Continue with Facebook
            </a>
        </div>

        <div class="auth-footer">
            <p>Already have an account? <a href="login.php">Sign in here</a></p>
        </div>
    </div>
</div>

<script>
    // Password visibility toggle
    function togglePassword(fieldId) {
        const field = document.getElementById(fieldId);
        const eye = document.getElementById(fieldId + '-eye');
        
        if (field.type === 'password') {
            field.type = 'text';
            eye.classList.remove('fa-eye');
            eye.classList.add('fa-eye-slash');
        } else {
            field.type = 'password';
            eye.classList.remove('fa-eye-slash');
            eye.classList.add('fa-eye');
        }
    }

    // Password strength checker
    function checkPasswordStrength(password) {
        let strength = 0;
        const strengthIndicator = document.getElementById('passwordStrength');
        const strengthFill = document.getElementById('strengthFill');
        const strengthText = document.getElementById('strengthText');

        if (password.length === 0) {
            strengthIndicator.classList.remove('show');
            return;
        }

        strengthIndicator.classList.add('show');

        // Length check
        if (password.length >= 8) strength++;
        if (password.length >= 12) strength++;

        // Character variety checks
        if (/[a-z]/.test(password)) strength++;
        if (/[A-Z]/.test(password)) strength++;
        if (/[0-9]/.test(password)) strength++;
        if (/[^A-Za-z0-9]/.test(password)) strength++;

        // Update UI based on strength
        strengthFill.className = 'strength-fill';
        
        if (strength <= 2) {
            strengthFill.classList.add('strength-weak');
            strengthText.textContent = 'Weak password';
        } else if (strength <= 4) {
            strengthFill.classList.add('strength-fair');
            strengthText.textContent = 'Fair password';
        } else if (strength <= 5) {
            strengthFill.classList.add('strength-good');
            strengthText.textContent = 'Good password';
        } else {
            strengthFill.classList.add('strength-strong');
            strengthText.textContent = 'Strong password';
        }
    }

    // Password strength event listener
    document.getElementById('password').addEventListener('input', function() {
        checkPasswordStrength(this.value);
    });

    // Form submission with loading state
    document.getElementById('registerForm').addEventListener('submit', function() {
        const submitBtn = document.getElementById('submitBtn');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<div class="loading"></div> Creating Account...';
    });

    // Real-time password confirmation
    document.getElementById('confirm_password').addEventListener('input', function() {
        const password = document.getElementById('password').value;
        const confirm = this.value;
        
        if (confirm && password !== confirm) {
            this.style.borderColor = '#ef4444';
        } else {
            this.style.borderColor = '';
        }
    });
</script>

<?php
require_once '../includes/footer.php';
?>