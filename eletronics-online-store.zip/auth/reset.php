<?php
require_once '../includes/header.php';

$token = $_GET['token'] ?? '';
$page_title = 'Reset Password';

if (empty($token)) {
    header("Location: forgot.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    
    if ($password !== $confirm) {
        $error = "Passwords don't match";
    } else {
        if (resetPassword($token, $password)) {
            $message = "Password reset successfully. You can now login.";
        } else {
            $error = "Invalid or expired reset token";
        }
    }
}
?>
<h1>Reset Password</h1>
<?php if (isset($message)): ?>
    <div class="message"><?= $message ?></div>
    <p><a href="login.php">Login here</a></p>
<?php else: ?>
    <?php if (isset($error)): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>
    <form method="post">
        <div>
            <label>New Password:</label>
            <input type="password" name="password" required>
        </div>
        <div>
            <label>Confirm Password:</label>
            <input type="password" name="confirm_password" required>
        </div>
        <button type="submit">Reset Password</button>
    </form>
<?php endif; ?>
<?php
require_once '../includes/footer.php';
?>