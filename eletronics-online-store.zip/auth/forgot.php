<?php
require_once '../includes/header.php';
$page_title = 'Forgot Password';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    
    // In a real app, you would send a password reset email here
    $success = true; // Simulate success for demo
    
    if ($success) {
        $message = "If an account exists with this email, we've sent a reset link.";
    } else {
        $error = "There was an error processing your request.";
    }
}
?>
<h1>Forgot Password</h1>
<?php if (isset($message)): ?>
    <div class="success"><?= $message ?></div>
<?php elseif (isset($error)): ?>
    <div class="error"><?= $error ?></div>
<?php endif; ?>
<form method="post">
    <div>
        <label>Email:</label>
        <input type="email" name="email" required>
    </div>
    <button type="submit">Reset Password</button>
</form>
<p>Remember your password? <a href="login.php">Login here</a></p>
<?php
require_once '../includes/footer.php';
?>