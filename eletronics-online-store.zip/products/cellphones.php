<?php
require_once '../includes/header.php';
$page_title = 'Cellphones';

// Define the Cellphones category ID (replace with your actual ID)
$cellphone_category_id = 1; // This should be your actual category ID for cellphones

// Handle AJAX requests for dynamic filtering
if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    header('Content-Type: application/json');
    
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $per_page = 12;
    $offset = ($page - 1) * $per_page;
    
    // Build query with filters
    $where_clauses = ["category_id = :category_id"];
    $params = [':category_id' => $cellphone_category_id];
    
    if (!empty($_GET['brand'])) {
        $where_clauses[] = "brand = :brand";
        $params[':brand'] = $_GET['brand'];
    }
    
    if (!empty($_GET['search'])) {
        $where_clauses[] = "(name LIKE :search OR brand LIKE :search)";
        $params[':search'] = '%' . $_GET['search'] . '%';
    }
    
    if (!empty($_GET['min_price'])) {
        $where_clauses[] = "price >= :min_price";
        $params[':min_price'] = $_GET['min_price'];
    }
    
    if (!empty($_GET['max_price'])) {
        $where_clauses[] = "price <= :max_price";
        $params[':max_price'] = $_GET['max_price'];
    }
    
    $where_sql = implode(' AND ', $where_clauses);
    
    // Sorting
    $sort_sql = "created_at DESC";
    if (!empty($_GET['sort'])) {
        switch ($_GET['sort']) {
            case 'price_asc':
                $sort_sql = "price ASC";
                break;
            case 'price_desc':
                $sort_sql = "price DESC";
                break;
            case 'name':
                $sort_sql = "name ASC";
                break;
        }
    }
    
    // Get products
    $stmt = $pdo->prepare("
        SELECT * FROM products 
        WHERE {$where_sql}
        ORDER BY {$sort_sql}
        LIMIT :limit OFFSET :offset
    ");
    
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count
    $total_stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE {$where_sql}");
    foreach ($params as $key => $value) {
        $total_stmt->bindValue($key, $value);
    }
    $total_stmt->execute();
    $total = $total_stmt->fetchColumn();
    $total_pages = ceil($total / $per_page);
    
    echo json_encode([
        'products' => $products,
        'total' => $total,
        'total_pages' => $total_pages,
        'current_page' => $page
    ]);
    exit;
}

// Regular page load
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 12;
$offset = ($page - 1) * $per_page;

// Get cellphones with pagination
$stmt = $pdo->prepare("
    SELECT * FROM products 
    WHERE category_id = :category_id
    ORDER BY created_at DESC 
    LIMIT :limit OFFSET :offset
");
$stmt->bindValue(':category_id', $cellphone_category_id, PDO::PARAM_INT);
$stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get total count for pagination
$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE category_id = :category_id");
$total_stmt->bindValue(':category_id', $cellphone_category_id, PDO::PARAM_INT);
$total_stmt->execute();
$total = $total_stmt->fetchColumn();
$total_pages = ceil($total / $per_page);

// Get brands for filtering
$brands_stmt = $pdo->prepare("
    SELECT DISTINCT brand FROM products 
    WHERE category_id = :category_id AND brand IS NOT NULL
    ORDER BY brand
");
$brands_stmt->bindValue(':category_id', $cellphone_category_id, PDO::PARAM_INT);
$brands_stmt->execute();
$brands = $brands_stmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium Cellphones - Professional Electronics Store</title>
    <link rel="stylesheet" href="../assets/css/cellphones.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Loading Overlay -->
    <div id="loading-overlay" class="loading-overlay hidden">
        <div class="loading-spinner"></div>
    </div>

    <!-- Notification Toast -->
    <div id="notification-toast" class="notification-toast hidden">
        <div class="toast-content">
            <div class="toast-icon">✓</div>
            <span class="toast-message"></span>
        </div>
    </div>

    <div class="page-container">
        <!-- Header Section -->
        <header class="page-header">
            <div class="header-content">
                <div class="header-text">
                    <h1 class="page-title">Premium Cellphones</h1>
                    <p class="page-subtitle">Discover the latest smartphones with cutting-edge technology</p>
                </div>
                <div class="header-stats">
                    <div class="stat-item">
                        <span class="stat-number" id="total-products"><?= $total ?></span>
                        <span class="stat-label">Products</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number"><?= count($brands) ?></span>
                        <span class="stat-label">Brands</span>
                    </div>
                </div>
            </div>
        </header>

        <!-- Filters Section -->
        <section class="filters-section">
            <div class="filters-container">
                <div class="filters-header">
                    <h3>Filter & Sort</h3>
                    <button id="clear-filters" class="clear-btn">Clear All</button>
                </div>
                
                <form id="filter-form" class="filter-form">
                    <div class="filter-row">
                        <div class="filter-group">
                            <label for="search">Search</label>
                            <div class="search-input-wrapper">
                                <input type="text" id="search" name="search" placeholder="Search phones..." autocomplete="off">
                                <div class="search-icon">🔍</div>
                            </div>
                        </div>
                        
                        <div class="filter-group">
                            <label for="brand">Brand</label>
                            <div class="select-wrapper">
                                <select name="brand" id="brand">
                                    <option value="">All Brands</option>
                                    <?php foreach ($brands as $brand): ?>
                                        <option value="<?= htmlspecialchars($brand) ?>">
                                            <?= htmlspecialchars($brand) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="filter-group">
                            <label for="sort">Sort by</label>
                            <div class="select-wrapper">
                                <select name="sort" id="sort">
                                    <option value="newest">Newest First</option>
                                    <option value="price_asc">Price: Low to High</option>
                                    <option value="price_desc">Price: High to Low</option>
                                    <option value="name">Name: A-Z</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="filter-row">
                        <div class="filter-group price-range">
                            <label>Price Range</label>
                            <div class="price-inputs">
                                <input type="number" id="min-price" name="min_price" placeholder="Min" min="0">
                                <span class="price-separator">-</span>
                                <input type="number" id="max-price" name="max_price" placeholder="Max" min="0">
                            </div>
                        </div>
                        
                        <div class="filter-actions">
                            <button type="submit" class="apply-btn">Apply Filters</button>
                        </div>
                    </div>
                </form>
            </div>
        </section>

        <!-- Products Section -->
        <section class="products-section">
            <div class="products-header">
                <div class="view-options">
                    <button class="view-btn active" data-view="grid">
                        <span class="grid-icon">⊞</span> Grid
                    </button>
                    <button class="view-btn" data-view="list">
                        <span class="list-icon">☰</span> List
                    </button>
                </div>
                
                <div class="results-info">
                    <span id="results-count">Showing <?= count($products) ?> of <?= $total ?> products</span>
                </div>
            </div>
            
            <div id="products-grid" class="products-grid">
                <?php if (empty($products)): ?>
                    <div class="no-results">
                        <div class="no-results-icon">📱</div>
                        <h3>No cellphones found</h3>
                        <p>Try adjusting your filters or search terms.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($products as $product): ?>
                        <article class="product-card" data-product-id="<?= $product['product_id'] ?>">
                            <div class="product-image-container">
                                <?php if (isset($product['image_main']) && $product['image_main']): ?>
                                    <img src="/assets/images/products/<?= htmlspecialchars($product['image_main']) ?>" 
                                         alt="<?= htmlspecialchars($product['name']) ?>"
                                         class="product-image"
                                         loading="lazy">
                                <?php else: ?>
                                    <div class="no-image">
                                        <div class="no-image-icon">📱</div>
                                        <span>No Image Available</span>
                                    </div>
                                <?php endif; ?>
                                <div class="product-overlay">
                                    <button class="quick-view-btn" data-product-id="<?= $product['product_id'] ?>">
                                        Quick View
                                    </button>
                                </div>
                            </div>
                            
                            <div class="product-content">
                                <div class="product-brand"><?= htmlspecialchars($product['brand'] ?? '') ?></div>
                                <h3 class="product-name">
                                    <a href="/products/view.php?id=<?= $product['product_id'] ?>">
                                        <?= htmlspecialchars($product['name']) ?>
                                    </a>
                                </h3>
                                
                                <div class="product-specs">
                                    <?php 
                                    $specs = json_decode($product['specifications'], true);
                                    if ($specs): ?>
                                        <span class="spec-item"><?= htmlspecialchars($specs['storage'] ?? '') ?></span>
                                        <?php if (!empty($specs['storage']) && !empty($specs['color'])): ?>
                                            <span class="spec-separator">•</span>
                                        <?php endif; ?>
                                        <span class="spec-item"><?= htmlspecialchars($specs['color'] ?? '') ?></span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="product-price">
                                    <span class="current-price">$<?= number_format($product['price'], 2) ?></span>
                                    <?php if (!empty($product['original_price']) && $product['original_price'] > $product['price']): ?>
                                        <span class="original-price">$<?= number_format($product['original_price'], 2) ?></span>
                                        <span class="discount-badge">
                                            <?= round((($product['original_price'] - $product['price']) / $product['original_price']) * 100) ?>% OFF
                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="product-actions">
                                    <button class="add-to-cart-btn" data-product-id="<?= $product['product_id'] ?>">
                                        <span class="btn-icon">🛒</span>
                                        <span class="btn-text">Add to Cart</span>
                                        <div class="btn-loading hidden">
                                            <div class="loading-spinner-small"></div>
                                        </div>
                                    </button>
                                    <button class="wishlist-btn" data-product-id="<?= $product['product_id'] ?>">
                                        <span class="heart-icon">♡</span>
                                    </button>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <nav class="pagination-nav" id="pagination-nav">
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="#" class="pagination-btn prev-btn" data-page="<?= $page - 1 ?>">
                                <span class="btn-icon">←</span>
                                <span class="btn-text">Previous</span>
                            </a>
                        <?php endif; ?>
                        
                        <div class="pagination-numbers">
                            <?php 
                            $start_page = max(1, $page - 2);
                            $end_page = min($total_pages, $page + 2);
                            
                            if ($start_page > 1): ?>
                                <a href="#" class="pagination-number" data-page="1">1</a>
                                <?php if ($start_page > 2): ?>
                                    <span class="pagination-ellipsis">...</span>
                                <?php endif; ?>
                            <?php endif; ?>
                            
                            <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
                                <a href="#" class="pagination-number <?= $i === $page ? 'active' : '' ?>" data-page="<?= $i ?>">
                                    <?= $i ?>
                                </a>
                            <?php endfor; ?>
                            
                            <?php if ($end_page < $total_pages): ?>
                                <?php if ($end_page < $total_pages - 1): ?>
                                    <span class="pagination-ellipsis">...</span>
                                <?php endif; ?>
                                <a href="#" class="pagination-number" data-page="<?= $total_pages ?>"><?= $total_pages ?></a>
                            <?php endif; ?>
                        </div>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="#" class="pagination-btn next-btn" data-page="<?= $page + 1 ?>">
                                <span class="btn-text">Next</span>
                                <span class="btn-icon">→</span>
                            </a>
                        <?php endif; ?>
                    </div>
                </nav>
            <?php endif; ?>
        </section>
    </div>

    <script src="../assets/js/cellphones.js"></script>
</body>
</html>

<?php
require_once '../includes/footer.php';
?>