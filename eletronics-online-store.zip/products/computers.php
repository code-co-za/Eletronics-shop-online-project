<?php
require_once '../includes/header.php';
$page_title = 'Computers';

// Database connection (ensure this is set in your header.php or here)
// $pdo = new PDO(...);

// Get the Computer category ID (you should replace 1 with your actual computer category ID)
$computer_category_id = 1;

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 12;
$offset = ($page - 1) * $per_page;

// Handle filtering and sorting
$brand_filter = isset($_GET['brand']) ? $_GET['brand'] : '';
$sort_order = isset($_GET['sort']) ? $_GET['sort'] : 'newest';

// Build query based on filters
$where_clause = "WHERE category_id = :category_id";
$params = [':category_id' => $computer_category_id];

if ($brand_filter) {
    $where_clause .= " AND brand = :brand";
    $params[':brand'] = $brand_filter;
}

// Sort order
$order_clause = "ORDER BY ";
switch ($sort_order) {
    case 'price_asc':
        $order_clause .= "price ASC";
        break;
    case 'price_desc':
        $order_clause .= "price DESC";
        break;
    case 'name':
        $order_clause .= "name ASC";
        break;
    default:
        $order_clause .= "created_at DESC";
}

// Get computers with pagination
$stmt = $pdo->prepare("
    SELECT * FROM products 
    {$where_clause}
    {$order_clause}
    LIMIT :limit OFFSET :offset
");

foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get total count for pagination
$count_stmt = $pdo->prepare("SELECT COUNT(*) FROM products {$where_clause}");
foreach ($params as $key => $value) {
    $count_stmt->bindValue($key, $value);
}
$count_stmt->execute();
$total = $count_stmt->fetchColumn();
$total_pages = ceil($total / $per_page);

// Get brands for filtering
$brands_stmt = $pdo->prepare("
    SELECT DISTINCT brand FROM products 
    WHERE category_id = :category_id AND brand IS NOT NULL AND brand != ''
    ORDER BY brand
");
$brands_stmt->execute([':category_id' => $computer_category_id]);
$brands = $brands_stmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --accent-color: #e74c3c;
            --light-gray: #f5f5f5;
            --medium-gray: #e0e0e0;
            --dark-gray: #333;
            --white: #fff;
            --success-color: #2ecc71;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: var(--light-gray);
            color: var(--dark-gray);
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        h1 {
            text-align: center;
            margin: 20px 0 30px;
            color: var(--secondary-color);
        }
        
        /* Filter Controls */
        .filter-controls {
            background-color: var(--white);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .filter-form {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: flex-end;
        }
        
        .form-group {
            flex: 1;
            min-width: 200px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: var(--secondary-color);
        }
        
        select, .btn {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--medium-gray);
            border-radius: 4px;
            font-size: 16px;
        }
        
        .btn {
            background-color: var(--primary-color);
            color: var(--white);
            border: none;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.3s;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            min-width: 100px;
        }
        
        .btn:hover {
            background-color: #2980b9;
        }
        
        /* Product Grid */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .product-card {
            background-color: var(--white);
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .product-card a {
            text-decoration: none;
            color: inherit;
            display: block;
            height: 100%;
        }
        
        .product-card img {
            width: 100%;
            height: 200px;
            object-fit: contain;
            border-bottom: 1px solid var(--medium-gray);
            padding: 10px;
            background-color: var(--white);
        }
        
        .product-card h3 {
            padding: 15px 15px 0;
            font-size: 16px;
            font-weight: 600;
            color: var(--secondary-color);
        }
        
        .price {
            padding: 5px 15px;
            font-weight: 700;
            color: var(--primary-color);
        }
        
        .original-price {
            text-decoration: line-through;
            color: var(--dark-gray);
            font-size: 14px;
            margin-right: 8px;
        }
        
        .discount-price {
            color: var(--accent-color);
        }
        
        .stock-status {
            padding: 5px 15px 15px;
            font-size: 14px;
        }
        
        .in-stock {
            color: var(--success-color);
        }
        
        .out-of-stock {
            color: var(--danger-color);
        }
        
        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 5px;
            margin: 30px 0;
        }
        
        .pagination a {
            padding: 8px 15px;
            background-color: var(--white);
            border: 1px solid var(--medium-gray);
            border-radius: 4px;
            text-decoration: none;
            color: var(--primary-color);
            transition: all 0.3s;
        }
        
        .pagination a:hover, .pagination a.active {
            background-color: var(--primary-color);
            color: var(--white);
            border-color: var(--primary-color);
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .filter-form {
                flex-direction: column;
            }
            
            .form-group {
                width: 100%;
            }
            
            .product-grid {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            }
        }
        
        @media (max-width: 480px) {
            .product-grid {
                grid-template-columns: 1fr 1fr;
            }
            
            .pagination a {
                padding: 6px 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1><?php echo htmlspecialchars($page_title); ?></h1>
        
        <!-- Filter and Sort Controls -->
        <div class="filter-controls">
            <form method="get" class="filter-form">
                <div class="form-group">
                    <label for="brand">Filter by Brand:</label>
                    <select name="brand" id="brand">
                        <option value="">All Brands</option>
                        <?php foreach ($brands as $brand): ?>
                            <option value="<?php echo htmlspecialchars($brand); ?>" 
                                <?php if ($brand_filter === $brand) echo 'selected'; ?>>
                                <?php echo htmlspecialchars($brand); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="sort">Sort by:</label>
                    <select name="sort" id="sort">
                        <option value="newest" <?php if ($sort_order === 'newest') echo 'selected'; ?>>Newest First</option>
                        <option value="price_asc" <?php if ($sort_order === 'price_asc') echo 'selected'; ?>>Price: Low to High</option>
                        <option value="price_desc" <?php if ($sort_order === 'price_desc') echo 'selected'; ?>>Price: High to Low</option>
                        <option value="name" <?php if ($sort_order === 'name') echo 'selected'; ?>>Name: A-Z</option>
                    </select>
                </div>
                
                <button type="submit" class="btn">Apply</button>
                <?php if ($brand_filter || $sort_order !== 'newest'): ?>
                    <a href="computers.php" class="btn">Reset</a>
                <?php endif; ?>
            </form>
        </div>
        
        <!-- Product Grid -->
        <div class="product-grid">
            <?php if (empty($products)): ?>
                <p>No computers found.</p>
            <?php else: ?>
                <?php foreach ($products as $product): ?>
                    <div class="product-card">
                        <a href="../product.php?id=<?php echo $product['product_id']; ?>">
                            <?php if (!empty($product['images'])): ?>
                                <?php $images = json_decode($product['images'], true); ?>
                                <img src="<?php echo htmlspecialchars($images[0]); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                            <?php else: ?>
                                <img src="../images/placeholder.png" alt="No image available">
                            <?php endif; ?>
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <div class="price">
                                <?php if ($product['discount_price']): ?>
                                    <span class="original-price">$<?php echo number_format($product['price'], 2); ?></span>
                                    <span class="discount-price">$<?php echo number_format($product['discount_price'], 2); ?></span>
                                <?php else: ?>
                                    <span>$<?php echo number_format($product['price'], 2); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="stock-status">
                                <?php if ($product['stock_quantity'] > 0): ?>
                                    <span class="in-stock">In Stock (<?php echo $product['stock_quantity']; ?>)</span>
                                <?php else: ?>
                                    <span class="out-of-stock">Out of Stock</span>
                                <?php endif; ?>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => 1])); ?>">&laquo; First</a>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">&lsaquo; Prev</a>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" 
                       <?php if ($i === $page) echo 'class="active"'; ?>>
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">Next &rsaquo;</a>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $total_pages])); ?>">Last &raquo;</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <?php require_once '../includes/footer.php'; ?>
    
    <script>
        // Enhance user experience with some simple JavaScript
        document.addEventListener('DOMContentLoaded', function() {
            // Add smooth scrolling to top when pagination links are clicked
            const paginationLinks = document.querySelectorAll('.pagination a');
            paginationLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    // Don't interfere with the link's default behavior
                    setTimeout(() => {
                        window.scrollTo({
                            top: 0,
                            behavior: 'smooth'
                        });
                    }, 100);
                });
            });
            
            // Add confirmation for reset button
            const resetBtn = document.querySelector('.btn[href="computers.php"]');
            if (resetBtn) {
                resetBtn.addEventListener('click', function(e) {
                    if (!confirm('Are you sure you want to reset all filters?')) {
                        e.preventDefault();
                    }
                });
            }
            
            // Add loading indicator when filters are applied
            const filterForm = document.querySelector('.filter-form');
            if (filterForm) {
                filterForm.addEventListener('submit', function() {
                    // You could add a loading spinner here if you want
                    // For now, we'll just disable the submit button
                    const submitBtn = this.querySelector('button[type="submit"]');
                    if (submitBtn) {
                        submitBtn.disabled = true;
                        submitBtn.textContent = 'Loading...';
                    }
                });
            }
        });
    </script>
</body>
</html>