<?php
require_once '../includes/header.php';
$page_title = 'Computers';

// Database connection (ensure this is set in your header.php or here)
// $pdo = new PDO(...);

// Get the Computer category ID (you should replace 1 with your actual computer category ID)
$computer_category_id = 1;

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 12;
$offset = ($page - 1) * $per_page;

// Handle filtering and sorting
$brand_filter = isset($_GET['brand']) ? $_GET['brand'] : '';
$sort_order = isset($_GET['sort']) ? $_GET['sort'] : 'newest';

// Build query based on filters
$where_clause = "WHERE category_id = :category_id";
$params = [':category_id' => $computer_category_id];

if ($brand_filter) {
    $where_clause .= " AND brand = :brand";
    $params[':brand'] = $brand_filter;
}

// Sort order
$order_clause = "ORDER BY ";
switch ($sort_order) {
    case 'price_asc':
        $order_clause .= "price ASC";
        break;
    case 'price_desc':
        $order_clause .= "price DESC";
        break;
    case 'name':
        $order_clause .= "name ASC";
        break;
    default:
        $order_clause .= "created_at DESC";
}

// Get computers with pagination
$stmt = $pdo->prepare("
    SELECT * FROM products 
    {$where_clause}
    {$order_clause}
    LIMIT :limit OFFSET :offset
");

foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get total count for pagination
$count_stmt = $pdo->prepare("SELECT COUNT(*) FROM products {$where_clause}");
foreach ($params as $key => $value) {
    $count_stmt->bindValue($key, $value);
}
$count_stmt->execute();
$total = $count_stmt->fetchColumn();
$total_pages = ceil($total / $per_page);

// Get brands for filtering
$brands_stmt = $pdo->prepare("
    SELECT DISTINCT brand FROM products 
    WHERE category_id = :category_id AND brand IS NOT NULL AND brand != ''
    ORDER BY brand
");
$brands_stmt->execute([':category_id' => $computer_category_id]);
$brands = $brands_stmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <div class="container">
        <h1><?php echo htmlspecialchars($page_title); ?></h1>
        
        <!-- Filter and Sort Controls -->
        <div class="filter-controls">
            <form method="get" class="filter-form">
                <div class="form-group">
                    <label for="brand">Filter by Brand:</label>
                    <select name="brand" id="brand">
                        <option value="">All Brands</option>
                        <?php foreach ($brands as $brand): ?>
                            <option value="<?php echo htmlspecialchars($brand); ?>" 
                                <?php if ($brand_filter === $brand) echo 'selected'; ?>>
                                <?php echo htmlspecialchars($brand); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="sort">Sort by:</label>
                    <select name="sort" id="sort">
                        <option value="newest" <?php if ($sort_order === 'newest') echo 'selected'; ?>>Newest First</option>
                        <option value="price_asc" <?php if ($sort_order === 'price_asc') echo 'selected'; ?>>Price: Low to High</option>
                        <option value="price_desc" <?php if ($sort_order === 'price_desc') echo 'selected'; ?>>Price: High to Low</option>
                        <option value="name" <?php if ($sort_order === 'name') echo 'selected'; ?>>Name: A-Z</option>
                    </select>
                </div>
                
                <button type="submit" class="btn">Apply</button>
                <?php if ($brand_filter || $sort_order !== 'newest'): ?>
                    <a href="computers.php" class="btn">Reset</a>
                <?php endif; ?>
            </form>
        </div>
        
        <!-- Product Grid -->
        <div class="product-grid">
            <?php if (empty($products)): ?>
                <p>No computers found.</p>
            <?php else: ?>
                <?php foreach ($products as $product): ?>
                    <div class="product-card">
                        <a href="../product.php?id=<?php echo $product['product_id']; ?>">
                            <?php if (!empty($product['images'])): ?>
                                <?php $images = json_decode($product['images'], true); ?>
                                <img src="<?php echo htmlspecialchars($images[0]); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                            <?php else: ?>
                                <img src="../images/placeholder.png" alt="No image available">
                            <?php endif; ?>
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <div class="price">
                                <?php if ($product['discount_price']): ?>
                                    <span class="original-price">$<?php echo number_format($product['price'], 2); ?></span>
                                    <span class="discount-price">$<?php echo number_format($product['discount_price'], 2); ?></span>
                                <?php else: ?>
                                    <span>$<?php echo number_format($product['price'], 2); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="stock-status">
                                <?php if ($product['stock_quantity'] > 0): ?>
                                    <span class="in-stock">In Stock (<?php echo $product['stock_quantity']; ?>)</span>
                                <?php else: ?>
                                    <span class="out-of-stock">Out of Stock</span>
                                <?php endif; ?>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => 1])); ?>">&laquo; First</a>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">&lsaquo; Prev</a>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" 
                       <?php if ($i === $page) echo 'class="active"'; ?>>
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">Next &rsaquo;</a>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $total_pages])); ?>">Last &raquo;</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <?php require_once '../includes/footer.php'; ?>
</body>
</html>