<?php
// Start session and include database connection
session_start();
require_once '../includes/db_connect.php';
require_once '../includes/config.php';

// Function to get product by ID - MOVED TO TOP
function getProductById($id) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT * FROM products WHERE product_id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return false;
    }
}

// Function to get similar products - MOVED TO TOP
function getSimilarProducts($currentProductId, $categoryId, $limit = 4) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM products 
            WHERE category_id = ? AND product_id != ? AND status = 'active'
            ORDER BY RAND() 
            LIMIT ?
        ");
        $stmt->execute([$categoryId, $currentProductId, $limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return [];
    }
}

// Function to get category name
function getCategoryName($categoryId) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT name FROM categories WHERE category_id = ?");
        $stmt->execute([$categoryId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $result['name'] : 'Unknown';
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return 'Unknown';
    }
}

// Check if product ID is provided and valid
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: /products/cellphones.php");
    exit;
}

$productId = (int)$_GET['id'];
$product = getProductById($productId);

// Redirect if product not found
if (!$product) {
    header("Location: /products/cellphones.php");
    exit;
}

$categoryName = getCategoryName($product['category_id']);
$similarProducts = getSimilarProducts($productId, $product['category_id']);

// Set page title
$page_title = $product['name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?> - <?= htmlspecialchars(SITE_NAME) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        /* CSS Variables for Modern Design System */
        :root {
            --primary-50: #eff6ff;
            --primary-100: #dbeafe;
            --primary-500: #3b82f6;
            --primary-600: #2563eb;
            --primary-700: #1d4ed8;
            --primary-900: #1e3a8a;
            
            --secondary-500: #10b981;
            --secondary-600: #059669;
            
            --accent-500: #f59e0b;
            --accent-600: #d97706;
            
            --success-500: #10b981;
            --warning-500: #f59e0b;
            --error-500: #ef4444;
            
            --neutral-50: #f9fafb;
            --neutral-100: #f3f4f6;
            --neutral-200: #e5e7eb;
            --neutral-300: #d1d5db;
            --neutral-400: #9ca3af;
            --neutral-500: #6b7280;
            --neutral-600: #4b5563;
            --neutral-700: #374151;
            --neutral-800: #1f2937;
            --neutral-900: #111827;
            
            --white: #ffffff;
            --black: #000000;
            
            /* Shadows */
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
            
            /* Transitions */
            --transition-fast: 150ms cubic-bezier(0.4, 0, 0.2, 1);
            --transition: 300ms cubic-bezier(0.4, 0, 0.2, 1);
            --transition-slow: 500ms cubic-bezier(0.4, 0, 0.2, 1);
            
            /* Border Radius */
            --rounded-sm: 0.25rem;
            --rounded: 0.375rem;
            --rounded-md: 0.5rem;
            --rounded-lg: 0.75rem;
            --rounded-xl: 1rem;
            --rounded-2xl: 1.5rem;
            --rounded-3xl: 2rem;
        }

        /* Reset and Base Styles */
        *, *::before, *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            color: var(--neutral-800);
            background: linear-gradient(135deg, var(--neutral-50) 0%, var(--primary-50) 100%);
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .container {
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
        }

        /* Header Styles */
        .header {
            position: sticky;
            top: 0;
            z-index: 1000;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--neutral-200);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
        }

        .header-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 1rem 0;
            min-height: 80px;
        }

        .logo {
            font-size: 2rem;
            font-weight: 900;
            background: linear-gradient(135deg, var(--primary-600), var(--secondary-500));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-decoration: none;
            letter-spacing: -0.025em;
            transition: var(--transition);
        }

        .logo:hover {
            transform: scale(1.05);
        }

        /* Mobile Menu Button */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--neutral-700);
            cursor: pointer;
            padding: 0.5rem;
            border-radius: var(--rounded-lg);
            transition: var(--transition);
        }

        .mobile-menu-btn:hover {
            background: var(--neutral-100);
            color: var(--primary-600);
        }

        /* Navigation */
        .nav {
            display: flex;
            list-style: none;
            gap: 2rem;
        }

        .nav-link {
            text-decoration: none;
            color: var(--neutral-700);
            font-weight: 500;
            font-size: 0.95rem;
            padding: 0.75rem 1.5rem;
            border-radius: var(--rounded-xl);
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .nav-link::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(59, 130, 246, 0.1), transparent);
            transition: left 0.5s;
        }

        .nav-link:hover::before {
            left: 100%;
        }

        .nav-link:hover {
            background: var(--primary-50);
            color: var(--primary-700);
            transform: translateY(-2px);
        }

        /* Mobile Sidebar */
        .mobile-sidebar {
            position: fixed;
            top: 0;
            left: -100%;
            width: 280px;
            height: 100vh;
            background: var(--white);
            box-shadow: var(--shadow-xl);
            z-index: 2000;
            transition: left var(--transition);
            overflow-y: auto;
        }

        .mobile-sidebar.active {
            left: 0;
        }

        .mobile-sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid var(--neutral-200);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .mobile-sidebar-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--neutral-700);
            cursor: pointer;
            padding: 0.5rem;
            border-radius: var(--rounded-lg);
            transition: var(--transition);
        }

        .mobile-sidebar-close:hover {
            background: var(--neutral-100);
            color: var(--primary-600);
        }

        .mobile-nav {
            padding: 1rem 0;
        }

        .mobile-nav-link {
            display: block;
            text-decoration: none;
            color: var(--neutral-700);
            font-weight: 500;
            padding: 1rem 1.5rem;
            transition: var(--transition);
            border-left: 3px solid transparent;
        }

        .mobile-nav-link:hover {
            background: var(--primary-50);
            color: var(--primary-700);
            border-left-color: var(--primary-600);
        }

        .mobile-user-actions {
            padding: 1rem;
            border-top: 1px solid var(--neutral-200);
        }

        .mobile-user-actions .auth-link {
            display: block;
            text-decoration: none;
            color: var(--neutral-700);
            font-weight: 500;
            padding: 0.75rem 1rem;
            margin-bottom: 0.5rem;
            border-radius: var(--rounded-lg);
            transition: var(--transition);
            text-align: center;
        }

        .mobile-user-actions .auth-link:hover {
            background: var(--neutral-100);
            color: var(--primary-600);
        }

        .mobile-user-actions .auth-link.register {
            background: var(--primary-600);
            color: var(--white);
        }

        .mobile-user-actions .auth-link.register:hover {
            background: var(--primary-700);
            color: var(--white);
        }

        /* Overlay */
        .mobile-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1500;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
        }

        .mobile-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        .user-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .auth-link {
            text-decoration: none;
            color: var(--neutral-700);
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: var(--rounded-lg);
            transition: var(--transition);
        }

        .auth-link:hover {
            background: var(--neutral-100);
            color: var(--primary-600);
        }

        .auth-link.register {
            background: var(--primary-600);
            color: var(--white);
            padding: 0.75rem 1.5rem;
            font-weight: 600;
        }

        .auth-link.register:hover {
            background: var(--primary-700);
            color: var(--white);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .cart-button {
            position: relative;
            background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
            color: var(--white);
            text-decoration: none;
            padding: 0.875rem 1.75rem;
            border-radius: var(--rounded-xl);
            font-weight: 600;
            font-size: 0.95rem;
            transition: var(--transition);
            box-shadow: var(--shadow);
        }

        .cart-button:hover {
            background: linear-gradient(135deg, var(--primary-700), var(--primary-900));
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .cart-count {
            position: absolute;
            top: -8px;
            right: -8px;
            background: var(--accent-500);
            color: var(--white);
            border-radius: 50%;
            width: 28px;
            height: 28px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            font-weight: 700;
            box-shadow: var(--shadow-md);
            animation: pulse 2s infinite;
        }

        /* Product Detail Layout */
        .product-detail {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 4rem;
            margin: 3rem 0;
            background: var(--white);
            border-radius: var(--rounded-3xl);
            padding: 3rem;
            box-shadow: var(--shadow-xl);
            position: relative;
            overflow: hidden;
        }

        .product-detail::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-500), var(--secondary-500), var(--accent-500));
        }

        /* Product Images */
        .product-images {
            display: grid;
            grid-template-columns: 120px 1fr;
            gap: 1.5rem;
        }

        .thumbnail-list {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .thumbnail {
            width: 120px;
            height: 120px;
            border: 2px solid var(--neutral-200);
            border-radius: var(--rounded-xl);
            cursor: pointer;
            overflow: hidden;
            transition: var(--transition);
            position: relative;
            background: var(--neutral-50);
        }

        .thumbnail:hover {
            border-color: var(--primary-500);
            transform: scale(1.05) rotate(1deg);
            box-shadow: var(--shadow-lg);
        }

        .thumbnail.active {
            border-color: var(--primary-600);
            box-shadow: 0 0 0 4px var(--primary-100);
            transform: scale(1.05);
        }

        .thumbnail img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: var(--transition);
        }

        .thumbnail:hover img {
            transform: scale(1.1);
        }

        .main-image {
            width: 100%;
            height: 600px;
            background: linear-gradient(135deg, var(--neutral-50), var(--neutral-100));
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: var(--rounded-2xl);
            overflow: hidden;
            box-shadow: var(--shadow-lg);
            position: relative;
        }

        .main-image::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(45deg, transparent 49%, rgba(255,255,255,0.1) 50%, transparent 51%);
            pointer-events: none;
        }

        .main-image img {
            max-width: 90%;
            max-height: 90%;
            object-fit: contain;
            transition: var(--transition-slow);
            filter: drop-shadow(0 10px 20px rgba(0,0,0,0.1));
        }

        .main-image:hover img {
            transform: scale(1.05) rotate(2deg);
        }

        .no-image {
            color: var(--neutral-500);
            font-weight: 500;
            text-align: center;
        }

        /* Product Information */
        .product-info {
            padding: 1rem 0;
        }

        .product-title {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 1rem;
            color: var(--neutral-900);
            line-height: 1.2;
            background: linear-gradient(135deg, var(--neutral-900), var(--neutral-700));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .product-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .meta-badge {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            background: var(--neutral-100);
            padding: 0.75rem 1.25rem;
            border-radius: var(--rounded-xl);
            font-size: 0.9rem;
            font-weight: 500;
            color: var(--neutral-700);
            transition: var(--transition);
        }

        .meta-badge:hover {
            background: var(--primary-50);
            color: var(--primary-700);
            transform: translateY(-2px);
        }

        .stock-status {
            font-weight: 600;
            padding: 0.5rem 1rem;
            border-radius: var(--rounded-lg);
            font-size: 0.85rem;
        }

        .in-stock {
            background: var(--success-500);
            color: var(--white);
        }

        .out-of-stock {
            background: var(--error-500);
            color: var(--white);
        }

        .product-price {
            font-size: 3rem;
            font-weight: 900;
            background: linear-gradient(135deg, var(--primary-600), var(--secondary-500));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin: 2rem 0;
            line-height: 1;
        }

        /* Specifications */
        .specs-container {
            margin: 2rem 0;
            background: var(--neutral-50);
            border-radius: var(--rounded-2xl);
            padding: 1.5rem;
            border: 1px solid var(--neutral-200);
        }

        .specs-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--neutral-800);
            margin-bottom: 1rem;
        }

        .specs-grid {
            display: grid;
            gap: 0.75rem;
        }

        .spec-item {
            display: grid;
            grid-template-columns: 140px 1fr;
            gap: 1rem;
            padding: 1rem;
            background: var(--white);
            border-radius: var(--rounded-lg);
            transition: var(--transition);
            border: 1px solid var(--neutral-200);
        }

        .spec-item:hover {
            background: var(--primary-50);
            border-color: var(--primary-200);
            transform: translateX(4px);
        }

        .spec-label {
            font-weight: 600;
            color: var(--neutral-600);
            font-size: 0.9rem;
        }

        .spec-value {
            font-weight: 500;
            color: var(--neutral-800);
        }

        /* Add to Cart Form */
        .cart-form {
            margin-top: 3rem;
            padding: 2rem;
            background: linear-gradient(135deg, var(--neutral-50), var(--primary-50));
            border-radius: var(--rounded-2xl);
            border: 1px solid var(--neutral-200);
        }

        .quantity-section {
            margin-bottom: 2rem;
        }

        .quantity-label {
            font-weight: 600;
            color: var(--neutral-700);
            margin-bottom: 0.75rem;
            display: block;
        }

        .quantity-selector {
            display: flex;
            align-items: center;
            gap: 0.25rem;
            width: fit-content;
        }

        .quantity-btn {
            width: 48px;
            height: 48px;
            background: var(--white);
            border: 2px solid var(--neutral-300);
            font-size: 1.5rem;
            font-weight: 700;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: var(--rounded-lg);
            transition: var(--transition);
            color: var(--primary-600);
        }

        .quantity-btn:hover {
            background: var(--primary-600);
            color: var(--white);
            border-color: var(--primary-600);
            transform: scale(1.1);
        }

        .quantity-input {
            width: 80px;
            height: 48px;
            text-align: center;
            border: 2px solid var(--neutral-300);
            border-radius: var(--rounded-lg);
            font-weight: 600;
            font-size: 1.1rem;
            transition: var(--transition);
            background: var(--white);
        }

        .quantity-input:focus {
            border-color: var(--primary-500);
            outline: none;
            box-shadow: 0 0 0 4px var(--primary-100);
        }

        .add-to-cart-btn {
            width: 100%;
            background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
            color: var(--white);
            border: none;
            padding: 1.25rem 2rem;
            border-radius: var(--rounded-xl);
            font-weight: 700;
            font-size: 1.125rem;
            cursor: pointer;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-lg);
        }

        .add-to-cart-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .add-to-cart-btn:hover::before {
            left: 100%;
        }

        .add-to-cart-btn:hover {
            background: linear-gradient(135deg, var(--primary-700), var(--primary-900));
            transform: translateY(-3px);
            box-shadow: var(--shadow-xl);
        }

        .add-to-cart-btn:disabled {
            background: var(--neutral-400);
            cursor: not-allowed;
            transform: none;
        }

        /* Product Description */
        .product-description {
            margin: 4rem 0;
            padding: 3rem;
            background: var(--white);
            border-radius: var(--rounded-3xl);
            box-shadow: var(--shadow-lg);
        }

        .description-title {
            font-size: 2rem;
            font-weight: 700;
            color: var(--neutral-900);
            margin-bottom: 1.5rem;
        }

        .description-text {
            font-size: 1.1rem;
            line-height: 1.8;
            color: var(--neutral-600);
        }

        /* Similar Products */
        .similar-products {
            margin: 5rem 0;
        }

        .similar-title {
            font-size: 2.5rem;
            font-weight: 800;
            text-align: center;
            color: var(--neutral-900);
            margin-bottom: 3rem;
            background: linear-gradient(135deg, var(--neutral-900), var(--primary-600));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 2rem;
        }

        .product-card {
            background: var(--white);
            border-radius: var(--rounded-2xl);
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: var(--transition);
            border: 1px solid var(--neutral-200);
        }

        .product-card:hover {
            transform: translateY(-8px) rotate(1deg);
            box-shadow: var(--shadow-xl);
            border-color: var(--primary-200);
        }

        .product-card a {
            text-decoration: none;
            color: inherit;
            display: block;
        }

        .product-image {
            height: 250px;
            background: var(--neutral-50);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
        }

        .product-image::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(45deg, transparent 49%, rgba(255,255,255,0.1) 50%, transparent 51%);
            pointer-events: none;
            opacity: 0;
            transition: var(--transition);
        }

        .product-card:hover .product-image::after {
            opacity: 1;
        }

        .product-image img {
            max-width: 85%;
            max-height: 85%;
            object-fit: contain;
            transition: var(--transition);
        }

        .product-card:hover .product-image img {
            transform: scale(1.1) rotate(-2deg);
        }

        .product-card-info {
            padding: 1.5rem;
        }

        .product-card h3 {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 0.75rem;
            color: var(--neutral-800);
            line-height: 1.3;
        }

        .product-card .price {
            font-weight: 700;
            font-size: 1.5rem;
            color: var(--primary-600);
        }

        /* Footer */
        .footer {
            background: linear-gradient(135deg, var(--neutral-900), var(--neutral-800));
            color: var(--white);
            padding: 4rem 0 2rem;
            margin-top: 6rem;
        }

        .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 3rem;
            margin-bottom: 3rem;
        }

        .footer-column h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: var(--white);
        }

        .footer-column ul {
            list-style: none;
        }

        .footer-column li {
            margin-bottom: 0.75rem;
        }

        .footer-column a {
            color: var(--neutral-300);
            text-decoration: none;
            transition: var(--transition);
            padding: 0.25rem 0;
            display: inline-block;
        }

        .footer-column a:hover {
            color: var(--white);
            transform: translateX(8px);
        }

        .copyright {
            text-align: center;
            padding-top: 2rem;
            border-top: 1px solid var(--neutral-700);
            color: var(--neutral-400);
        }

        /* Animations */
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        @keyframes fadeIn {
            from { 
                opacity: 0; 
                transform: translateY(30px); 
            }
            to { 
                opacity: 1; 
                transform: translateY(0); 
            }
        }

        @keyframes slideIn {
            from { 
                opacity: 0; 
                transform: translateX(-30px); 
            }
            to { 
                opacity: 1; 
                transform: translateX(0); 
            }
        }

        .fade-in {
            animation: fadeIn 0.6s ease-out;
        }

        .slide-in {
            animation: slideIn 0.6s ease-out;
        }

        .loading {
            position: relative;
            pointer-events: none;
        }

        .loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 24px;
            height: 24px;
            margin: -12px 0 0 -12px;
            border: 3px solid rgba(255,255,255,0.3);
            border-top: 3px solid white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .product-detail {
                grid-template-columns: 1fr;
                padding: 2rem;
                gap: 2rem;
            }
            
            .product-images {
                grid-template-columns: 1fr;
                gap: 1rem;
            }
            
            .thumbnail-list {
                flex-direction: row;
                order: 2;
                justify-content: center;
                flex-wrap: wrap;
            }
            
            .thumbnail {
                width: 100px;
                height: 100px;
            }
            
            .main-image {
                height: 400px;
            }
        }

        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .nav {
                display: none;
            }
            
            .user-actions .auth-link {
                display: none;
            }
            
            .header-content {
                flex-direction: row;
                gap: 1rem;
                padding: 1rem 0;
            }
            
            .product-title {
                font-size: 2rem;
            }
            
            .product-price {
                font-size: 2.5rem;
            }
            
            .container {
                padding: 0 1rem;
            }
        }

        @media (max-width: 480px) {
            .product-grid {
                grid-template-columns: 1fr;
            }
            
            .product-detail,
            .product-description,
            .cart-form {
                padding: 1.5rem;
            }
            
            .thumbnail-list {
                gap: 0.5rem;
            }
            
            .thumbnail {
                width: 80px;
                height: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Mobile Overlay -->
    <div class="mobile-overlay" id="mobileOverlay"></div>
    
    <!-- Mobile Sidebar -->
    <div class="mobile-sidebar" id="mobileSidebar">
        <div class="mobile-sidebar-header">
            <a href="/" class="logo"><?= htmlspecialchars(SITE_NAME) ?></a>
            <button class="mobile-sidebar-close" id="mobileSidebarClose">×</button>
        </div>
        
        <nav class="mobile-nav">
            <a href="/products/cellphones.php" class="mobile-nav-link">Cellphones</a>
            <a href="/products/computers.php" class="mobile-nav-link">Computers</a>
            <a href="/products/accessories.php" class="mobile-nav-link">Accessories</a>
        </nav>
        
        <div class="mobile-user-actions">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="/user/dashboard.php" class="auth-link">My Account</a>
                <a href="/auth/logout.php" class="auth-link">Logout</a>
            <?php else: ?>
                <a href="/auth/login.php" class="auth-link">Login</a>
                <a href="/auth/register.php" class="auth-link register">Register</a>
            <?php endif; ?>
        </div>
    </div>

    <header class="header">
        <div class="container">
            <div class="header-content">
                <button class="mobile-menu-btn" id="mobileMenuBtn">☰</button>
                
                <a href="/" class="logo"><?= htmlspecialchars(SITE_NAME) ?></a>
                
                <nav>
                    <ul class="nav">
                        <li><a href="/products/cellphones.php" class="nav-link">Cellphones</a></li>
                        <li><a href="/products/computers.php" class="nav-link">Computers</a></li>
                        <li><a href="/products/accessories.php" class="nav-link">Accessories</a></li>
                    </ul>
                </nav>
                
                <div class="user-actions">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <a href="/user/dashboard.php" class="auth-link">My Account</a>
                        <a href="/auth/logout.php" class="auth-link">Logout</a>
                    <?php else: ?>
                        <a href="/auth/login.php" class="auth-link">Login</a>
                        <a href="/auth/register.php" class="auth-link register">Register</a>
                    <?php endif; ?>
                    
                    <a href="/cart/view.php" class="cart-button">
                        Cart <span id="cart-count" class="cart-count">0</span>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <main class="container">
        <div class="product-detail fade-in">
            <div class="product-images">
                <div class="thumbnail-list">
                    <?php 
                    // Get images from JSON field
                    $images = json_decode($product['images'] ?? '[]', true);
                    if (!empty($images)): 
                        foreach ($images as $index => $image): ?>
                            <div class="thumbnail <?= $index === 0 ? 'active' : '' ?>" data-image="/assets/images/products/<?= htmlspecialchars($image) ?>">
                                <img src="/assets/images/products/<?= htmlspecialchars($image) ?>" alt="Product image <?= $index + 1 ?>">
                            </div>
                        <?php endforeach; 
                    else: ?>
                        <div class="thumbnail active">
                            <div class="no-image">No Image Available</div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="main-image">
                    <?php if (!empty($images)): ?>
                        <img src="/assets/images/products/<?= htmlspecialchars($images[0]) ?>" alt="<?= htmlspecialchars($product['name']) ?>" id="main-product-image">
                    <?php else: ?>
                        <div class="no-image">No Image Available</div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="product-info slide-in">
                <h1 class="product-title"><?= htmlspecialchars($product['name']) ?></h1>
                
                <div class="product-meta">
                    <div class="meta-badge">
                        <strong>Brand:</strong> <?= htmlspecialchars($product['brand'] ?? 'Unknown') ?>
                    </div>
                    <div class="meta-badge">
                        <strong>Category:</strong> <?= htmlspecialchars($categoryName) ?>
                    </div>
                    <div class="meta-badge">
                        <strong>Availability:</strong> 
                        <span class="stock-status <?= ($product['stock_quantity'] ?? 0) > 0 ? 'in-stock' : 'out-of-stock' ?>">
                            <?= ($product['stock_quantity'] ?? 0) > 0 ? 'In Stock (' . $product['stock_quantity'] . ' available)' : 'Out of Stock' ?>
                        </span>
                    </div>
                </div>
                
                <div class="product-price">$<?= number_format($product['price'], 2) ?></div>
                
                <div class="specs-container">
                    <h3 class="specs-title">Specifications</h3>
                    <div class="specs-grid">
                        <?php 
                        $specs = json_decode($product['specifications'] ?? '{}', true);
                        if ($specs && is_array($specs)):
                            foreach ($specs as $key => $value): 
                                if (is_array($value)) {
                                    $value = implode(', ', $value);
                                }
                            ?>
                                <div class="spec-item">
                                    <div class="spec-label"><?= ucfirst(str_replace('_', ' ', $key)) ?>:</div>
                                    <div class="spec-value"><?= htmlspecialchars($value) ?></div>
                                </div>
                            <?php endforeach; 
                        else: ?>
                            <div class="spec-item">
                                <div class="spec-label">Brand:</div>
                                <div class="spec-value"><?= htmlspecialchars($product['brand'] ?? 'Unknown') ?></div>
                            </div>
                            <div class="spec-item">
                                <div class="spec-label">Model:</div>
                                <div class="spec-value"><?= htmlspecialchars($product['model'] ?? 'Unknown') ?></div>
                            </div>
                            <?php if ($product['weight']): ?>
                            <div class="spec-item">
                                <div class="spec-label">Weight:</div>
                                <div class="spec-value"><?= htmlspecialchars($product['weight']) ?> kg</div>
                            </div>
                            <?php endif; ?>
                            <?php if ($product['dimensions']): ?>
                            <div class="spec-item">
                                <div class="spec-label">Dimensions:</div>
                                <div class="spec-value"><?= htmlspecialchars($product['dimensions']) ?></div>
                            </div>
                            <?php endif; ?>
                            <?php if ($product['warranty_period']): ?>
                            <div class="spec-item">
                                <div class="spec-label">Warranty:</div>
                                <div class="spec-value"><?= htmlspecialchars($product['warranty_period']) ?> months</div>
                            </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                
                <form class="cart-form" method="post" action="/cart/add.php">
                    <input type="hidden" name="product_id" value="<?= $product['product_id'] ?>">
                    
                    <div class="quantity-section">
                        <label class="quantity-label">Quantity:</label>
                        <div class="quantity-selector">
                            <button type="button" class="quantity-btn quantity-decrease">−</button>
                            <input type="number" name="quantity" value="1" min="1" max="<?= $product['stock_quantity'] ?? 0 ?>" class="quantity-input" <?= ($product['stock_quantity'] ?? 0) <= 0 ? 'disabled' : '' ?>>
                            <button type="button" class="quantity-btn quantity-increase">+</button>
                        </div>
                    </div>
                    
                    <button type="submit" class="add-to-cart-btn" <?= ($product['stock_quantity'] ?? 0) <= 0 ? 'disabled' : '' ?>>
                        <?= ($product['stock_quantity'] ?? 0) > 0 ? 'Add to Cart' : 'Out of Stock' ?>
                    </button>
                </form>
            </div>
        </div>
        
        <div class="product-description fade-in">
            <h2 class="description-title">Product Description</h2>
            <p class="description-text"><?= nl2br(htmlspecialchars($product['description'] ?? 'No description available.')) ?></p>
        </div>
        
        <?php if (!empty($similarProducts)): ?>
            <div class="similar-products fade-in">
                <h2 class="similar-title">You May Also Like</h2>
                <div class="product-grid">
                    <?php foreach ($similarProducts as $similar): ?>
                        <div class="product-card">
                            <a href="/products/view.php?id=<?= $similar['product_id'] ?>">
                                <div class="product-image">
                                    <?php 
                                    $similarImages = json_decode($similar['images'] ?? '[]', true);
                                    if (!empty($similarImages)): ?>
                                        <img src="/assets/images/products/<?= htmlspecialchars($similarImages[0]) ?>" alt="<?= htmlspecialchars($similar['name']) ?>">
                                    <?php else: ?>
                                        <div class="no-image">No Image Available</div>
                                    <?php endif; ?>
                                </div>
                                <div class="product-card-info">
                                    <h3><?= htmlspecialchars($similar['name']) ?></h3>
                                    <div class="price">$<?= number_format($similar['price'], 2) ?></div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-column">
                    <h3>Shop Categories</h3>
                    <ul>
                        <li><a href="/products/cellphones.php">Cellphones</a></li>
                        <li><a href="/products/computers.php">Computers</a></li>
                        <li><a href="/products/accessories.php">Accessories</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Customer Support</h3>
                    <ul>
                        <li><a href="/contact.php">Contact Us</a></li>
                        <li><a href="/faq.php">FAQ</a></li>
                        <li><a href="/returns.php">Returns Policy</a></li>
                        <li><a href="/shipping.php">Shipping Info</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Company Info</h3>
                    <ul>
                        <li><a href="/about.php">About Us</a></li>
                        <li><a href="/blog.php">Blog</a></li>
                        <li><a href="/careers.php">Careers</a></li>
                        <li><a href="/privacy.php">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; <?= date('Y') ?> <?= htmlspecialchars(SITE_NAME) ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Mobile menu functionality
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mobileSidebar = document.getElementById('mobileSidebar');
        const mobileSidebarClose = document.getElementById('mobileSidebarClose');
        const mobileOverlay = document.getElementById('mobileOverlay');

        function openMobileMenu() {
            mobileSidebar.classList.add('active');
            mobileOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeMobileMenu() {
            mobileSidebar.classList.remove('active');
            mobileOverlay.classList.remove('active');
            document.body.style.overflow = '';
        }

        mobileMenuBtn.addEventListener('click', openMobileMenu);
        mobileSidebarClose.addEventListener('click', closeMobileMenu);
        mobileOverlay.addEventListener('click', closeMobileMenu);

        // Close mobile menu on escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeMobileMenu();
            }
        });

        // Quantity selector functionality
        const quantityInput = document.querySelector('.quantity-input');
        const decreaseBtn = document.querySelector('.quantity-decrease');
        const increaseBtn = document.querySelector('.quantity-increase');
        
        if (decreaseBtn && increaseBtn && quantityInput) {
            decreaseBtn.addEventListener('click', function() {
                let value = parseInt(quantityInput.value);
                if (value > 1) {
                    quantityInput.value = value - 1;
                }
            });
            
            increaseBtn.addEventListener('click', function() {
                let value = parseInt(quantityInput.value);
                const max = parseInt(quantityInput.max);
                if (value < max) {
                    quantityInput.value = value + 1;
                }
            });
        }
        
        // Thumbnail click handler with active state and smooth transitions
        const mainImage = document.getElementById('main-product-image');
        const thumbnails = document.querySelectorAll('.thumbnail');
        
        thumbnails.forEach(thumbnail => {
            thumbnail.addEventListener('click', function() {
                // Remove active class from all thumbnails
                thumbnails.forEach(t => t.classList.remove('active'));
                // Add active class to clicked thumbnail
                this.classList.add('active');
                
                // Change main image with fade effect
                const newImageSrc = this.dataset.image;
                if (mainImage && newImageSrc) {
                    mainImage.style.opacity = '0';
                    mainImage.style.transform = 'scale(0.95)';
                    
                    setTimeout(() => {
                        mainImage.src = newImageSrc;
                        mainImage.style.opacity = '1';
                        mainImage.style.transform = 'scale(1)';
                    }, 200);
                }
            });
        });
        
        // Add to cart form submission with enhanced feedback
        const cartForm = document.querySelector('.cart-form');
        if (cartForm) {
            cartForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const form = this;
                const submitButton = form.querySelector('.add-to-cart-btn');
                const originalText = submitButton.textContent;
                
                submitButton.disabled = true;
                submitButton.classList.add('loading');
                submitButton.textContent = 'Adding...';
                
                fetch(form.action, {
                    method: 'POST',
                    body: new FormData(form),
                    headers: {
                        'Accept': 'application/json'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    submitButton.classList.remove('loading');
                    
                    if (data.success) {
                        submitButton.textContent = 'Added to Cart!';
                        submitButton.style.background = 'linear-gradient(135deg, var(--success-500), var(--success-600))';
                        
                        // Update cart count in header with animation
                        const cartCount = document.getElementById('cart-count');
                        if (cartCount) {
                            cartCount.textContent = data.count;
                            cartCount.style.animation = 'pulse 0.6s ease';
                            setTimeout(() => {
                                cartCount.style.animation = '';
                            }, 600);
                        }
                        
                        // Show success state for 2 seconds
                        setTimeout(() => {
                            submitButton.textContent = originalText;
                            submitButton.style.background = '';
                            submitButton.disabled = false;
                        }, 2000);
                    } else {
                        alert(data.message || 'Error adding to cart');
                        submitButton.textContent = originalText;
                        submitButton.disabled = false;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    submitButton.classList.remove('loading');
                    alert('An error occurred');
                    submitButton.textContent = originalText;
                    submitButton.disabled = false;
                });
            });
        }

        // Load current cart count on page load
        function loadCartCount() {
            fetch('/cart/get_count.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const cartCount = document.getElementById('cart-count');
                        if (cartCount) {
                            cartCount.textContent = data.count;
                        }
                    }
                })
                .catch(error => console.error('Error loading cart count:', error));
        }

        loadCartCount();

        // Smooth scroll animations for elements coming into view
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        // Observe elements for animation
        document.querySelectorAll('.fade-in, .slide-in').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
            el.style.transition = 'all 0.6s ease-out';
            observer.observe(el);
        });

        // Add hover effects for interactive elements
        document.querySelectorAll('.product-card, .meta-badge, .spec-item').forEach(el => {
            el.addEventListener('mouseenter', function() {
                this.style.transform = this.style.transform.includes('translateY') ? 
                    this.style.transform : 'translateY(-4px)';
            });
            
            el.addEventListener('mouseleave', function() {
                this.style.transform = '';
            });
        });
    });
    </script>
</body>
</html>