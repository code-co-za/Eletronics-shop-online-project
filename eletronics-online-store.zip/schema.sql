-- Database schema for electronics e-commerce store
CREATE DATABASE IF NOT EXISTS electronics_store;
USE electronics_store;

-- Users table
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    phone VARCHAR(20),
    address TEXT,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Products table
CREATE TABLE products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    category ENUM('cellphone','computer','accessory') NOT NULL,
    brand VARCHAR(50),
    image_main VARCHAR(255),
    images TEXT, -- JSON array of additional images
    specs JSON NOT NULL, -- {"storage":"256GB","color":"black",...}
    stock INT DEFAULT 0,
    featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Shopping cart
CREATE TABLE cart (
    cart_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    session_id VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Cart items
CREATE TABLE cart_items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    cart_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    FOREIGN KEY (cart_id) REFERENCES cart(cart_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Orders
CREATE TABLE orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    total DECIMAL(10,2) NOT NULL,
    status ENUM('pending','processing','shipped','delivered','cancelled') DEFAULT 'pending',
    payment_method VARCHAR(50),
    shipping_address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Order items
CREATE TABLE order_items (
    order_item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT,
    product_name VARCHAR(100) NOT NULL,
    product_price DECIMAL(10,2) NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Wishlist
CREATE TABLE wishlist (
    wishlist_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
    UNIQUE KEY (user_id, product_id)
) ENGINE=InnoDB;

-- Sample data
INSERT INTO users (email, password, first_name, last_name, is_admin) VALUES
('admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin', 'User', TRUE),
('customer@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'John', 'Doe', FALSE);

INSERT INTO products (name, slug, description, price, category, brand, image_main, specs, stock, featured) VALUES
('iPhone 15 Pro', 'iphone-15-pro', 'Latest iPhone with A17 Pro chip and titanium design', 999.99, 'cellphone', 'Apple', 'iphone15pro.jpg', 
 '{"storage":"128GB","color":"Titanium Black","screen":"6.1\" Super Retina XDR","camera":"Triple 48MP","battery":"3274mAh"}', 50, TRUE),

('MacBook Pro 14"', 'macbook-pro-14', 'Apple laptop with M2 Pro chip and Liquid Retina XDR display', 1999.99, 'computer', 'Apple', 'macbookpro14.jpg',
 '{"processor":"M2 Pro","ram":"16GB","storage":"512GB SSD","screen":"14.2\" Liquid Retina XDR"}', 30, TRUE),

('AirPods Pro (2nd Gen)', 'airpods-pro-2', 'Wireless noise-cancelling earbuds with Spatial Audio', 249.99, 'accessory', 'Apple', 'airpodspro2.jpg',
 '{"battery":"6hr (30hr with case)","features":["Active Noise Cancellation","Spatial Audio","Water Resistant"]}', 100, TRUE),

('Samsung Galaxy S23 Ultra', 'samsung-galaxy-s23-ultra', 'Premium Android phone with S Pen and 200MP camera', 1199.99, 'cellphone', 'Samsung', 's23ultra.jpg',
 '{"storage":"256GB","color":"Phantom Black","screen":"6.8\" Dynamic AMOLED 2X","camera":"200MP","battery":"5000mAh"}', 40, TRUE),

('Dell XPS 15', 'dell-xps-15', 'Premium Windows laptop with 4K OLED display', 1799.99, 'computer', 'Dell', 'dellxps15.jpg',
 '{"processor":"Intel Core i7","ram":"16GB","storage":"1TB SSD","screen":"15.6\" 4K OLED"}', 25, FALSE);