<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config.php';
require_once 'db_connect.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? $page_title . ' | ' . SITE_NAME : SITE_NAME ?></title>
    <link rel="stylesheet" href="/assets/css/main.css">
    <link rel="stylesheet" href="/assets/css/index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2563eb;
            --primary-hover: #1d4ed8;
            --secondary-color: #475569;
            --text-dark: #1e293b;
            --text-light: #64748b;
            --bg-light: #f8fafc;
            --border-color: #e2e8f0;
            --success-color: #10b981;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            line-height: 1.6;
            color: var(--text-dark);
        }

        /* Header Styles */
        header {
            background: #ffffff;
            border-bottom: 1px solid var(--border-color);
            box-shadow: var(--shadow-sm);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 70px;
        }

        /* Logo Styles */
        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .logo a {
            text-decoration: none;
            color: var(--primary-color);
            font-size: 1.75rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: color 0.2s ease;
        }

        .logo a:hover {
            color: var(--primary-hover);
        }

        .logo-icon {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-hover));
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.1rem;
        }

        /* Navigation Styles */
        nav {
            display: flex;
            align-items: center;
        }

        nav ul {
            display: flex;
            list-style: none;
            gap: 2rem;
            margin: 0;
            padding: 0;
        }

        nav a {
            text-decoration: none;
            color: var(--text-dark);
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            transition: all 0.2s ease;
            position: relative;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        nav a:hover {
            color: var(--primary-color);
            background-color: var(--bg-light);
        }

        nav a::before {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 2px;
            background: var(--primary-color);
            transition: width 0.2s ease;
        }

        nav a:hover::before {
            width: 80%;
        }

        /* User Actions Styles */
        .user-actions {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .user-actions a {
            text-decoration: none;
            color: var(--text-dark);
            font-weight: 500;
            padding: 0.625rem 1rem;
            border-radius: 6px;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.875rem;
        }

        .user-actions a:hover {
            color: var(--primary-color);
            background-color: var(--bg-light);
        }

        /* Special button styles */
        .btn-primary {
            background: var(--primary-color);
            color: white !important;
            border: 2px solid var(--primary-color);
        }

        .btn-primary:hover {
            background: var(--primary-hover);
            border-color: var(--primary-hover);
            color: white !important;
        }

        .btn-outline {
            border: 2px solid var(--border-color);
            background: transparent;
        }

        .btn-outline:hover {
            border-color: var(--primary-color);
            background: var(--primary-color);
            color: white !important;
        }

        .cart-badge {
            position: relative;
        }

        .cart-badge::after {
            content: '0';
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--primary-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 0.7rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }

        /* Mobile Responsive */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.25rem;
            color: var(--text-dark);
            cursor: pointer;
            padding: 0.5rem;
        }

        @media (max-width: 768px) {
            .header-container {
                padding: 0 1rem;
                height: 60px;
            }

            nav {
                display: none;
            }

            .mobile-menu-btn {
                display: block;
            }

            .logo a {
                font-size: 1.5rem;
            }

            .logo-icon {
                width: 28px;
                height: 28px;
            }

            .user-actions {
                gap: 0.5rem;
            }

            .user-actions a {
                padding: 0.5rem 0.75rem;
                font-size: 0.8rem;
            }

            .user-actions a span {
                display: none;
            }
        }

        /* Mobile Navigation Overlay */
        .mobile-nav {
            display: none;
            position: fixed;
            top: 60px;
            left: 0;
            right: 0;
            background: white;
            border-bottom: 1px solid var(--border-color);
            box-shadow: var(--shadow-md);
            padding: 1rem;
            z-index: 999;
        }

        .mobile-nav.active {
            display: block;
        }

        .mobile-nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .mobile-nav li {
            margin-bottom: 0.5rem;
        }

        .mobile-nav a {
            display: block;
            padding: 0.75rem;
            text-decoration: none;
            color: var(--text-dark);
            font-weight: 500;
            border-radius: 6px;
        }

        .mobile-nav a:hover {
            background: var(--bg-light);
            color: var(--primary-color);
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <a href="/">
                    <div class="logo-icon">
                        <i class="fas fa-bolt"></i>
                    </div>
                    <?= SITE_NAME ?>
                </a>
            </div>

            <nav class="desktop-nav">
                <ul>
                    <li><a href="/products/cellphones.php">
                        <i class="fas fa-mobile-alt"></i>
                        <span>Cellphones</span>
                    </a></li>
                    <li><a href="/products/computers.php">
                        <i class="fas fa-laptop"></i>
                        <span>Computers</span>
                    </a></li>
                    <li><a href="/products/accessories.php">
                        <i class="fas fa-headphones"></i>
                        <span>Accessories</span>
                    </a></li>
                </ul>
            </nav>

            <div class="user-actions">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="/user/dashboard.php" class="btn-outline">
                        <i class="fas fa-user"></i>
                        <span>My Account</span>
                    </a>
                    <a href="/auth/logout.php">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </a>
                <?php else: ?>
                    <a href="/auth/login.php">
                        <i class="fas fa-sign-in-alt"></i>
                        <span>Login</span>
                    </a>
                    <a href="/auth/register.php" class="btn-primary">
                        <i class="fas fa-user-plus"></i>
                        <span>Register</span>
                    </a>
                <?php endif; ?>
                <a href="/cart/view.php" class="cart-badge">
                    <i class="fas fa-shopping-cart"></i>
                    <span>Cart</span>
                </a>
            </div>

            <button class="mobile-menu-btn" onclick="toggleMobileMenu()">
                <i class="fas fa-bars"></i>
            </button>
        </div>

        <!-- Mobile Navigation -->
        <div class="mobile-nav" id="mobileNav">
            <ul>
                <li><a href="/products/cellphones.php">
                    <i class="fas fa-mobile-alt"></i> Cellphones
                </a></li>
                <li><a href="/products/computers.php">
                    <i class="fas fa-laptop"></i> Computers
                </a></li>
                <li><a href="/products/accessories.php">
                    <i class="fas fa-headphones"></i> Accessories
                </a></li>
            </ul>
        </div>
    </header>

    <script>
        function toggleMobileMenu() {
            const mobileNav = document.getElementById('mobileNav');
            mobileNav.classList.toggle('active');
        }

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            const mobileNav = document.getElementById('mobileNav');
            const mobileBtn = document.querySelector('.mobile-menu-btn');
            
            if (!mobileNav.contains(event.target) && !mobileBtn.contains(event.target)) {
                mobileNav.classList.remove('active');
            }
        });

        // Update cart badge (you can integrate this with your cart system)
        function updateCartBadge(count) {
            const badge = document.querySelector('.cart-badge::after');
            if (badge) {
                badge.textContent = count;
            }
        }
    </script>

    <main>