<?php
function getFeaturedProducts() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM products WHERE featured = 1 LIMIT 4");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function searchProducts($term) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM products WHERE name LIKE ? OR description LIKE ?");
    $stmt->execute(["%$term%", "%$term%"]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getProductsByCategory($category) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM products WHERE category = ?");
    $stmt->execute([$category]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getProductById($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM products WHERE product_id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
?>