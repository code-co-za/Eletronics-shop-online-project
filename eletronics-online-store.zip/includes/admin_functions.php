<?php
function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'];
}

function getTotalProducts() {
    global $pdo;
    $stmt = $pdo->query("SELECT COUNT(*) FROM products");
    return $stmt->fetchColumn();
}

function getTotalOrders() {
    global $pdo;
    $stmt = $pdo->query("SELECT COUNT(*) FROM orders");
    return $stmt->fetchColumn();
}

function getTotalUsers() {
    global $pdo;
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    return $stmt->fetchColumn();
}

function getAllProducts() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM products ORDER BY product_id DESC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function addProduct($name, $description, $price, $category) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO products (name, description, price, category) VALUES (?, ?, ?, ?)");
    return $stmt->execute([$name, $description, $price, $category]);
}

function updateProduct($id, $name, $description, $price, $category) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE products SET name = ?, description = ?, price = ?, category = ? WHERE product_id = ?");
    return $stmt->execute([$name, $description, $price, $category, $id]);
}

function getAllOrders() {
    global $pdo;
    $stmt = $pdo->query("
        SELECT o.*, u.email 
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        ORDER BY o.created_at DESC
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getOrderById($id) {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT o.*, u.email, u.first_name, u.last_name
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        WHERE o.order_id = ?
    ");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getOrderItems($order_id) {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT oi.*, p.name, p.price
        FROM order_items oi
        JOIN products p ON oi.product_id = p.product_id
        WHERE oi.order_id = ?
    ");
    $stmt->execute([$order_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Wrapper functions for dashboard compatibility
function getTotalProductCount() {
    return getTotalProducts();
}

function getTotalOrderCount() {
    return getTotalOrders();
}

function getTotalUserCount() {
    return getTotalUsers();
}
// Add these to your existing admin_functions.php

function getRecentUserOrders($user_id, $limit = 5) {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT * FROM orders 
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT ?
    ");
    $stmt->execute([$user_id, $limit]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getRecentOrders($limit = 5) {
    global $pdo;
    $stmt = $pdo->query("
        SELECT o.*, u.email 
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        ORDER BY o.created_at DESC
        LIMIT $limit
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getLowStockProducts($threshold = 5) {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT * FROM products
        WHERE stock <= ?
        ORDER BY stock ASC
    ");
    $stmt->execute([$threshold]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function searchAdminProducts($term) {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT * FROM products
        WHERE name LIKE ? OR description LIKE ?
        ORDER BY product_id DESC
    ");
    $stmt->execute(["%$term%", "%$term%"]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getFeaturedProducts($onlyFeatured = false) {
    global $pdo;
    $sql = "SELECT * FROM products";
    if ($onlyFeatured) {
        $sql .= " WHERE featured = 1";
    }
    $sql .= " ORDER BY product_id DESC";
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>