<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? $page_title . ' | ' . SITE_NAME : SITE_NAME ?></title>
    <link rel="stylesheet" href="/assets/css/main.css">
    <link rel="stylesheet" href="/assets/css/index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2563eb;
            --primary-hover: #1d4ed8;
            --secondary-color: #475569;
            --text-dark: #1e293b;
            --text-light: #64748b;
            --bg-light: #f8fafc;
            --border-color: #e2e8f0;
            --success-color: #10b981;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            line-height: 1.6;
            color: var(--text-dark);
        }

        /* Header Styles */
        header {
            background: #ffffff;
            border-bottom: 1px solid var(--border-color);
            box-shadow: var(--shadow-sm);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 70px;
        }

        /* Logo Styles */
        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .logo a {
            text-decoration: none;
            color: var(--primary-color);
            font-size: 1.75rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: color 0.2s ease;
        }

        .logo a:hover {
            color: var(--primary-hover);
        }

        .logo-icon {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-hover));
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.1rem;
        }

        /* Navigation Styles */
        nav {
            display: flex;
            align-items: center;
        }

        nav ul {
            display: flex;
            list-style: none;
            gap: 2rem;
            margin: 0;
            padding: 0;
        }

        nav a {
            text-decoration: none;
            color: var(--text-dark);
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            transition: all 0.2s ease;
            position: relative;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        nav a:hover {
            color: var(--primary-color);
            background-color: var(--bg-light);
        }

        nav a::before {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 2px;
            background: var(--primary-color);
            transition: width 0.2s ease;
        }

        nav a:hover::before {
            width: 80%;
        }

        /* User Actions Styles */
        .user-actions {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .user-actions a {
            text-decoration: none;
            color: var(--text-dark);
            font-weight: 500;
            padding: 0.625rem 1rem;
            border-radius: 6px;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.875rem;
        }

        .user-actions a:hover {
            color: var(--primary-color);
            background-color: var(--bg-light);
        }

        /* Special button styles */
        .btn-primary {
            background: var(--primary-color);
            color: white !important;
            border: 2px solid var(--primary-color);
        }

        .btn-primary:hover {
            background: var(--primary-hover);
            border-color: var(--primary-hover);
            color: white !important;
        }

        .btn-outline {
            border: 2px solid var(--border-color);
            background: transparent;
        }

        .btn-outline:hover {
            border-color: var(--primary-color);
            background: var(--primary-color);
            color: white !important;
        }

        .cart-badge {
            position: relative;
        }

        .cart-badge::after {
            content: '0';
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--primary-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 0.7rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }

        /* Mobile Responsive */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 1.25rem;
            color: var(--text-dark);
            cursor: pointer;
            padding: 0.5rem;
        }

        @media (max-width: 768px) {
            .header-container {
                padding: 0 1rem;
                height: 60px;
            }

            nav {
                display: none;
            }

            .mobile-menu-btn {
                display: block;
            }

            .logo a {
                font-size: 1.5rem;
            }

            .logo-icon {
                width: 28px;
                height: 28px;
            }

            .user-actions {
                gap: 0.5rem;
            }

            .user-actions a {
                padding: 0.5rem 0.75rem;
                font-size: 0.8rem;
            }

            .user-actions a span {
                display: none;
            }
        }

        /* Mobile Navigation Overlay */
        .mobile-nav {
            display: none;
            position: fixed;
            top: 60px;
            left: 0;
            right: 0;
            background: white;
            border-bottom: 1px solid var(--border-color);
            box-shadow: var(--shadow-md);
            padding: 1rem;
            z-index: 999;
        }

        .mobile-nav.active {
            display: block;
        }

        .mobile-nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .mobile-nav li {
            margin-bottom: 0.5rem;
        }

        .mobile-nav a {
            display: block;
            padding: 0.75rem;
            text-decoration: none;
            color: var(--text-dark);
            font-weight: 500;
            border-radius: 6px;
        }

        .mobile-nav a:hover {
            background: var(--bg-light);
            color: var(--primary-color);
        }

        /* Footer Styles */
        footer {
            background: var(--text-dark);
            color: #e2e8f0;
            margin-top: auto;
        }

        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1rem;
        }

        .footer-top {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            padding: 3rem 0 2rem;
        }

        .footer-section h3,
        .footer-section h4 {
            color: white;
            margin-bottom: 1rem;
            font-weight: 600;
        }

        .footer-section h4 {
            font-size: 1.1rem;
        }

        .footer-logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 1rem;
        }

        .footer-logo .logo-icon {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-hover));
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.1rem;
        }

        .footer-description {
            color: #94a3b8;
            line-height: 1.6;
            margin-bottom: 1.5rem;
        }

        .social-links {
            display: flex;
            gap: 1rem;
        }

        .social-links a {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: #e2e8f0;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .social-links a:hover {
            background: var(--primary-color);
            color: white;
            transform: translateY(-2px);
        }

        .footer-section ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-section ul li {
            margin-bottom: 0.5rem;
        }

        .footer-section ul a {
            color: #94a3b8;
            text-decoration: none;
            transition: color 0.2s ease;
        }

        .footer-section ul a:hover {
            color: var(--primary-color);
        }

        /* Newsletter Form */
        .newsletter-form {
            margin-bottom: 2rem;
        }

        .newsletter-form p {
            color: #94a3b8;
            margin-bottom: 1rem;
            font-size: 0.9rem;
        }

        .input-group {
            display: flex;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .input-group input {
            flex: 1;
            padding: 0.75rem 1rem;
            border: none;
            background: transparent;
            color: white;
            outline: none;
        }

        .input-group input::placeholder {
            color: #94a3b8;
        }

        .input-group button {
            padding: 0.75rem 1rem;
            border: none;
            background: var(--primary-color);
            color: white;
            cursor: pointer;
            transition: background 0.2s ease;
        }

        .input-group button:hover {
            background: var(--primary-hover);
        }

        /* Payment Methods */
        .payment-methods {
            margin-top: 1.5rem;
        }

        .payment-methods h5 {
            color: white;
            font-size: 0.9rem;
            margin-bottom: 0.75rem;
            font-weight: 500;
        }

        .payment-icons {
            display: flex;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .payment-icons i {
            font-size: 1.5rem;
            color: #94a3b8;
            transition: color 0.2s ease;
        }

        .payment-icons i:hover {
            color: var(--primary-color);
        }

        /* Footer Bottom */
        .footer-bottom {
            border-top: 1px solid #374151;
            padding: 1.5rem 0;
        }

        .footer-bottom-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .footer-bottom p {
            color: #94a3b8;
            margin: 0;
        }

        .footer-links {
            display: flex;
            gap: 1.5rem;
        }

        .footer-links a {
            color: #94a3b8;
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.2s ease;
        }

        .footer-links a:hover {
            color: var(--primary-color);
        }

        /* Footer Mobile Responsive */
        @media (max-width: 768px) {
            .footer-top {
                grid-template-columns: 1fr;
                gap: 2rem;
                padding: 2rem 0 1.5rem;
            }

            .footer-bottom-content {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }

            .footer-links {
                justify-content: center;
            }

            .social-links {
                justify-content: center;
            }

            .payment-icons {
                justify-content: center;
            }
        }

        /* Ensure footer stays at bottom */
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        main {
            flex: 1;
        }
    </style>
</head>
<body>

    <script>
        function toggleMobileMenu() {
            const mobileNav = document.getElementById('mobileNav');
            mobileNav.classList.toggle('active');
        }

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            const mobileNav = document.getElementById('mobileNav');
            const mobileBtn = document.querySelector('.mobile-menu-btn');
            
            if (!mobileNav.contains(event.target) && !mobileBtn.contains(event.target)) {
                mobileNav.classList.remove('active');
            }
        });

        // Update cart badge (you can integrate this with your cart system)
        function updateCartBadge(count) {
            const badge = document.querySelector('.cart-badge::after');
            if (badge) {
                badge.textContent = count;
            }
        }
    </script>

    <main>
        <!-- Your page content goes here -->
    </main>

    <footer>
        <div class="footer-container">
            <!-- Footer Top Section -->
            <div class="footer-top">
                <div class="footer-section">
                    <div class="footer-logo">
                        <div class="logo-icon">
                            <i class="fas fa-bolt"></i>
                        </div>
                        <h3><?= SITE_NAME ?></h3>
                    </div>
                    <p class="footer-description">Your trusted partner for cutting-edge electronics. Quality products, competitive prices, and exceptional service.</p>
                    <div class="social-links">
                        <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                        <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                        <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>

                <div class="footer-section">
                    <h4>Products</h4>
                    <ul>
                        <li><a href="/products/cellphones.php">Smartphones</a></li>
                        <li><a href="/products/computers.php">Laptops & Desktops</a></li>
                        <li><a href="/products/accessories.php">Accessories</a></li>
                        <li><a href="/products/tablets.php">Tablets</a></li>
                        <li><a href="/products/gaming.php">Gaming</a></li>
                    </ul>
                </div>

                <div class="footer-section">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="/support/contact.php">Contact Us</a></li>
                        <li><a href="/support/faq.php">FAQ</a></li>
                        <li><a href="/support/warranty.php">Warranty</a></li>
                        <li><a href="/support/returns.php">Returns</a></li>
                        <li><a href="/support/shipping.php">Shipping Info</a></li>
                    </ul>
                </div>

                <div class="footer-section">
                    <h4>Company</h4>
                    <ul>
                        <li><a href="/about.php">About Us</a></li>
                        <li><a href="/careers.php">Careers</a></li>
                        <li><a href="/news.php">News</a></li>
                        <li><a href="/privacy.php">Privacy Policy</a></li>
                        <li><a href="/terms.php">Terms of Service</a></li>
                    </ul>
                </div>

                <div class="footer-section">
                    <h4>Newsletter</h4>
                    <p>Stay updated with our latest offers and products.</p>
                    <form class="newsletter-form" action="/newsletter/subscribe.php" method="POST">
                        <div class="input-group">
                            <input type="email" name="email" placeholder="Enter your email" required>
                            <button type="submit">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </div>
                    </form>
                    <div class="payment-methods">
                        <h5>We Accept</h5>
                        <div class="payment-icons">
                            <i class="fab fa-cc-visa"></i>
                            <i class="fab fa-cc-mastercard"></i>
                            <i class="fab fa-cc-paypal"></i>
                            <i class="fab fa-cc-apple-pay"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer Bottom Section -->
            <div class="footer-bottom">
                <div class="footer-bottom-content">
                    <p>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. All rights reserved.</p>
                    <div class="footer-links">
                        <a href="/privacy.php">Privacy</a>
                        <a href="/terms.php">Terms</a>
                        <a href="/cookies.php">Cookies</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>