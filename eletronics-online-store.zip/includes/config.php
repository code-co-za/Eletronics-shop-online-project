<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'electronics_store');
define('DB_USER', 'root');
define('DB_PASS', '');

// Site configuration
define('SITE_NAME', 'ElectroShop');
define('BASE_URL', 'http://localhost/Ecommerc');
?>