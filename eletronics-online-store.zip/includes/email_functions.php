<?php
function sendPasswordResetEmail($email) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if (!$user) return true; // Don't reveal if email exists
    
    $token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
    
    $stmt = $pdo->prepare("
        INSERT INTO password_resets (user_id, token, expires_at)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE token = ?, expires_at = ?
    ");
    $stmt->execute([$user['user_id'], $token, $expires, $token, $expires]);
    
    // In a real app, you would send an email here with the reset link
    // For example: $resetLink = BASE_URL . "/auth/reset.php?token=$token";
    
    return true;
}

function resetPassword($token, $newPassword) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT pr.user_id 
        FROM password_resets pr
        WHERE pr.token = ? AND pr.expires_at > NOW()
    ");
    $stmt->execute([$token]);
    $reset = $stmt->fetch();
    
    if (!$reset) return false;
    
    $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
    $stmt->execute([$hashed, $reset['user_id']]);
    
    // Delete the used token
    $pdo->prepare("DELETE FROM password_resets WHERE user_id = ?")->execute([$reset['user_id']]);
    
    return true;
}
?>