<?php
function getCartItems($userId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT p.*, ci.quantity 
        FROM cart_items ci
        JOIN products p ON ci.product_id = p.product_id
        WHERE ci.cart_id = (SELECT cart_id FROM cart WHERE user_id = ?)
    ");
    $stmt->execute([$userId]);
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function calculateCartTotal($items) {
    $total = 0;
    foreach ($items as $item) {
        $total += $item['price'] * $item['quantity'];
    }
    return $total;
}

function addToCart($userId, $productId, $quantity = 1) {
    global $pdo;

    // Get existing cart ID or create one
    $stmt = $pdo->prepare("SELECT cart_id FROM cart WHERE user_id = ?");
    $stmt->execute([$userId]);
    $cart = $stmt->fetch();

    if (!$cart) {
        $stmt = $pdo->prepare("INSERT INTO cart (user_id) VALUES (?)");
        $stmt->execute([$userId]);
        $cartId = $pdo->lastInsertId();
    } else {
        $cartId = $cart['cart_id'];
    }

    // Add or update product in cart
    $stmt = $pdo->prepare("
        INSERT INTO cart_items (cart_id, product_id, quantity) 
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)
    ");
    return $stmt->execute([$cartId, $productId, $quantity]);
}

function getCartCount($userId) {
    global $pdo;

    try {
        $stmt = $pdo->prepare("
            SELECT SUM(quantity) as count 
            FROM cart_items 
            WHERE cart_id = (SELECT cart_id FROM cart WHERE user_id = ?)
        ");
        $stmt->execute([$userId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0;
    } catch (PDOException $e) {
        error_log("Error getting cart count: " . $e->getMessage());
        return 0;
    }
}
?>
