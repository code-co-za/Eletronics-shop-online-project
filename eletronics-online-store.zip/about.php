<?php
require_once 'includes/header.php';
$page_title = 'About Us';
?>
<h1>About Our Store</h1>
<div class="about-content">
    <p>Welcome to our electronics store! We specialize in providing the latest cellphones, computers, and accessories at competitive prices.</p>
    <p>Our mission is to deliver high-quality products with excellent customer service.</p>
</div>
<?php
require_once 'includes/footer.php';
?>