document.addEventListener('DOMContentLoaded', function() {
    // Main JavaScript functionality
    console.log('Site loaded');
});
// if duplicated
document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const menuToggle = document.querySelector('.mobile-menu-toggle');
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            document.querySelector('nav').classList.toggle('active');
        });
    }
    
    // Notification timeout
    const notifications = document.querySelectorAll('.error, .success');
    notifications.forEach(notification => {
        setTimeout(() => {
            notification.style.display = 'none';
        }, 5000);
    });
});