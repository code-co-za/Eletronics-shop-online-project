/**
 * Professional Computers Page JavaScript
 * Handles interactivity, AJAX requests, and user experience enhancements
 */

class ComputersPage {
    constructor() {
        this.init();
        this.bindEvents();
        this.setupIntersectionObserver();
    }

    init() {
        // Initialize page components
        this.loadingOverlay = document.getElementById('loadingOverlay');
        this.toastContainer = document.getElementById('toastContainer');
        this.filterForm = document.getElementById('filterForm');
        this.productGrid = document.getElementById('productGrid');
        this.mobileFilterToggle = document.getElementById('mobileFilterToggle');
        
        // Initialize cart from localStorage
        this.cart = JSON.parse(localStorage.getItem('cart')) || [];
        
        // Initialize wishlist from localStorage
        this.wishlist = JSON.parse(localStorage.getItem('wishlist')) || [];
        
        // Update UI based on saved data
        this.updateCartUI();
        this.updateWishlistUI();
        
        // Apply any saved filter preferences
        this.applySavedFilters();
    }

    bindEvents() {
        // Filter form submission
        if (this.filterForm) {
            this.filterForm.addEventListener('submit', (e) => {
                this.handleFilterSubmit(e);
            });
            
            // Auto-submit on select change for better UX
            const selects = this.filterForm.querySelectorAll('select');
            selects.forEach(select => {
                select.addEventListener('change', () => {
                    this.debounce(() => this.handleFilterSubmit(), 300)();
                });
            });
        }

        // Mobile filter toggle
        if (this.mobileFilterToggle) {
            this.mobileFilterToggle.addEventListener('click', () => {
                this.toggleMobileFilters();
            });
        }

        // Add to cart buttons
        document.addEventListener('click', (e) => {
            if (e.target.closest('.add-to-cart-btn')) {
                e.preventDefault();
                const btn = e.target.closest('.add-to-cart-btn');
                const productId = btn.dataset.productId;
                this.addToCart(productId, btn);
            }
        });

        // Wishlist buttons
        document.addEventListener('click', (e) => {
            if (e.target.closest('.wishlist-btn')) {
                e.preventDefault();
                const btn = e.target.closest('.wishlist-btn');
                const productId = btn.dataset.productId;
                this.toggleWishlist(productId, btn);
            }
        });

        // Quick view buttons
        document.addEventListener('click', (e) => {
            if (e.target.closest('.quick-view-btn')) {
                e.preventDefault();
                const btn = e.target.closest('.quick-view-btn');
                const productId = btn.dataset.productId;
                this.showQuickView(productId);
            }
        });

        // Pagination with smooth scrolling
        document.addEventListener('click', (e) => {
            if (e.target.closest('.pagination a')) {
                e.preventDefault();
                const link = e.target.closest('.pagination a');
                this.navigatePage(link.href);
            }
        });

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            this.handleKeyboardNavigation(e);
        });

        // Window events
        window.addEventListener('resize', this.debounce(() => {
            this.handleResize();
        }, 250));

        window.addEventListener('scroll', this.throttle(() => {
            this.handleScroll();
        }, 100));
    }

    setupIntersectionObserver() {
        // Lazy loading for product images
        const imageObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                        imageObserver.unobserve(img);
                    }
                }
            });
        }, {
            rootMargin: '50px'
        });

        // Observe all product images
        document.querySelectorAll('img[data-src]').forEach(img => {
            imageObserver.observe(img);
        });

        // Animation observer for scroll animations
        const animationObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.animationDelay = `${Math.random() * 0.3}s`;
                    entry.target.setAttribute('data-aos', 'fade-up');
                    animationObserver.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1
        });

        // Observe product cards for staggered animations
        document.querySelectorAll('.product-card').forEach((card, index) => {
            animationObserver.observe(card);
        });
    }

    handleFilterSubmit(e) {
        if (e) e.preventDefault();
        
        this.showLoading();
        
        // Save filter preferences
        const formData = new FormData(this.filterForm);
        const filters = Object.fromEntries(formData);
        localStorage.setItem('computerFilters', JSON.stringify(filters));
        
        // Simulate API call (replace with actual AJAX in production)
        setTimeout(() => {
            this.filterForm.submit();
        }, 500);
    }

    toggleMobileFilters() {
        const filtersSection = document.querySelector('.filters-section');
        const isExpanded = filtersSection.classList.contains('mobile-expanded');
        
        if (isExpanded) {
            filtersSection.classList.remove('mobile-expanded');
            this.mobileFilterToggle.innerHTML = '<i class="fas fa-sliders-h"></i> Filters';
        } else {
            filtersSection.classList.add('mobile-expanded');
            this.mobileFilterToggle.innerHTML = '<i class="fas fa-times"></i> Close';
        }
    }

    async addToCart(productId, button) {
        if (!productId) return;
        
        const originalText = button.innerHTML;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';
        button.disabled = true;
        
        try {
            // Simulate API call
            await this.simulateApiCall();
            
            // Add to cart array
            const existingItem = this.cart.find(item => item.id === productId);
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                this.cart.push({
                    id: productId,
                    quantity: 1,
                    addedAt: new Date().toISOString()
                });
            }
            
            // Save to localStorage
            localStorage.setItem('cart', JSON.stringify(this.cart));
            
            // Update UI
            this.updateCartUI();
            
            // Show success message
            this.showToast('Product added to cart successfully!', 'success');
            
            // Update button temporarily
            button.innerHTML = '<i class="fas fa-check"></i> Added!';
            button.classList.add('success');
            
            setTimeout(() => {
                button.innerHTML = originalText;
                button.classList.remove('success');
                button.disabled = false;
            }, 2000);
            
        } catch (error) {
            console.error('Error adding to cart:', error);
            this.showToast('Failed to add product to cart. Please try again.', 'error');
            
            button.innerHTML = originalText;
            button.disabled = false;
        }
    }

    toggleWishlist(productId, button) {
        if (!productId) return;
        
        const isInWishlist = this.wishlist.includes(productId);
        const icon = button.querySelector('i');
        
        if (isInWishlist) {
            // Remove from wishlist
            this.wishlist = this.wishlist.filter(id => id !== productId);
            icon.classList.remove('fas');
            icon.classList.add('far');
            button.classList.remove('active');
            this.showToast('Removed from wishlist', 'warning');
        } else {
            // Add to wishlist
            this.wishlist.push(productId);
            icon.classList.remove('far');
            icon.classList.add('fas');
            button.classList.add('active');
            this.showToast('Added to wishlist', 'success');
        }
        
        // Save to localStorage
        localStorage.setItem('wishlist', JSON.stringify(this.wishlist));
        this.updateWishlistUI();
    }

    async showQuickView(productId) {
        if (!productId) return;
        
        this.showLoading();
        
        try {
            // Simulate API call to get product details
            await this.simulateApiCall(1000);
            
            // In a real application, you would fetch product details
            // and show them in a modal
            this.showToast('Quick view feature coming soon!', 'warning');
            
        } catch (error) {
            console.error('Error loading product details:', error);
            this.showToast('Failed to load product details', 'error');
        } finally {
            this.hideLoading();
        }
    }

    async navigatePage(url) {
        this.showLoading();
        
        // Smooth scroll to top
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
        
        // Simulate loading delay for better UX
        setTimeout(() => {
            window.location.href = url;
        }, 300);
    }

    handleKeyboardNavigation(e) {
        // Add keyboard shortcuts for better accessibility
        if (e.ctrlKey || e.metaKey) {
            switch (e.key) {
                case 'f':
                    e.preventDefault();
                    const brandSelect = document.getElementById('brand');
                    if (brandSelect) brandSelect.focus();
                    break;
                case 's':
                    e.preventDefault();
                    const sortSelect = document.getElementById('sort');
                    if (sortSelect) sortSelect.focus();
                    break;
            }
        }
        
        // Escape key to close mobile filters
        if (e.key === 'Escape') {
            const filtersSection = document.querySelector('.filters-section');
            if (filtersSection && filtersSection.classList.contains('mobile-expanded')) {
                this.toggleMobileFilters();
            }
        }
    }

    handleResize() {
        // Close mobile filters on resize to desktop
        if (window.innerWidth > 768) {
            const filtersSection = document.querySelector('.filters-section');
            if (filtersSection && filtersSection.classList.contains('mobile-expanded')) {
                filtersSection.classList.remove('mobile-expanded');
                this.mobileFilterToggle.innerHTML = '<i class="fas fa-sliders-h"></i> Filters';
            }
        }
    }

    handleScroll() {
        // Add scroll-based enhancements if needed
        const scrollTop = window.pageYOffset;
        
        // Show/hide back to top button
        const backToTop = document.querySelector('.back-to-top');
        if (backToTop) {
            if (scrollTop > 500) {
                backToTop.classList.add('visible');
            } else {
                backToTop.classList.remove('visible');
            }
        }
    }

    updateCartUI() {
        // Update cart count in header (if exists)
        const cartCount = document.querySelector('.cart-count');
        if (cartCount) {
            const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);
            cartCount.textContent = totalItems;
            cartCount.style.display = totalItems > 0 ? 'block' : 'none';
        }
    }

    updateWishlistUI() {
        // Update wishlist buttons state
        document.querySelectorAll('.wishlist-btn').forEach(btn => {
            const productId = btn.dataset.productId;
            const icon = btn.querySelector('i');
            
            if (this.wishlist.includes(productId)) {
                icon.classList.remove('far');
                icon.classList.add('fas');
                btn.classList.add('active');
            } else {
                icon.classList.remove('fas');
                icon.classList.add('far');
                btn.classList.remove('active');
            }
        });
        
        // Update wishlist count in header (if exists)
        const wishlistCount = document.querySelector('.wishlist-count');
        if (wishlistCount) {
            wishlistCount.textContent = this.wishlist.length;
            wishlistCount.style.display = this.wishlist.length > 0 ? 'block' : 'none';
        }
    }

    applySavedFilters() {
        // Apply saved filter preferences
        const savedFilters = localStorage.getItem('computerFilters');
        if (savedFilters) {
            try {
                const filters = JSON.parse(savedFilters);
                Object.keys(filters).forEach(key => {
                    const element = document.querySelector(`[name="${key}"]`);
                    if (element && filters[key]) {
                        element.value = filters[key];
                    }
                });
            } catch (error) {
                console.error('Error applying saved filters:', error);
            }
        }
    }

    showLoading() {
        if (this.loadingOverlay) {
            this.loadingOverlay.classList.add('active');
        }
    }

    hideLoading() {
        if (this.loadingOverlay) {
            this.loadingOverlay.classList.remove('active');
        }
    }

    showToast(message, type = 'info') {
        if (!this.toastContainer) return;
        
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        const icon = this.getToastIcon(type);
        toast.innerHTML = `
            <i class="${icon}"></i>
            <span>${message}</span>
        `;
        
        this.toastContainer.appendChild(toast);
        
        // Auto remove after 4 seconds
        setTimeout(() => {
            toast.style.animation = 'slideOutRight 0.3s ease forwards';
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.parentNode.removeChild(toast);
                }
            }, 300);
        }, 4000);
    }

    getToastIcon(type) {
        const icons = {
            success: 'fas fa-check-circle',
            error: 'fas fa-exclamation-circle',
            warning: 'fas fa-exclamation-triangle',
            info: 'fas fa-info-circle'
        };
        return icons[type] || icons.info;
    }

    async simulateApiCall(delay = 500) {
        return new Promise((resolve) => {
            setTimeout(resolve, delay);
        });
    }

    // Utility functions
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }
}

// CSS Animation for toast exit
const style = document.createElement('style');
style.textContent = `
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .filters-section.mobile-expanded .filter-grid {
        display: grid !important;
    }
    
    @media (max-width: 768px) {
        .filter-grid {
            display: none;
        }
    }
    
    .btn.success {
        background: var(--success-color) !important;
    }
    
    .wishlist-btn.active {
        background: rgba(239, 68, 68, 0.1);
        color: var(--error-color);
    }
    
    .back-to-top {
        position: fixed;
        bottom: 2rem;
        right: 2rem;
        width: 3rem;
        height: 3rem;
        background: var(--primary-color);
        color: white;
        border: none;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: var(--shadow-lg);
        opacity: 0;
        visibility: hidden;
        transition: var(--transition-normal);
        z-index: 100;
    }
    
    .back-to-top.visible {
        opacity: 1;
        visibility: visible;
    }
    
    .back-to-top:hover {
        background: var(--primary-dark);
        transform: translateY(-2px);
    }
`;
document.head.appendChild(style);

// Initialize the computers page when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new ComputersPage();
});

// Add back to top button
const backToTop = document.createElement('button');
backToTop.className = 'back-to-top';
backToTop.innerHTML = '<i class="fas fa-chevron-up"></i>';
backToTop.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});
document.body.appendChild(backToTop);

// Service Worker registration for PWA features (optional)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then((registration) => {
                console.log('SW registered: ', registration);
            })
            .catch((registrationError) => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}