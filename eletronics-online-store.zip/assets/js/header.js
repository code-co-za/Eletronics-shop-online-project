// /assets/js/header.js

document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu functionality
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mainNav = document.querySelector('.main-nav');
    
    if (mobileMenuToggle && mainNav) {
        mobileMenuToggle.addEventListener('click', function() {
            const isExpanded = this.getAttribute('aria-expanded') === 'true';
            
            // Toggle aria-expanded attribute
            this.setAttribute('aria-expanded', !isExpanded);
            
            // Toggle mobile nav class
            mainNav.classList.toggle('mobile-nav-open');
            
            // Focus management for accessibility
            if (!isExpanded) {
                // When opening menu, focus first nav link
                const firstNavLink = mainNav.querySelector('.nav-link');
                if (firstNavLink) {
                    setTimeout(() => firstNavLink.focus(), 100);
                }
            }
        });
        
        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!mobileMenuToggle.contains(event.target) && 
                !mainNav.contains(event.target) && 
                mainNav.classList.contains('mobile-nav-open')) {
                
                mobileMenuToggle.setAttribute('aria-expanded', 'false');
                mainNav.classList.remove('mobile-nav-open');
            }
        });
        
        // Close mobile menu on escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && mainNav.classList.contains('mobile-nav-open')) {
                mobileMenuToggle.setAttribute('aria-expanded', 'false');
                mainNav.classList.remove('mobile-nav-open');
                mobileMenuToggle.focus();
            }
        });
    }
    
    // Cart count functionality
    function updateCartCount() {
        // This would typically fetch from your backend
        // For now, we'll check if there's a cart count in localStorage or session
        const cartCount = getCartItemCount();
        const cartCountElement = document.getElementById('cart-count');
        
        if (cartCountElement) {
            cartCountElement.textContent = cartCount;
            cartCountElement.style.display = cartCount > 0 ? 'flex' : 'none';
        }
    }
    
    function getCartItemCount() {
        // This is a placeholder - replace with your actual cart logic
        // You might want to make an AJAX call to get the current cart count
        // or read from localStorage if you're storing cart data there
        
        // Example: return sessionStorage.getItem('cartCount') || 0;
        return 0; // Replace with actual cart count logic
    }
    
    // Initialize cart count on page load
    updateCartCount();
    
    // Update cart count when storage changes (for multi-tab support)
    window.addEventListener('storage', function(event) {
        if (event.key === 'cartCount') {
            updateCartCount();
        }
    });
    
    // Smooth scrolling for anchor links (if any)
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    anchorLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                event.preventDefault();
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Header scroll effect (optional - adds/removes class based on scroll)
    let lastScrollTop = 0;
    const header = document.querySelector('.site-header');
    
    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        if (scrollTop > lastScrollTop && scrollTop > 100) {
            // Scrolling down
            header.classList.add('header-hidden');
        } else {
            // Scrolling up
            header.classList.remove('header-hidden');
        }
        
        lastScrollTop = scrollTop;
    }, { passive: true });
});