document.addEventListener('DOMContentLoaded', function() {
    const filterForm = document.querySelector('.filters form');
    
    if (filterForm) {
        filterForm.addEventListener('change', function() {
            this.submit();
        });
    }
});
