// Professional Cellphone Catalog JavaScript

class CellphoneCatalog {
    constructor() {
        this.currentPage = 1;
        this.isLoading = false;
        this.filters = {
            search: '',
            brand: '',
            sort: 'newest',
            min_price: '',
            max_price: ''
        };
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.initializeViewToggle();
        this.initializeAnimations();
    }
    
    bindEvents() {
        // Filter form submission
        const filterForm = document.getElementById('filter-form');
        if (filterForm) {
            filterForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.applyFilters();
            });
        }
        
        // Real-time search
        const searchInput = document.getElementById('search');
        if (searchInput) {
            let searchTimeout;
            searchInput.addEventListener('input', (e) => {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    this.filters.search = e.target.value;
                    this.applyFilters();
                }, 300);
            });
        }
        
        // Filter changes
        const filterInputs = ['brand', 'sort', 'min-price', 'max-price'];
        filterInputs.forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.addEventListener('change', () => {
                    this.updateFiltersFromForm();
                    this.applyFilters();
                });
            }
        });
        
        // Clear filters
        const clearBtn = document.getElementById('clear-filters');
        if (clearBtn) {
            clearBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.clearFilters();
            });
        }
        
        // Pagination
        this.bindPaginationEvents();
        
        // Add to cart buttons
        this.bindCartEvents();
        
        // Wishlist buttons
        this.bindWishlistEvents();
        
        // View toggle
        this.bindViewToggle();
        
        // Quick view
        this.bindQuickViewEvents();
    }
    
    bindPaginationEvents() {
        document.addEventListener('click', (e) => {
            if (e.target.matches('.pagination-number, .pagination-btn')) {
                e.preventDefault();
                const page = parseInt(e.target.getAttribute('data-page'));
                if (page && page !== this.currentPage) {
                    this.loadPage(page);
                }
            }
        });
    }
    
    bindCartEvents() {
        document.addEventListener('click', (e) => {
            if (e.target.matches('.add-to-cart-btn') || e.target.closest('.add-to-cart-btn')) {
                e.preventDefault();
                const btn = e.target.matches('.add-to-cart-btn') ? e.target : e.target.closest('.add-to-cart-btn');
                const productId = btn.getAttribute('data-product-id');
                this.addToCart(productId, btn);
            }
        });
    }
    
    bindWishlistEvents() {
        document.addEventListener('click', (e) => {
            if (e.target.matches('.wishlist-btn') || e.target.closest('.wishlist-btn')) {
                e.preventDefault();
                const btn = e.target.matches('.wishlist-btn') ? e.target : e.target.closest('.wishlist-btn');
                const productId = btn.getAttribute('data-product-id');
                this.toggleWishlist(productId, btn);
            }
        });
    }
    
    bindViewToggle() {
        document.addEventListener('click', (e) => {
            if (e.target.matches('.view-btn')) {
                const viewType = e.target.getAttribute('data-view');
                this.switchView(viewType);
            }
        });
    }
    
    bindQuickViewEvents() {
        document.addEventListener('click', (e) => {
            if (e.target.matches('.quick-view-btn')) {
                e.preventDefault();
                const productId = e.target.getAttribute('data-product-id');
                this.openQuickView(productId);
            }
        });
    }
    
    updateFiltersFromForm() {
        this.filters.search = document.getElementById('search')?.value || '';
        this.filters.brand = document.getElementById('brand')?.value || '';
        this.filters.sort = document.getElementById('sort')?.value || 'newest';
        this.filters.min_price = document.getElementById('min-price')?.value || '';
        this.filters.max_price = document.getElementById('max-price')?.value || '';
    }
    
    applyFilters() {
        if (this.isLoading) return;
        
        this.updateFiltersFromForm();
        this.currentPage = 1;
        this.loadProducts();
    }
    
    clearFilters() {
        this.filters = {
            search: '',
            brand: '',
            sort: 'newest',
            min_price: '',
            max_price: ''
        };
        
        // Reset form
        document.getElementById('search').value = '';
        document.getElementById('brand').value = '';
        document.getElementById('sort').value = 'newest';
        document.getElementById('min-price').value = '';
        document.getElementById('max-price').value = '';
        
        this.currentPage = 1;
        this.loadProducts();
    }
    
    loadPage(page) {
        if (this.isLoading || page === this.currentPage) return;
        
        this.currentPage = page;
        this.loadProducts();
        
        // Smooth scroll to top of products
        document.querySelector('.products-section').scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
    
    async loadProducts() {
        if (this.isLoading) return;
        
        this.isLoading = true;
        this.showLoading();
        
        try {
            // Build query string
            const params = new URLSearchParams({
                ajax: '1',
                page: this.currentPage,
                ...this.filters
            });
            
            // Remove empty filters
            Object.keys(this.filters).forEach(key => {
                if (!this.filters[key]) {
                    params.delete(key);
                }
            });
            
            const response = await fetch(`cellphones.php?${params.toString()}`);
            
            if (!response.ok) {
                throw new Error('Failed to load products');
            }
            
            const data = await response.json();
            this.renderProducts(data);
            this.updatePagination(data);
            this.updateResultsInfo(data);
            
        } catch (error) {
            console.error('Error loading products:', error);
            this.showError('Failed to load products. Please try again.');
        } finally {
            this.isLoading = false;
            this.hideLoading();
        }
    }
    
    renderProducts(data) {
        const grid = document.getElementById('products-grid');
        if (!grid) return;
        
        if (data.products.length === 0) {
            grid.innerHTML = `
                <div class="no-results">
                    <div class="no-results-icon">📱</div>
                    <h3>No cellphones found</h3>
                    <p>Try adjusting your filters or search terms.</p>
                </div>
            `;
            return;
        }
        
        const productsHtml = data.products.map(product => this.renderProductCard(product)).join('');
        grid.innerHTML = productsHtml;
        
        // Animate cards in
        this.animateCardsIn();
    }
    
    renderProductCard(product) {
        const specs = product.specs ? JSON.parse(product.specs) : {};
        const hasDiscount = product.original_price && product.original_price > product.price;
        const discountPercent = hasDiscount ? 
            Math.round(((product.original_price - product.price) / product.original_price) * 100) : 0;
        
        return `
            <article class="product-card" data-product-id="${product.product_id}">
                <div class="product-image-container">
                    ${product.image_main ? 
                        `<img src="/assets/images/products/${this.escapeHtml(product.image_main)}" 
                             alt="${this.escapeHtml(product.name)}"
                             class="product-image"
                             loading="lazy">` :
                        `<div class="no-image">
                            <div class="no-image-icon">📱</div>
                            <span>No Image Available</span>
                        </div>`
                    }
                    <div class="product-overlay">
                        <button class="quick-view-btn" data-product-id="${product.product_id}">
                            Quick View
                        </button>
                    </div>
                </div>
                
                <div class="product-content">
                    <div class="product-brand">${this.escapeHtml(product.brand || '')}</div>
                    <h3 class="product-name">
                        <a href="/products/view.php?id=${product.product_id}">
                            ${this.escapeHtml(product.name)}
                        </a>
                    </h3>
                    
                    <div class="product-specs">
                        ${specs.storage ? `<span class="spec-item">${this.escapeHtml(specs.storage)}</span>` : ''}
                        ${specs.storage && specs.color ? '<span class="spec-separator">•</span>' : ''}
                        ${specs.color ? `<span class="spec-item">${this.escapeHtml(specs.color)}</span>` : ''}
                    </div>
                    
                    <div class="product-price">
                        <span class="current-price">$${this.formatPrice(product.price)}</span>
                        ${hasDiscount ? 
                            `<span class="original-price">$${this.formatPrice(product.original_price)}</span>
                             <span class="discount-badge">${discountPercent}% OFF</span>` : ''
                        }
                    </div>
                    
                    <div class="product-actions">
                        <button class="add-to-cart-btn" data-product-id="${product.product_id}">
                            <span class="btn-icon">🛒</span>
                            <span class="btn-text">Add to Cart</span>
                            <div class="btn-loading hidden">
                                <div class="loading-spinner-small"></div>
                            </div>
                        </button>
                        <button class="wishlist-btn" data-product-id="${product.product_id}">
                            <span class="heart-icon">♡</span>
                        </button>
                    </div>
                </div>
            </article>
        `;
    }
    
    updatePagination(data) {
        const paginationNav = document.getElementById('pagination-nav');
        if (!paginationNav || data.total_pages <= 1) {
            if (paginationNav) paginationNav.style.display = 'none';
            return;
        }
        
        paginationNav.style.display = 'flex';
        
        let paginationHtml = '<div class="pagination">';
        
        // Previous button
        if (data.current_page > 1) {
            paginationHtml += `
                <a href="#" class="pagination-btn prev-btn" data-page="${data.current_page - 1}">
                    <span class="btn-icon">←</span>
                    <span class="btn-text">Previous</span>
                </a>
            `;
        }
        
        // Page numbers
        paginationHtml += '<div class="pagination-numbers">';
        
        const startPage = Math.max(1, data.current_page - 2);
        const endPage = Math.min(data.total_pages, data.current_page + 2);
        
        if (startPage > 1) {
            paginationHtml += `<a href="#" class="pagination-number" data-page="1">1</a>`;
            if (startPage > 2) {
                paginationHtml += '<span class="pagination-ellipsis">...</span>';
            }
        }
        
        for (let i = startPage; i <= endPage; i++) {
            const activeClass = i === data.current_page ? 'active' : '';
            paginationHtml += `<a href="#" class="pagination-number ${activeClass}" data-page="${i}">${i}</a>`;
        }
        
        if (endPage < data.total_pages) {
            if (endPage < data.total_pages - 1) {
                paginationHtml += '<span class="pagination-ellipsis">...</span>';
            }
            paginationHtml += `<a href="#" class="pagination-number" data-page="${data.total_pages}">${data.total_pages}</a>`;
        }
        
        paginationHtml += '</div>';
        
        // Next button
        if (data.current_page < data.total_pages) {
            paginationHtml += `
                <a href="#" class="pagination-btn next-btn" data-page="${data.current_page + 1}">
                    <span class="btn-text">Next</span>
                    <span class="btn-icon">→</span>
                </a>
            `;
        }
        
        paginationHtml += '</div>';
        paginationNav.innerHTML = paginationHtml;
    }
    
    updateResultsInfo(data) {
        const resultsInfo = document.getElementById('results-count');
        const totalProducts = document.getElementById('total-products');
        
        if (resultsInfo) {
            resultsInfo.textContent = `Showing ${data.products.length} of ${data.total} products`;
        }
        
        if (totalProducts) {
            totalProducts.textContent = data.total;
        }
    }
    
    async addToCart(productId, button) {
        if (!productId || button.classList.contains('loading')) return;
        
        button.classList.add('loading');
        
        try {
            // Simulate API call
            await this.delay(800);
            
            // Add success animation
            button.style.background = 'linear-gradient(135deg, #10b981 0%, #059669 100%)';
            button.querySelector('.btn-text').textContent = 'Added!';
            
            this.showNotification('Product added to cart successfully!');
            
            // Reset button after delay
            setTimeout(() => {
                button.style.background = '';
                button.querySelector('.btn-text').textContent = 'Add to Cart';
                button.classList.remove('loading');
            }, 2000);
            
        } catch (error) {
            console.error('Error adding to cart:', error);
            this.showError('Failed to add product to cart. Please try again.');
            button.classList.remove('loading');
        }
    }
    
    toggleWishlist(productId, button) {
        if (!productId) return;
        
        const isActive = button.classList.contains('active');
        const heartIcon = button.querySelector('.heart-icon');
        
        if (isActive) {
            button.classList.remove('active');
            heartIcon.textContent = '♡';
            this.showNotification('Product removed from wishlist.');
        } else {
            button.classList.add('active');
            heartIcon.textContent = '♥';
            this.showNotification('Product added to wishlist!');
        }
        
        // Add bounce animation
        heartIcon.style.transform = 'scale(1.3)';
        setTimeout(() => {
            heartIcon.style.transform = '';
        }, 200);
    }
    
    switchView(viewType) {
        const viewBtns = document.querySelectorAll('.view-btn');
        const grid = document.getElementById('products-grid');
        
        if (!grid) return;
        
        // Update active button
        viewBtns.forEach(btn => {
            btn.classList.toggle('active', btn.getAttribute('data-view') === viewType);
        });
        
        // Update grid class
        if (viewType === 'list') {
            grid.classList.add('list-view');
        } else {
            grid.classList.remove('list-view');
        }
    }
    
    openQuickView(productId) {
        if (!productId) return;
        
        // For now, just redirect to product page
        // In a real app, you'd open a modal with product details
        window.location.href = `/products/view.php?id=${productId}`;
    }
    
    showLoading() {
        const overlay = document.getElementById('loading-overlay');
        if (overlay) {
            overlay.classList.remove('hidden');
        }
    }
    
    hideLoading() {
        const overlay = document.getElementById('loading-overlay');
        if (overlay) {
            overlay.classList.add('hidden');
        }
    }
    
    showNotification(message, type = 'success') {
        const toast = document.getElementById('notification-toast');
        const messageEl = toast?.querySelector('.toast-message');
        const iconEl = toast?.querySelector('.toast-icon');
        
        if (!toast || !messageEl || !iconEl) return;
        
        messageEl.textContent = message;
        
        // Update icon based on type
        if (type === 'success') {
            iconEl.textContent = '✓';
            iconEl.style.background = 'linear-gradient(135deg, #10b981 0%, #059669 100%)';
        } else if (type === 'error') {
            iconEl.textContent = '✗';
            iconEl.style.background = 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)';
        }
        
        toast.classList.remove('hidden');
        
        setTimeout(() => {
            toast.classList.add('hidden');
        }, 4000);
    }
    
    showError(message) {
        this.showNotification(message, 'error');
    }
    
    animateCardsIn() {
        const cards = document.querySelectorAll('.product-card');
        cards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                card.style.transition = 'all 0.5s ease-out';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 100);
        });
    }
    
    initializeViewToggle() {
        // Set default view
        const defaultView = localStorage.getItem('catalog-view') || 'grid';
        this.switchView(defaultView);
        
        // Save view preference
        document.addEventListener('click', (e) => {
            if (e.target.matches('.view-btn')) {
                const viewType = e.target.getAttribute('data-view');
                localStorage.setItem('catalog-view', viewType);
            }
        });
    }
    
    initializeAnimations() {
        // Intersection Observer for scroll animations
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, { threshold: 0.1 });
        
        // Observe elements that should animate
        document.querySelectorAll('.product-card, .filters-section, .products-header').forEach(el => {
            observer.observe(el);
        });
    }
    
    // Utility methods
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    formatPrice(price) {
        return parseFloat(price).toFixed(2);
    }
    
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Initialize the catalog when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const catalog = new CellphoneCatalog();
});

// Add CSS for list view and animations
const additionalStyles = `
    .products-grid.list-view {
        display: flex;
        flex-direction: column;
        gap: var(--space-4);
    }
    
    .products-grid.list-view .product-card {
        display: flex;
        flex-direction: row;
        max-width: 100%;
    }
    
    .products-grid.list-view .product-image-container {
        flex: 0 0 200px;
        aspect-ratio: 1;
    }
    
    .products-grid.list-view .product-content {
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }
    
    .products-grid.list-view .product-actions {
        margin-top: auto;
    }
    
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .animate-in {
        animation: fadeInUp 0.6s ease-out forwards;
    }
    
    @media (max-width: 768px) {
        .products-grid.list-view .product-card {
            flex-direction: column;
        }
        
        .products-grid.list-view .product-image-container {
            flex: none;
            aspect-ratio: 4/3;
        }
    }
`;

// Inject additional styles
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);