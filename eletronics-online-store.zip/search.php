<?php
require_once 'includes/header.php';

$searchTerm = $_GET['q'] ?? '';
?>
<h1>Search Results for "<?= htmlspecialchars($searchTerm) ?>"</h1>
<div class="search-results">
    <?php include 'includes/product_functions.php';
    $results = searchProducts($searchTerm);
    foreach ($results as $product): ?>
        <div class="product">
            <h3><?= htmlspecialchars($product['name']) ?></h3>
            <p>Price: $<?= number_format($product['price'], 2) ?></p>
        </div>
    <?php endforeach; ?>
</div>
<?php
require_once 'includes/footer.php';
?>