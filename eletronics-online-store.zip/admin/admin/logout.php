<?php
require_once '../includes/auth.php';
logout();
?>