<?php
require_once '../includes/auth.php';
require_once '../config/database.php';
require_once '../classes/Product.php';
require_once '../classes/Category.php';
require_once '../includes/functions.php';

requireLogin();

$database = new Database();
$db = $database->getConnection();

$product = new Product($db);
$category = new Category($db);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'create':
                $data = array(
                    'category_id' => sanitizeInput($_POST['category_id']),
                    'name' => sanitizeInput($_POST['name']),
                    'description' => sanitizeInput($_POST['description']),
                    'short_description' => sanitizeInput($_POST['short_description']),
                    'price' => floatval($_POST['price']),
                    'discount_price' => !empty($_POST['discount_price']) ? floatval($_POST['discount_price']) : null,
                    'stock_quantity' => intval($_POST['stock_quantity']),
                    'min_stock_level' => intval($_POST['min_stock_level']),
                    'sku' => sanitizeInput($_POST['sku']),
                    'brand' => sanitizeInput($_POST['brand']),
                    'model' => sanitizeInput($_POST['model']),
                    'weight' => !empty($_POST['weight']) ? floatval($_POST['weight']) : null,
                    'dimensions' => sanitizeInput($_POST['dimensions']),
                    'warranty_period' => !empty($_POST['warranty_period']) ? intval($_POST['warranty_period']) : null,
                    'status' => sanitizeInput($_POST['status']),
                    'featured' => isset($_POST['featured']) ? 1 : 0,
                    'meta_title' => sanitizeInput($_POST['meta_title']),
                    'meta_description' => sanitizeInput($_POST['meta_description'])
                );
                
                // Handle image uploads
                $uploaded_images = [];
                if (!empty($_FILES['images']['name'][0])) {
                    $upload_dir = '../uploads/products/';
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    
                    foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
                        $file_name = $_FILES['images']['name'][$key];
                        $file_tmp = $_FILES['images']['tmp_name'][$key];
                        $file_size = $_FILES['images']['size'][$key];
                        $file_error = $_FILES['images']['error'][$key];
                        
                        // Validate file
                        if ($file_error === UPLOAD_ERR_OK) {
                            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                            $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                            
                            if (in_array($file_ext, $allowed_ext)) {
                                if ($file_size < 5000000) { // 5MB max
                                    $new_file_name = uniqid('', true) . '.' . $file_ext;
                                    $destination = $upload_dir . $new_file_name;
                                    
                                    if (move_uploaded_file($file_tmp, $destination)) {
                                        $uploaded_images[] = $new_file_name;
                                    }
                                }
                            }
                        }
                    }
                    
                    if (!empty($uploaded_images)) {
                        $data['images'] = json_encode($uploaded_images);
                    }
                }
                
                if ($product->create($data)) {
                    $success_message = "Product created successfully!";
                } else {
                    $error_message = "Failed to create product.";
                }
                break;
                
            case 'update':
                $product_id = intval($_POST['product_id']);
                $data = array(
                    'category_id' => sanitizeInput($_POST['category_id']),
                    'name' => sanitizeInput($_POST['name']),
                    'description' => sanitizeInput($_POST['description']),
                    'short_description' => sanitizeInput($_POST['short_description']),
                    'price' => floatval($_POST['price']),
                    'discount_price' => !empty($_POST['discount_price']) ? floatval($_POST['discount_price']) : null,
                    'stock_quantity' => intval($_POST['stock_quantity']),
                    'min_stock_level' => intval($_POST['min_stock_level']),
                    'sku' => sanitizeInput($_POST['sku']),
                    'brand' => sanitizeInput($_POST['brand']),
                    'model' => sanitizeInput($_POST['model']),
                    'weight' => !empty($_POST['weight']) ? floatval($_POST['weight']) : null,
                    'dimensions' => sanitizeInput($_POST['dimensions']),
                    'warranty_period' => !empty($_POST['warranty_period']) ? intval($_POST['warranty_period']) : null,
                    'status' => sanitizeInput($_POST['status']),
                    'featured' => isset($_POST['featured']) ? 1 : 0,
                    'meta_title' => sanitizeInput($_POST['meta_title']),
                    'meta_description' => sanitizeInput($_POST['meta_description'])
                );
                
                // Handle image uploads for update
                $uploaded_images = [];
                if (!empty($_FILES['images']['name'][0])) {
                    $upload_dir = '../uploads/products/';
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    
                    foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
                        $file_name = $_FILES['images']['name'][$key];
                        $file_tmp = $_FILES['images']['tmp_name'][$key];
                        $file_size = $_FILES['images']['size'][$key];
                        $file_error = $_FILES['images']['error'][$key];
                        
                        if ($file_error === UPLOAD_ERR_OK) {
                            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                            $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                            
                            if (in_array($file_ext, $allowed_ext)) {
                                if ($file_size < 5000000) {
                                    $new_file_name = uniqid('', true) . '.' . $file_ext;
                                    $destination = $upload_dir . $new_file_name;
                                    
                                    if (move_uploaded_file($file_tmp, $destination)) {
                                        $uploaded_images[] = $new_file_name;
                                    }
                                }
                            }
                        }
                    }
                    
                    // Get existing images
                    $existing_product = $product->getById($product_id);
                    $existing_images = [];
                    if ($existing_product && !empty($existing_product['images'])) {
                        $existing_images = json_decode($existing_product['images'], true);
                    }
                    
                    // Merge existing and new images
                    if (!empty($uploaded_images)) {
                        $all_images = array_merge($existing_images, $uploaded_images);
                        $data['images'] = json_encode($all_images);
                    }
                }
                
                if ($product->update($product_id, $data)) {
                    $success_message = "Product updated successfully!";
                } else {
                    $error_message = "Failed to update product.";
                }
                break;
                
            case 'delete':
                $product_id = intval($_POST['product_id']);
                if ($product->delete($product_id)) {
                    $success_message = "Product deleted successfully!";
                } else {
                    $error_message = "Failed to delete product.";
                }
                break;
                
            case 'delete_image':
                $product_id = intval($_POST['product_id']);
                $image_name = sanitizeInput($_POST['image_name']);
                
                $product_data = $product->getById($product_id);
                if ($product_data && !empty($product_data['images'])) {
                    $images = json_decode($product_data['images'], true);
                    $image_index = array_search($image_name, $images);
                    
                    if ($image_index !== false) {
                        // Delete the file
                        $file_path = '../uploads/products/' . $image_name;
                        if (file_exists($file_path)) {
                            unlink($file_path);
                        }
                        
                        // Remove from array
                        unset($images[$image_index]);
                        $images = array_values($images); // Re-index array
                        
                        // Update database
                        $product->update($product_id, ['images' => json_encode($images)]);
                    }
                }
                
                header('Content-Type: application/json');
                echo json_encode(['success' => true]);
                exit;
                break;
        }
    }
}

// Get filter parameters
$search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
$category_filter = isset($_GET['category']) ? sanitizeInput($_GET['category']) : '';
$status_filter = isset($_GET['status']) ? sanitizeInput($_GET['status']) : '';
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Get products
$products = $product->getAll($per_page, $offset, $search, $category_filter, $status_filter);
$total_products = $product->getTotalCount($search, $category_filter, $status_filter);
$total_pages = ceil($total_products / $per_page);

// Get categories for filter and form
$categories = $category->getAll();

$admin = getLoggedInAdmin();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Electronics Store Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
    <style>
        .img-thumbnail {
            object-fit: cover;
        }
        .current-image-container {
            position: relative;
            display: inline-block;
            margin-right: 10px;
            margin-bottom: 10px;
        }
        .delete-image-btn {
            position: absolute;
            top: 5px;
            right: 5px;
            width: 25px;
            height: 25px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0;
        }
        .image-preview-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 10px;
        }
        .image-preview {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Products</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProductModal">
                            <i class="fas fa-plus"></i> Add Product
                        </button>
                    </div>
                </div>

                <?php if (isset($success_message)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $success_message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (isset($error_message)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $error_message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Filters -->
                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-4">
                                <input type="text" class="form-control" name="search" placeholder="Search products..." value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" name="category">
                                    <option value="">All Categories</option>
                                    <?php foreach ($categories as $cat): ?>
                                        <option value="<?php echo $cat['category_id']; ?>" <?php echo ($category_filter == $cat['category_id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($cat['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" name="status">
                                    <option value="">All Status</option>
                                    <option value="active" <?php echo ($status_filter == 'active') ? 'selected' : ''; ?>>Active</option>
                                    <option value="inactive" <?php echo ($status_filter == 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                                    <option value="out_of_stock" <?php echo ($status_filter == 'out_of_stock') ? 'selected' : ''; ?>>Out of Stock</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-outline-primary w-100">
                                    <i class="fas fa-search"></i> Filter
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Products Table -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>SKU</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>Stock</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($products as $prod): 
                                        $images = !empty($prod['images']) ? json_decode($prod['images'], true) : [];
                                    ?>
                                    <tr>
                                        <td>
                                            <?php if (!empty($images)): ?>
                                                <img src="../uploads/products/<?php echo htmlspecialchars($images[0]); ?>" alt="Product" class="img-thumbnail" style="width: 50px; height: 50px;">
                                            <?php else: ?>
                                                <img src="https://via.placeholder.com/50x50" alt="Product" class="img-thumbnail" style="width: 50px; height: 50px;">
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($prod['name']); ?></strong>
                                            <?php if ($prod['featured']): ?>
                                                <span class="badge bg-warning ms-1">Featured</span>
                                            <?php endif; ?>
                                            <br>
                                            <small class="text-muted"><?php echo htmlspecialchars($prod['brand']); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($prod['sku']); ?></td>
                                        <td><?php echo htmlspecialchars($prod['category_name']); ?></td>
                                        <td>
                                            <?php if ($prod['discount_price']): ?>
                                                <span class="text-decoration-line-through text-muted"><?php echo formatCurrency($prod['price']); ?></span><br>
                                                <strong class="text-success"><?php echo formatCurrency($prod['discount_price']); ?></strong>
                                            <?php else: ?>
                                                <strong><?php echo formatCurrency($prod['price']); ?></strong>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge <?php echo ($prod['stock_quantity'] <= $prod['min_stock_level']) ? 'bg-danger' : 'bg-success'; ?>">
                                                <?php echo $prod['stock_quantity']; ?>
                                            </span>
                                        </td>
                                        <td><?php echo getStatusBadge($prod['status'], 'product_status'); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <button type="button" class="btn btn-sm btn-outline-primary" onclick="editProduct(<?php echo $prod['product_id']; ?>)">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button type="button" class="btn btn-sm btn-outline-danger" onclick="deleteProduct(<?php echo $prod['product_id']; ?>)">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                            <nav aria-label="Products pagination">
                                <ul class="pagination justify-content-center">
                                    <?php if ($page > 1): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?php echo ($page - 1); ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($category_filter); ?>&status=<?php echo urlencode($status_filter); ?>">Previous</a>
                                        </li>
                                    <?php endif; ?>
                                    
                                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                                        <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                                            <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($category_filter); ?>&status=<?php echo urlencode($status_filter); ?>"><?php echo $i; ?></a>
                                        </li>
                                    <?php endfor; ?>
                                    
                                    <?php if ($page < $total_pages): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?php echo ($page + 1); ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($category_filter); ?>&status=<?php echo urlencode($status_filter); ?>">Next</a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Add Product Modal -->
    <div class="modal fade" id="addProductModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="create">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="name" class="form-label">Product Name *</label>
                                <input type="text" class="form-control" name="name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="sku" class="form-label">SKU *</label>
                                <input type="text" class="form-control" name="sku" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="category_id" class="form-label">Category *</label>
                                <select class="form-select" name="category_id" required>
                                    <option value="">Select Category</option>
                                    <?php foreach ($categories as $cat): ?>
                                        <option value="<?php echo $cat['category_id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="brand" class="form-label">Brand</label>
                                <input type="text" class="form-control" name="brand">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="price" class="form-label">Price *</label>
                                <input type="number" step="0.01" class="form-control" name="price" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="discount_price" class="form-label">Discount Price</label>
                                <input type="number" step="0.01" class="form-control" name="discount_price">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="stock_quantity" class="form-label">Stock Quantity *</label>
                                <input type="number" class="form-control" name="stock_quantity" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="status" class="form-label">Status</label>
                                <select class="form-select" name="status">
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="min_stock_level" class="form-label">Min Stock Level</label>
                                <input type="number" class="form-control" name="min_stock_level" value="5">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="short_description" class="form-label">Short Description</label>
                            <textarea class="form-control" name="short_description" rows="2"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" name="description" rows="4"></textarea>
                        </div>
                        
                        <!-- Image Upload Section -->
                        <div class="mb-3">
                            <label for="images" class="form-label">Product Images</label>
                            <input type="file" class="form-control" name="images[]" multiple accept="image/*" id="imageUpload">
                            <small class="text-muted">Upload multiple images (JPEG, PNG, GIF, max 5MB each)</small>
                            <div class="image-preview-container mt-2" id="imagePreviewContainer"></div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="model" class="form-label">Model</label>
                                <input type="text" class="form-control" name="model">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="weight" class="form-label">Weight (kg)</label>
                                <input type="number" step="0.01" class="form-control" name="weight">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="dimensions" class="form-label">Dimensions</label>
                                <input type="text" class="form-control" name="dimensions" placeholder="L x W x H">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="warranty_period" class="form-label">Warranty (months)</label>
                                <input type="number" class="form-control" name="warranty_period">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="meta_title" class="form-label">Meta Title</label>
                                <input type="text" class="form-control" name="meta_title">
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="form-check mt-4">
                                    <input class="form-check-input" type="checkbox" name="featured" id="featured">
                                    <label class="form-check-label" for="featured">
                                        Featured Product
                                    </label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="meta_description" class="form-label">Meta Description</label>
                            <textarea class="form-control" name="meta_description" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Product</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Product Modal -->
    <div class="modal fade" id="editProductModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" enctype="multipart/form-data" id="editProductForm">
                    <div class="modal-body" id="editProductContent">
                        <!-- Content will be loaded via AJAX -->
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Product</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/admin.js"></script>
    <script>
        // Image preview for add product form
        document.getElementById('imageUpload').addEventListener('change', function(e) {
            const previewContainer = document.getElementById('imagePreviewContainer');
            previewContainer.innerHTML = '';
            
            const files = e.target.files;
            for (let i = 0; i < files.length; i++) {
                const file = files[i];
                if (file.type.match('image.*')) {
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.classList.add('image-preview');
                        previewContainer.appendChild(img);
                    }
                    
                    reader.readAsDataURL(file);
                }
            }
        });

        function editProduct(productId) {
            // Load product data via AJAX and populate edit modal
            fetch('ajax/get_product.php?id=' + productId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('editProductContent').innerHTML = data.html;
                        
                        // Initialize image preview for edit form
                        const editImageUpload = document.querySelector('#editProductContent input[name="images[]"]');
                        if (editImageUpload) {
                            editImageUpload.addEventListener('change', function(e) {
                                const previewContainer = document.querySelector('#editProductContent .image-preview-container');
                                if (!previewContainer) return;
                                
                                const files = e.target.files;
                                for (let i = 0; i < files.length; i++) {
                                    const file = files[i];
                                    if (file.type.match('image.*')) {
                                        const reader = new FileReader();
                                        
                                        reader.onload = function(e) {
                                            const img = document.createElement('img');
                                            img.src = e.target.result;
                                            img.classList.add('image-preview');
                                            previewContainer.appendChild(img);
                                        }
                                        
                                        reader.readAsDataURL(file);
                                    }
                                }
                            });
                        }
                        
                        new bootstrap.Modal(document.getElementById('editProductModal')).show();
                    }
                });
        }

        function deleteProduct(productId) {
            if (confirm('Are you sure you want to delete this product?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="product_id" value="${productId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function deleteImage(productId, imageName) {
            if (confirm('Are you sure you want to delete this image?')) {
                fetch('products.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=delete_image&product_id=' + productId + '&image_name=' + encodeURIComponent(imageName)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Remove the image from the UI
                        document.querySelector(`button[onclick="deleteImage(${productId}, '${imageName}')"]`).parentElement.remove();
                    }
                });
            }
        }
    </script>
</body>
</html>