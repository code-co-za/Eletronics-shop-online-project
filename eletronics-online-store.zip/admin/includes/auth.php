<?php
session_start();

function isLoggedIn() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit();
    }
}

function getLoggedInAdmin() {
    if (isLoggedIn()) {
        return array(
            'admin_id'  => $_SESSION['admin_id'],
            'username'  => $_SESSION['username']  ?? null,
            'email'     => $_SESSION['email']     ?? null,
            'full_name' => $_SESSION['full_name'] ?? null,
            'role'      => $_SESSION['role']      ?? null
        );
    }
    return null;
}

function logout() {
    session_destroy();
    header('Location: login.php');
    exit();
}

function hasPermission($required_role) {
    if (!isLoggedIn()) {
        return false;
    }

    $role_hierarchy = array(
        'super_admin'       => 5,
        'product_manager'   => 4,
        'sales_manager'     => 3,
        'inventory_manager' => 2,
        'customer_support'  => 1
    );

    $user_level     = $role_hierarchy[$_SESSION['role']]     ?? 0;
    $required_level = $role_hierarchy[$required_role]        ?? 0;

    return $user_level >= $required_level;
}
?>
