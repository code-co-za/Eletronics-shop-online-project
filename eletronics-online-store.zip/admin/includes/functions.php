<?php
function formatCurrency($amount) {
    return '$' . number_format($amount, 2);
}

function formatDate($date) {
    return date('M j, Y', strtotime($date));
}

function formatDateTime($datetime) {
    return date('M j, Y g:i A', strtotime($datetime));
}

function getStatusBadge($status, $type = 'default') {
    $badges = array(
        'order_status' => array(
            'pending' => 'badge-warning',
            'confirmed' => 'badge-info',
            'processing' => 'badge-primary',
            'shipped' => 'badge-secondary',
            'delivered' => 'badge-success',
            'cancelled' => 'badge-danger',
            'returned' => 'badge-dark'
        ),
        'payment_status' => array(
            'pending' => 'badge-warning',
            'completed' => 'badge-success',
            'failed' => 'badge-danger',
            'refunded' => 'badge-secondary'
        ),
        'user_status' => array(
            'active' => 'badge-success',
            'inactive' => 'badge-secondary',
            'suspended' => 'badge-danger'
        ),
        'product_status' => array(
            'active' => 'badge-success',
            'inactive' => 'badge-secondary',
            'out_of_stock' => 'badge-danger'
        )
    );
    
    $badge_class = $badges[$type][$status] ?? 'badge-secondary';
    return '<span class="badge ' . $badge_class . '">' . ucfirst(str_replace('_', ' ', $status)) . '</span>';
}

function getPagination($current_page, $total_pages, $base_url) {
    $pagination = '';
    
    if ($total_pages > 1) {
        $pagination .= '<nav aria-label="Page navigation">';
        $pagination .= '<ul class="pagination justify-content-center">';
        
        // Previous button
        if ($current_page > 1) {
            $pagination .= '<li class="page-item"><a class="page-link" href="' . $base_url . '&page=' . ($current_page - 1) . '">Previous</a></li>';
        }
        
        // Page numbers
        for ($i = max(1, $current_page - 2); $i <= min($total_pages, $current_page + 2); $i++) {
            $active = ($i == $current_page) ? 'active' : '';
            $pagination .= '<li class="page-item ' . $active . '"><a class="page-link" href="' . $base_url . '&page=' . $i . '">' . $i . '</a></li>';
        }
        
        // Next button
        if ($current_page < $total_pages) {
            $pagination .= '<li class="page-item"><a class="page-link" href="' . $base_url . '&page=' . ($current_page + 1) . '">Next</a></li>';
        }
        
        $pagination .= '</ul>';
        $pagination .= '</nav>';
    }
    
    return $pagination;
}

function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function generateRandomString($length = 10) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}

function uploadImage($file, $upload_dir = 'uploads/') {
    $allowed_types = array('jpg', 'jpeg', 'png', 'gif');
    $max_size = 5 * 1024 * 1024; // 5MB
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return array('success' => false, 'message' => 'Upload error');
    }
    
    if ($file['size'] > $max_size) {
        return array('success' => false, 'message' => 'File too large');
    }
    
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($file_extension, $allowed_types)) {
        return array('success' => false, 'message' => 'Invalid file type');
    }
    
    $new_filename = uniqid() . '.' . $file_extension;
    $upload_path = $upload_dir . $new_filename;
    
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    if (move_uploaded_file($file['tmp_name'], $upload_path)) {
        return array('success' => true, 'filename' => $new_filename, 'path' => $upload_path);
    } else {
        return array('success' => false, 'message' => 'Failed to move uploaded file');
    }
}
?>