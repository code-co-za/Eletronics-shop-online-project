<?php
require_once '../config/database.php';

class Admin {
    private $conn;
    private $table_name = "admins";

    public $admin_id;
    public $username;
    public $email;
    public $password_hash;
    public $full_name;
    public $role;
    public $status;
    public $last_login;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Login function
    public function login($username, $password) {
        $query = "SELECT admin_id, username, email, password_hash, full_name, role, status 
                  FROM " . $this->table_name . " 
                  WHERE (username = :username OR email = :username) AND status = 'active'";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (password_verify($password, $row['password_hash'])) {
                // Update last login
                $this->updateLastLogin($row['admin_id']);

                // Remove password_hash before storing in session
                unset($row['password_hash']);

                return array(
                    'success' => true,
                    'admin' => array(
                        'admin_id' => $row['admin_id'],
                        'username' => $row['username'],
                        'email' => $row['email'],
                        'full_name' => $row['full_name'],
                        'role' => $row['role']
                    )
                );
            }
        }

        return array('success' => false, 'message' => 'Invalid credentials');
    }

    // Update last login
    private function updateLastLogin($admin_id) {
        $query = "UPDATE " . $this->table_name . " SET last_login = NOW() WHERE admin_id = :admin_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':admin_id', $admin_id);
        $stmt->execute();
    }

    // Get admin by ID
    public function getById($admin_id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE admin_id = :admin_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':admin_id', $admin_id);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Create new admin
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                  (username, email, password_hash, full_name, role, status, created_by) 
                  VALUES (:username, :email, :password_hash, :full_name, :role, :status, :created_by)";
        
        $stmt = $this->conn->prepare($query);
        
        // Hash password
        $hashed_password = password_hash($this->password_hash, PASSWORD_DEFAULT);
        
        $stmt->bindParam(':username', $this->username);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':password_hash', $hashed_password);
        $stmt->bindParam(':full_name', $this->full_name);
        $stmt->bindParam(':role', $this->role);
        $stmt->bindParam(':status', $this->status);
        $stmt->bindParam(':created_by', $_SESSION['admin_id']);
        
        return $stmt->execute();
    }

    // Get all admins
    public function getAll() {
        $query = "SELECT admin_id, username, email, full_name, role, status, last_login, created_at 
                  FROM " . $this->table_name . " ORDER BY created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
