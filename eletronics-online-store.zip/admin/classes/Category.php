<?php
require_once '../config/database.php';

class Category {
    private $conn;
    private $table_name = "categories";

    public function __construct($db) {
        $this->conn = $db;
    }

    // Get all categories
    public function getAll($search = '', $status = '') {
        $query = "SELECT * FROM " . $this->table_name . " WHERE 1=1";
        
        $params = array();
        
        if (!empty($search)) {
            $query .= " AND (name LIKE :search OR slug LIKE :search)";
            $params[':search'] = '%' . $search . '%';
        }
        
        if (!empty($status)) {
            $query .= " AND status = :status";
            $params[':status'] = $status;
        }
        
        $query .= " ORDER BY sort_order ASC, name ASC";
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get category by ID
    public function getById($category_id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE category_id = :category_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':category_id', $category_id);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Create category
    public function create($data) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (name, slug, parent_id, description, sort_order, status) 
                  VALUES (:name, :slug, :parent_id, :description, :sort_order, :status)";
        
        $stmt = $this->conn->prepare($query);
        
        // Generate slug from name if not provided
        $slug = !empty($data['slug']) ? $data['slug'] : $this->generateSlug($data['name']);
        
        $stmt->bindParam(':name', $data['name']);
        $stmt->bindParam(':slug', $slug);
        $stmt->bindParam(':parent_id', $data['parent_id']);
        $stmt->bindParam(':description', $data['description']);
        $stmt->bindParam(':sort_order', $data['sort_order']);
        $stmt->bindParam(':status', $data['status']);
        
        return $stmt->execute();
    }

    // Update category
    public function update($category_id, $data) {
        $query = "UPDATE " . $this->table_name . " SET 
                  name = :name, slug = :slug, parent_id = :parent_id, description = :description, 
                  sort_order = :sort_order, status = :status, updated_at = NOW() 
                  WHERE category_id = :category_id";
        
        $stmt = $this->conn->prepare($query);
        
        // Generate slug from name if not provided
        $slug = !empty($data['slug']) ? $data['slug'] : $this->generateSlug($data['name']);
        
        $stmt->bindParam(':category_id', $category_id);
        $stmt->bindParam(':name', $data['name']);
        $stmt->bindParam(':slug', $slug);
        $stmt->bindParam(':parent_id', $data['parent_id']);
        $stmt->bindParam(':description', $data['description']);
        $stmt->bindParam(':sort_order', $data['sort_order']);
        $stmt->bindParam(':status', $data['status']);
        
        return $stmt->execute();
    }

    // Delete category
    public function delete($category_id) {
        // Check if category has products
        $check_query = "SELECT COUNT(*) as count FROM products WHERE category_id = :category_id";
        $check_stmt = $this->conn->prepare($check_query);
        $check_stmt->bindParam(':category_id', $category_id);
        $check_stmt->execute();
        $result = $check_stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result['count'] > 0) {
            return array('success' => false, 'message' => 'Cannot delete category with existing products');
        }
        
        $query = "DELETE FROM " . $this->table_name . " WHERE category_id = :category_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':category_id', $category_id);
        
        if ($stmt->execute()) {
            return array('success' => true, 'message' => 'Category deleted successfully');
        } else {
            return array('success' => false, 'message' => 'Failed to delete category');
        }
    }

    // Generate slug from name
    private function generateSlug($name) {
        $slug = strtolower(trim($name));
        $slug = preg_replace('/[^a-z0-9-]/', '-', $slug);
        $slug = preg_replace('/-+/', '-', $slug);
        return trim($slug, '-');
    }

    // Get categories with product count
    public function getWithProductCount() {
        $query = "SELECT c.*, COUNT(p.product_id) as product_count 
                  FROM " . $this->table_name . " c 
                  LEFT JOIN products p ON c.category_id = p.category_id 
                  GROUP BY c.category_id 
                  ORDER BY c.sort_order ASC, c.name ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>