<?php
require_once '../config/database.php';

class Product {
    private $conn;
    private $table_name = "products";

    public function __construct($db) {
        $this->conn = $db;
    }

    // Get all products with category info
    public function getAll($limit = null, $offset = null, $search = '', $category_id = '', $status = '') {
        $query = "SELECT p.*, c.name as category_name 
                  FROM " . $this->table_name . " p 
                  LEFT JOIN categories c ON p.category_id = c.category_id 
                  WHERE 1=1";
        
        $params = array();
        
        if (!empty($search)) {
            $query .= " AND (p.name LIKE :search OR p.sku LIKE :search OR p.brand LIKE :search)";
            $params[':search'] = '%' . $search . '%';
        }
        
        if (!empty($category_id)) {
            $query .= " AND p.category_id = :category_id";
            $params[':category_id'] = $category_id;
        }
        
        if (!empty($status)) {
            $query .= " AND p.status = :status";
            $params[':status'] = $status;
        }
        
        $query .= " ORDER BY p.created_at DESC";
        
        if ($limit) {
            $query .= " LIMIT :limit";
            if ($offset) {
                $query .= " OFFSET :offset";
            }
        }
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        if ($limit) {
            $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
            if ($offset) {
                $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
            }
        }
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get product by ID
    public function getById($product_id) {
        $query = "SELECT p.*, c.name as category_name 
                  FROM " . $this->table_name . " p 
                  LEFT JOIN categories c ON p.category_id = c.category_id 
                  WHERE p.product_id = :product_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':product_id', $product_id);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Create product
    public function create($data) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (category_id, name, slug, description, short_description, price, discount_price, 
                   stock_quantity, min_stock_level, sku, brand, model, weight, dimensions, 
                   warranty_period, status, featured, meta_title, meta_description) 
                  VALUES (:category_id, :name, :slug, :description, :short_description, :price, 
                          :discount_price, :stock_quantity, :min_stock_level, :sku, :brand, :model, 
                          :weight, :dimensions, :warranty_period, :status, :featured, :meta_title, :meta_description)";
        
        $stmt = $this->conn->prepare($query);
        
        // Generate slug from name
        $slug = $this->generateSlug($data['name']);
        
        $stmt->bindParam(':category_id', $data['category_id']);
        $stmt->bindParam(':name', $data['name']);
        $stmt->bindParam(':slug', $slug);
        $stmt->bindParam(':description', $data['description']);
        $stmt->bindParam(':short_description', $data['short_description']);
        $stmt->bindParam(':price', $data['price']);
        $stmt->bindParam(':discount_price', $data['discount_price']);
        $stmt->bindParam(':stock_quantity', $data['stock_quantity']);
        $stmt->bindParam(':min_stock_level', $data['min_stock_level']);
        $stmt->bindParam(':sku', $data['sku']);
        $stmt->bindParam(':brand', $data['brand']);
        $stmt->bindParam(':model', $data['model']);
        $stmt->bindParam(':weight', $data['weight']);
        $stmt->bindParam(':dimensions', $data['dimensions']);
        $stmt->bindParam(':warranty_period', $data['warranty_period']);
        $stmt->bindParam(':status', $data['status']);
        $stmt->bindParam(':featured', $data['featured']);
        $stmt->bindParam(':meta_title', $data['meta_title']);
        $stmt->bindParam(':meta_description', $data['meta_description']);
        
        return $stmt->execute();
    }

    // Update product
    public function update($product_id, $data) {
        $query = "UPDATE " . $this->table_name . " SET 
                  category_id = :category_id, name = :name, slug = :slug, description = :description, 
                  short_description = :short_description, price = :price, discount_price = :discount_price, 
                  stock_quantity = :stock_quantity, min_stock_level = :min_stock_level, sku = :sku, 
                  brand = :brand, model = :model, weight = :weight, dimensions = :dimensions, 
                  warranty_period = :warranty_period, status = :status, featured = :featured, 
                  meta_title = :meta_title, meta_description = :meta_description, updated_at = NOW() 
                  WHERE product_id = :product_id";
        
        $stmt = $this->conn->prepare($query);
        
        // Generate slug from name
        $slug = $this->generateSlug($data['name']);
        
        $stmt->bindParam(':product_id', $product_id);
        $stmt->bindParam(':category_id', $data['category_id']);
        $stmt->bindParam(':name', $data['name']);
        $stmt->bindParam(':slug', $slug);
        $stmt->bindParam(':description', $data['description']);
        $stmt->bindParam(':short_description', $data['short_description']);
        $stmt->bindParam(':price', $data['price']);
        $stmt->bindParam(':discount_price', $data['discount_price']);
        $stmt->bindParam(':stock_quantity', $data['stock_quantity']);
        $stmt->bindParam(':min_stock_level', $data['min_stock_level']);
        $stmt->bindParam(':sku', $data['sku']);
        $stmt->bindParam(':brand', $data['brand']);
        $stmt->bindParam(':model', $data['model']);
        $stmt->bindParam(':weight', $data['weight']);
        $stmt->bindParam(':dimensions', $data['dimensions']);
        $stmt->bindParam(':warranty_period', $data['warranty_period']);
        $stmt->bindParam(':status', $data['status']);
        $stmt->bindParam(':featured', $data['featured']);
        $stmt->bindParam(':meta_title', $data['meta_title']);
        $stmt->bindParam(':meta_description', $data['meta_description']);
        
        return $stmt->execute();
    }

    // Delete product
    public function delete($product_id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE product_id = :product_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':product_id', $product_id);
        
        return $stmt->execute();
    }

    // Get low stock products
    public function getLowStock() {
        $query = "SELECT * FROM low_stock_view ORDER BY stock_quantity ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get featured products
    public function getFeatured() {
        $query = "SELECT * FROM featured_products_view LIMIT 10";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Update stock using stored procedure
    public function updateStock($product_id, $quantity_change, $change_type, $reason, $changed_by) {
        $query = "CALL UpdateProductStock(:product_id, :quantity_change, :change_type, :reason, :changed_by)";
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':product_id', $product_id);
        $stmt->bindParam(':quantity_change', $quantity_change);
        $stmt->bindParam(':change_type', $change_type);
        $stmt->bindParam(':reason', $reason);
        $stmt->bindParam(':changed_by', $changed_by);
        
        return $stmt->execute();
    }

    // Generate slug from name
    private function generateSlug($name) {
        $slug = strtolower(trim($name));
        $slug = preg_replace('/[^a-z0-9-]/', '-', $slug);
        $slug = preg_replace('/-+/', '-', $slug);
        return trim($slug, '-');
    }

    // Get total count for pagination
    public function getTotalCount($search = '', $category_id = '', $status = '') {
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name . " WHERE 1=1";
        
        $params = array();
        
        if (!empty($search)) {
            $query .= " AND (name LIKE :search OR sku LIKE :search OR brand LIKE :search)";
            $params[':search'] = '%' . $search . '%';
        }
        
        if (!empty($category_id)) {
            $query .= " AND category_id = :category_id";
            $params[':category_id'] = $category_id;
        }
        
        if (!empty($status)) {
            $query .= " AND status = :status";
            $params[':status'] = $status;
        }
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $row['total'];
    }
}
?>