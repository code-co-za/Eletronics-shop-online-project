<?php
require_once '../config/database.php';

class Order {
    private $conn;
    private $table_name = "orders";

    public function __construct($db) {
        $this->conn = $db;
    }

    // Get all orders with customer info
    public function getAll($limit = null, $offset = null, $search = '', $status = '', $payment_status = '') {
        $query = "SELECT o.*, u.first_name, u.last_name, u.email as customer_email,
                         COUNT(oi.item_id) as total_items,
                         SUM(oi.quantity) as total_quantity
                  FROM " . $this->table_name . " o 
                  LEFT JOIN users u ON o.user_id = u.user_id 
                  LEFT JOIN order_items oi ON o.order_id = oi.order_id 
                  WHERE 1=1";
        
        $params = array();
        
        if (!empty($search)) {
            $query .= " AND (o.order_number LIKE :search OR u.first_name LIKE :search OR u.last_name LIKE :search OR u.email LIKE :search)";
            $params[':search'] = '%' . $search . '%';
        }
        
        if (!empty($status)) {
            $query .= " AND o.status = :status";
            $params[':status'] = $status;
        }
        
        if (!empty($payment_status)) {
            $query .= " AND o.payment_status = :payment_status";
            $params[':payment_status'] = $payment_status;
        }
        
        $query .= " GROUP BY o.order_id ORDER BY o.order_date DESC";
        
        if ($limit) {
            $query .= " LIMIT :limit";
            if ($offset) {
                $query .= " OFFSET :offset";
            }
        }
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        if ($limit) {
            $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
            if ($offset) {
                $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
            }
        }
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get order by ID with full details
    public function getById($order_id) {
        $query = "SELECT o.*, u.first_name, u.last_name, u.email as customer_email, u.phone,
                         sa.address_line1, sa.address_line2, sa.city, sa.state, sa.zip_code, sa.country
                  FROM " . $this->table_name . " o 
                  LEFT JOIN users u ON o.user_id = u.user_id 
                  LEFT JOIN user_shipping_addresses sa ON o.shipping_address_id = sa.address_id
                  WHERE o.order_id = :order_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':order_id', $order_id);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Get order items
    public function getOrderItems($order_id) {
        $query = "SELECT oi.*, p.name as current_product_name, p.price as current_price 
                  FROM order_items oi 
                  LEFT JOIN products p ON oi.product_id = p.product_id 
                  WHERE oi.order_id = :order_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':order_id', $order_id);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Update order status
    public function updateStatus($order_id, $status, $admin_id = null) {
        $query = "UPDATE " . $this->table_name . " SET status = :status, updated_at = NOW() WHERE order_id = :order_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':order_id', $order_id);
        $stmt->bindParam(':status', $status);
        
        if ($stmt->execute()) {
            // Log status change in history
            $this->logStatusChange($order_id, $status, $admin_id);
            return true;
        }
        
        return false;
    }

    // Update payment status
    public function updatePaymentStatus($order_id, $payment_status) {
        $query = "UPDATE " . $this->table_name . " SET payment_status = :payment_status, updated_at = NOW() WHERE order_id = :order_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':order_id', $order_id);
        $stmt->bindParam(':payment_status', $payment_status);
        
        return $stmt->execute();
    }

    // Log status change
    private function logStatusChange($order_id, $new_status, $admin_id) {
        $query = "INSERT INTO order_status_history (order_id, new_status, changed_by, notes) 
                  VALUES (:order_id, :new_status, :changed_by, :notes)";
        
        $stmt = $this->conn->prepare($query);
        $notes = "Status changed by admin";
        
        $stmt->bindParam(':order_id', $order_id);
        $stmt->bindParam(':new_status', $new_status);
        $stmt->bindParam(':changed_by', $admin_id);
        $stmt->bindParam(':notes', $notes);
        
        $stmt->execute();
    }

    // Get order statistics
    public function getStatistics() {
        $stats = array();
        
        // Total orders
        $query = "SELECT COUNT(*) as total_orders FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $stats['total_orders'] = $result['total_orders'];
        
        // Total revenue
        $query = "SELECT SUM(total_amount) as total_revenue FROM " . $this->table_name . " WHERE payment_status = 'completed'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $stats['total_revenue'] = $result['total_revenue'] ?? 0;
        
        // Orders by status
        $query = "SELECT status, COUNT(*) as count FROM " . $this->table_name . " GROUP BY status";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $stats['by_status'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Recent orders
        $query = "SELECT o.order_id, o.order_number, o.total_amount, o.status, o.order_date,
                         CONCAT(u.first_name, ' ', u.last_name) as customer_name
                  FROM " . $this->table_name . " o 
                  LEFT JOIN users u ON o.user_id = u.user_id 
                  ORDER BY o.order_date DESC LIMIT 5";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $stats['recent_orders'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        return $stats;
    }

    // Get total count for pagination
    public function getTotalCount($search = '', $status = '', $payment_status = '') {
        $query = "SELECT COUNT(DISTINCT o.order_id) as total 
                  FROM " . $this->table_name . " o 
                  LEFT JOIN users u ON o.user_id = u.user_id 
                  WHERE 1=1";
        
        $params = array();
        
        if (!empty($search)) {
            $query .= " AND (o.order_number LIKE :search OR u.first_name LIKE :search OR u.last_name LIKE :search OR u.email LIKE :search)";
            $params[':search'] = '%' . $search . '%';
        }
        
        if (!empty($status)) {
            $query .= " AND o.status = :status";
            $params[':status'] = $status;
        }
        
        if (!empty($payment_status)) {
            $query .= " AND o.payment_status = :payment_status";
            $params[':payment_status'] = $payment_status;
        }
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $row['total'];
    }
}
?>