<?php
require_once '../includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /auth/login.php");
    exit;
}

$cartItems = getCartItems($_SESSION['user_id']);

if (empty($cartItems)) {
    header("Location: view.php");
    exit;
}

$page_title = 'Checkout';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $total = array_reduce($cartItems, function($sum, $item) {
        return $sum + ($item['price'] * $item['quantity']);
    }, 0);
    
    $pdo->beginTransaction();
    
    try {
        // Create order
        $stmt = $pdo->prepare("
            INSERT INTO orders (user_id, total, payment_method, shipping_address)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $_SESSION['user_id'],
            $total,
            $_POST['payment_method'],
            $_POST['shipping_address']
        ]);
        $order_id = $pdo->lastInsertId();
        
        // Add order items
        $stmt = $pdo->prepare("
            INSERT INTO order_items (order_id, product_id, quantity, price)
            VALUES (?, ?, ?, ?)
        ");
        
        foreach ($cartItems as $item) {
            $stmt->execute([
                $order_id,
                $item['product_id'],
                $item['quantity'],
                $item['price']
            ]);
        }
        
        // Clear cart
        $pdo->prepare("DELETE FROM cart_items WHERE cart_id = (SELECT cart_id FROM cart WHERE user_id = ?)")
            ->execute([$_SESSION['user_id']]);
        
        $pdo->commit();
        
        header("Location: success.php?id=$order_id");
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Checkout failed: " . $e->getMessage();
    }
}
?>
<h1>Checkout</h1>
<?php if (isset($error)): ?>
    <div class="error"><?= $error ?></div>
<?php endif; ?>
<form method="post">
    <div class="order-summary">
        <h3>Order Summary</h3>
        <ul>
            <?php foreach ($cartItems as $item): ?>
            <li>
                <?= htmlspecialchars($item['name']) ?> 
                (x<?= $item['quantity'] ?>) 
                - $<?= number_format($item['price'] * $item['quantity'], 2) ?>
            </li>
            <?php endforeach; ?>
        </ul>
        <h4>Total: $<?= number_format(array_reduce($cartItems, function($sum, $item) {
            return $sum + ($item['price'] * $item['quantity']);
        }, 0), 2) ?></h4>
    </div>
    
    <div class="shipping-info">
        <h3>Shipping Information</h3>
        <div>
            <label>Shipping Address:</label>
            <textarea name="shipping_address" required></textarea>
        </div>
    </div>
    
    <div class="payment-method">
        <h3>Payment Method</h3>
        <div>
            <label>
                <input type="radio" name="payment_method" value="credit_card" checked>
                Credit Card
            </label>
        </div>
        <div>
            <label>
                <input type="radio" name="payment_method" value="paypal">
                PayPal
            </label>
        </div>
    </div>
    
    <button type="submit">Complete Order</button>
</form>
<?php
require_once '../includes/footer.php';
?>