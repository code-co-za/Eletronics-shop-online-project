<?php
require_once '../includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: /auth/login.php");
    exit;
}

$order_id = $_GET['id'] ?? 0;
$page_title = 'Order Confirmation';
?>
<h1>Order Confirmation</h1>
<div class="order-success">
    <p>Thank you for your order!</p>
    <p>Your order number is: <strong>#<?= $order_id ?></strong></p>
    <p>You will receive an email confirmation shortly.</p>
    <a href="/user/orders.php" class="btn">View Your Orders</a>
    <a href="/products/cellphones.php" class="btn">Continue Shopping</a>
</div>
<?php
require_once '../includes/footer.php';
?>